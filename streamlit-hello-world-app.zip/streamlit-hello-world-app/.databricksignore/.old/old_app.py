"""Aplicação Streamlit - Chatbot de Legislação Tributária.

Sistema completo com:
- Gerenciamento de sessões multi-usuário
- Memória de conversação
- Analytics e tracking de interações
- Persistência de histórico
- Monitoramento de performance com MLflow
"""

import streamlit as st
import time
from datetime import datetime
from databricks.sdk import WorkspaceClient

from config.settings import (
    CATALOG, SCHEMA, IX_TABLE, 
    GENIE_SPACE_ID, LLM_ENDPOINT,
    DATABRICKS_HOST, DATABRICKS_TOKEN
)
from agents.base_agent import AgentConfig
from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent
from agents.agent_factory import agent_factory
from supervisor.multi_agent_supervisor import MultiAgentSupervisor
from memory import SessionManager, ConversationHandler
from utils import DeltaTableAnalyticsLogger, InMemoryAnalyticsLogger


# ========================================
# 1. CONFIGURAÇÃO DA PÁGINA
# ========================================
st.set_page_config(
    page_title="Chatbot Legislação Tributária",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ========================================
# 2. INICIALIZAÇÃO DE COMPONENTES (CACHE)
# ========================================
@st.cache_resource
def initialize_components():
    """Inicializa todos os componentes do sistema (executado uma vez)."""
    
    # 2.1 Registrar agentes no factory
    agent_factory.register("rag", RAGAgent)
    agent_factory.register("genie", GenieAgent)
    
    # 2.2 Workspace Client
    workspace_client = WorkspaceClient(
        host=DATABRICKS_HOST,
        token=DATABRICKS_TOKEN
    )
    
    # 2.3 Criar agentes
    rag_agent = agent_factory.create(
        "rag",
        config=AgentConfig(
            name="query_tax_legislation",
            description="Consulta conteúdo de legislações tributárias"
        ),
        index_table=f"{CATALOG}.{SCHEMA}.{IX_TABLE}",
        endpoint_llm=LLM_ENDPOINT
    )
    
    genie_agent = agent_factory.create(
        "genie",
        config=AgentConfig(
            name="query_genie",
            description="Consultas quantitativas sobre legislações"
        ),
        genie_space_id=GENIE_SPACE_ID,
        workspace_client=workspace_client
    )
    
    # 2.4 Criar supervisor
    supervisor = MultiAgentSupervisor(
        agents=[rag_agent, genie_agent],
        llm_endpoint=LLM_ENDPOINT,
        workspace_client=workspace_client
    )
    
    # 2.5 Analytics Logger
    # Opção 1: Delta Table (produção)
    try:
        analytics = DeltaTableAnalyticsLogger(
            catalog=CATALOG,
            schema=SCHEMA,
            interactions_table="conversation_interactions",
            events_table="conversation_events",
            enable_batch=True,
            batch_size=10
        )
        analytics_type = "Delta Table"
    except Exception as e:
        # Fallback: In-Memory (desenvolvimento/testes)
        st.warning(f"Analytics em Delta Table não disponível. Usando modo in-memory. Erro: {e}")
        analytics = InMemoryAnalyticsLogger()
        analytics_type = "In-Memory"
    
    # 2.6 Session Manager
    session_manager = SessionManager(
        session_timeout_minutes=120,
        max_messages_per_session=50
    )
    
    # 2.7 Conversation Handler
    conversation_handler = ConversationHandler(
        session_manager=session_manager,
        analytics_logger=analytics,
        enable_metrics=True
    )
    
    return {
        "supervisor": supervisor,
        "conversation_handler": conversation_handler,
        "analytics": analytics,
        "analytics_type": analytics_type,
        "workspace_client": workspace_client
    }


# Carregar componentes
components = initialize_components()
supervisor = components["supervisor"]
conversation_handler = components["conversation_handler"]
analytics = components["analytics"]


# ========================================
# 3. GERENCIAMENTO DE SESSÃO
# ========================================
def get_or_create_session():
    """Obtém ou cria uma sessão para o usuário atual."""
    if "session_id" not in st.session_state:
        # Tentar obter user_id do Databricks (se disponível)
        try:
            user_id = st.experimental_user.email
        except:
            user_id = None
        
        # Criar nova sessão
        session_id, session_data = conversation_handler.session_manager.get_or_create_session(
            user_id=user_id
        )
        st.session_state.session_id = session_id
        st.session_state.session_created_at = datetime.now()
        
        # Log evento de criação
        if analytics:
            analytics.log_event(
                session_id=session_id,
                event_type="session_created",
                metadata={"user_id": user_id}
            )
    
    return st.session_state.session_id


# Obter sessão atual
session_id = get_or_create_session()


# ========================================
# 4. INTERFACE PRINCIPAL
# ========================================
st.title("🤖 Chatbot de Legislação Tributária")
st.caption("Assistente inteligente para consultas sobre legislação tributária brasileira")

# Container para o chat
chat_container = st.container()

# Exibir histórico de conversação
with chat_container:
    context = conversation_handler.get_conversation_context(session_id)
    
    for msg in context:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        
        # Mapear roles para exibição
        if role == "assistant":
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(content)
        elif role == "user":
            with st.chat_message("user", avatar="👤"):
                st.markdown(content)
        elif role == "system":
            with st.chat_message("system", avatar="⚙️"):
                st.info(content)


# ========================================
# 5. INPUT DO USUÁRIO
# ========================================
if user_input := st.chat_input("Digite sua pergunta sobre legislação tributária..."):
    
    # Exibir mensagem do usuário imediatamente
    with st.chat_message("user", avatar="👤"):
        st.markdown(user_input)
    
    # Processar input do usuário
    conversation_handler.process_user_input(
        session_id=session_id,
        content=user_input,
        metadata={
            "source": "streamlit_chat",
            "timestamp": datetime.now().isoformat()
        }
    )
    
    # Processar com supervisor
    with st.chat_message("assistant", avatar="🤖"):
        with st.spinner("Pensando..."):
            start_time = time.time()
            
            try:
                # Obter contexto da conversação
                conversation_context = conversation_handler.get_conversation_context(
                    session_id=session_id,
                    limit=10  # Últimas 10 mensagens
                )
                
                # Invocar supervisor
                response = supervisor.invoke(user_input)
                
                # Calcular latência
                latency_ms = (time.time() - start_time) * 1000
                
                # Extrair resposta final
                messages = response.get("messages", [])
                if messages:
                    final_answer = messages[-1].content
                    agent_name = getattr(messages[-1], "name", "supervisor")
                    
                    # Exibir resposta
                    st.markdown(final_answer)
                    
                    # Processar resposta do agente
                    conversation_handler.process_agent_response(
                        session_id=session_id,
                        content=final_answer,
                        agent_name=agent_name,
                        metrics={
                            "latency_ms": round(latency_ms, 2),
                            "model": LLM_ENDPOINT.split("/")[-1] if "/" in LLM_ENDPOINT else LLM_ENDPOINT,
                            "timestamp": datetime.now().isoformat()
                        },
                        metadata={
                            "response_type": "success",
                            "num_messages_in_context": len(conversation_context)
                        }
                    )
                    
                    # Exibir métricas (opcional, em expander)
                    with st.expander("📊 Métricas da Resposta"):
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Latência", f"{latency_ms:.0f}ms")
                        with col2:
                            st.metric("Agente", agent_name)
                        with col3:
                            st.metric("Mensagens", len(conversation_context))
                
                else:
                    st.error("Não foi possível gerar uma resposta. Tente novamente.")
                    
            except Exception as e:
                st.error(f"Erro ao processar sua pergunta: {str(e)}")
                
                # Log erro no analytics
                if analytics:
                    analytics.log_event(
                        session_id=session_id,
                        event_type="error",
                        metadata={
                            "error": str(e),
                            "user_input": user_input,
                            "timestamp": datetime.now().isoformat()
                        }
                    )


# ========================================
# 6. SIDEBAR - CONTROLES E ESTATÍSTICAS
# ========================================
with st.sidebar:
    st.header("⚙️ Controles")
    
    # Botão para limpar conversação
    if st.button("🗑️ Limpar Conversação", use_container_width=True):
        if conversation_handler.clear_conversation(session_id):
            st.success("Conversação limpa!")
            st.rerun()
        else:
            st.error("Erro ao limpar conversação")
    
    # Botão para nova sessão
    if st.button("🔄 Nova Sessão", use_container_width=True):
        # Encerrar sessão atual
        conversation_handler.session_manager.end_session(session_id)
        
        # Limpar session_state
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        
        st.success("Nova sessão criada!")
        st.rerun()
    
    st.divider()
    
    # Estatísticas da sessão
    st.header("📊 Estatísticas da Sessão")
    
    summary = conversation_handler.get_conversation_summary(session_id)
    if summary:
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric(
                "Mensagens",
                summary.get("message_count", 0)
            )
        
        with col2:
            st.metric(
                "Sessões Ativas",
                conversation_handler.session_manager.get_active_sessions_count()
            )
        
        # Informações detalhadas em expander
        with st.expander("🔍 Detalhes da Sessão"):
            st.json({
                "session_id": summary.get("session_id", "N/A")[:8] + "...",
                "user_id": summary.get("user_id", "N/A"),
                "created_at": summary.get("created_at", "N/A"),
                "last_activity": summary.get("last_activity", "N/A"),
                "is_active": summary.get("is_active", False)
            })
    
    st.divider()
    
    # Estatísticas do Analytics
    st.header("📈 Analytics")
    
    analytics_stats = analytics.get_statistics()
    
    st.metric(
        "Tipo de Analytics",
        components["analytics_type"]
    )
    
    if components["analytics_type"] == "Delta Table":
        col1, col2 = st.columns(2)
        with col1:
            st.metric(
                "Interações Logadas",
                analytics_stats.get("interactions_logged", 0)
            )
        with col2:
            st.metric(
                "Eventos Logados",
                analytics_stats.get("events_logged", 0)
            )
        
        # Botão para flush manual
        if st.button("💾 Gravar Analytics", use_container_width=True):
            analytics.flush_all()
            st.success("Dados gravados no Delta Table!")
    
    else:  # In-Memory
        st.metric(
            "Interações em Memória",
            analytics_stats.get("interactions_count", 0)
        )
    
    st.divider()
    
    # Informações do sistema
    with st.expander("ℹ️ Informações do Sistema"):
        st.code(f"""
            Catálogo: {CATALOG}
            Schema: {SCHEMA}
            Tabela de Índice: {IX_TABLE}
            Genie Space ID: {GENIE_SPACE_ID}
            LLM Endpoint: {LLM_ENDPOINT.split('/')[-1] if '/' in LLM_ENDPOINT else LLM_ENDPOINT}
        """)


# ========================================
# 7. CLEANUP AO ENCERRAR
# ========================================
# Nota: Streamlit não tem um hook de "on_close" confiável,
# mas o __del__ do analytics garante flush dos buffers
