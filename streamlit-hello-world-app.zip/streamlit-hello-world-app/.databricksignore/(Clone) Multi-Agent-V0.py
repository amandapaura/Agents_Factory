# Databricks notebook source
# DBTITLE 1,Untitled
 !pip install -r requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Cell 3
# Catalog 
CATALOG = "financefranchise"
SCHEMA = "tax_legislation"

# Listar tabelas no schema
tables = spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}").collect()

print(f"📊 Tabelas disponíveis em {CATALOG}.{SCHEMA}:\n")
for table in tables:
    table_name = table.tableName
    print(f"   - {table_name}")

# COMMAND ----------

IX_TABLE = "tax_legislation_idx"
DELTA_TABLE = "tax_legislation"

# IDs dos recursos
GENIE_SPACE_ID = "01f0f79711e8177fbf6f3fb48a2d4e27"
GENIE_NAME = "[TAX] Legislation"
GENIE_DESCRIPTION = "Este agente responde perguntas sobre legislações tributárias"

# KA_ENDPOINT = "ka-e805a80b-endpoint"
# KA_NAME = "contracts-ka"
# KA_DESCRIPTION = "Este agente responde perguntas sobre contratos de prestação de serviço"

# Usar endpoint que suporta tool calling
LLM_ENDPOINT = "databricks-claude-haiku-4-5" #"databricks-meta-llama-3-1-70b-instruct"

# Credenciais Databricks
DATABRICKS_HOST = f"https://{spark.conf.get('spark.databricks.workspaceUrl')}"
DATABRICKS_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

print(f"✅ Host: {DATABRICKS_HOST}")
print(f"✅ Genie: {GENIE_SPACE_ID}")
print(f"✅ LLM Endpoint: {LLM_ENDPOINT}")
# print(f"✅ KB: {KB_ENDPOINT}")

# COMMAND ----------

# DBTITLE 1,Cell 3
import requests
import re
import os
from typing import Generator, Dict, List, Any
from uuid import uuid4
import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain.genie import GenieAgent
from langgraph_supervisor import create_supervisor
from databricks_langchain import ChatDatabricks

# OBO - On-Behalf-Of User Authentication
from databricks.sdk.credentials_provider import ModelServingUserCredentials
from databricks.vector_search.client import VectorSearchClient

# ============================================
# Knowledge Base Agent (RAG)
# ============================================
from langchain_core.tools import tool
from langchain_core.messages import ToolMessage
from langgraph.prebuilt import create_react_agent
from langchain.agents import create_agent

# COMMAND ----------

# DBTITLE 1,Cell 4
class MetadataExtractor:
    # Mapeamento de estados brasileiros (nome completo -> sigla)
    STATE_MAPPING = {
        'acre': 'AC', 'alagoas': 'AL', 'amapá': 'AP', 'amapa': 'AP',
        'amazonas': 'AM', 'bahia': 'BA', 'ceará': 'CE', 'ceara': 'CE',
        'distrito federal': 'DF', 'espírito santo': 'ES', 'espirito santo': 'ES',
        'goiás': 'GO', 'goias': 'GO', 'maranhão': 'MA', 'maranhao': 'MA',
        'mato grosso': 'MT', 'mato grosso do sul': 'MS',
        'minas gerais': 'MG', 'pará': 'PA', 'para': 'PA',
        'paraíba': 'PB', 'paraiba': 'PB', 'paraná': 'PR', 'parana': 'PR',
        'pernambuco': 'PE', 'piauí': 'PI', 'piaui': 'PI',
        'rio de janeiro': 'RJ', 'rio grande do norte': 'RN',
        'rio grande do sul': 'RS', 'rondônia': 'RO', 'rondonia': 'RO',
        'roraima': 'RR', 'santa catarina': 'SC', 'são paulo': 'SP',
        'sao paulo': 'SP', 'sergipe': 'SE', 'tocantins': 'TO'
    }
    
    # Lista de siglas válidas
    VALID_STATES = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
                    'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
                    'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO']
    
    @staticmethod
    def extract(query: str) -> dict:
        print('\n Extraindo metadados ...')
        filtros = {}

        # Filtro por número da lei - aceita variações como "Lei 123", "lei numero 123", "ache a lei numero 123"
        match_number = re.search(r'lei\s+(?:n[úu]mero\s+|n[°º]\.?\s+)?(\d+)', query, re.IGNORECASE)
        if match_number:
            filtros['law_number'] = match_number.group(1)

        # Filtro por ano da lei - aceita variações como "lei de 2020", "lei do ano 2021", "ano 2022"
        match_year = re.search(r'(?:ano|de)\s+(\d{4})|\b(19\d{2}|20\d{2})\b', query, re.IGNORECASE)
        if match_year:
            filtros['law_year'] = match_year.group(1) or match_year.group(2)

        # Filtro por estado da lei - aceita nome completo ou sigla
        query_lower = query.lower()
        
        # Primeiro tenta encontrar siglas (ex: "RJ", "SP")
        match_sigla = re.search(r'\b([A-Z]{2})\b', query)
        if match_sigla:
            sigla = match_sigla.group(1).upper()
            if sigla in MetadataExtractor.VALID_STATES:
                filtros['law_state'] = sigla
        
        # Se não encontrou sigla, busca por nome completo do estado
        if 'law_state' not in filtros:
            for state_name, sigla in MetadataExtractor.STATE_MAPPING.items():
                if state_name in query_lower:
                    filtros['law_state'] = sigla
                    break

        # Filtro por cidade da lei - aceita padrões como "lei de [cidade]", "lei municipal de [cidade]"
        # Captura nomes de cidades após palavras-chave comuns
        match_city = re.search(
            r'(?:lei\s+(?:municipal\s+)?(?:da\s+cidade\s+)?de\s+|cidade\s+de\s+|município\s+de\s+)([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)',
            query
        )
        if match_city:
            city_name = match_city.group(1).strip()
            # Verifica se não é um estado (para evitar falsos positivos)
            if city_name.lower() not in MetadataExtractor.STATE_MAPPING:
                filtros['law_city'] = city_name

        return filtros

class RAGPipeline:
    def __init__(self, index_table: str, endpoint_llm: str):
        self.index_table = index_table
        self.endpoint_llm = endpoint_llm

    def vector_search(self, query_text: str, filtros: dict, num_results: int = 3, columns: list = None) -> list:
        try:
            print('\n Iniciando busca vetorial ...')
            client = VectorSearchClient()
            index = client.get_index(index_name=self.index_table)
            results = index.similarity_search(
                query_text=query_text,
                num_results=num_results,
                filters=filtros if filtros else None,
                columns=columns
            )
            patterns = r'[\n\t\r]|td>||<td>|</td>|<tr>|</tr>|<p>|</p>|<b>|</b>'
            cleaned_texts = [
                re.sub(patterns, '', i[1])
                for i in results["result"]["data_array"]
            ]
            #print(f'Contexto: {cleaned_texts}')
            return cleaned_texts
        except Exception as e:
            print(f"Error: {e}")
            return []

    @staticmethod
    def auto_merge_chunks(chunks: list, min_length: int = 300) -> list:
        try:
            merged = []
            buffer = ""
            for chunk in chunks:
                if len(buffer) + len(chunk) < min_length:
                    buffer += " " + chunk
                else:
                    if buffer:
                        merged.append(buffer.strip())
                    buffer = chunk
            if buffer:
                merged.append(buffer.strip())
            return merged
        except Exception as e:
            print(f"Error: {e}")
            return []

    def generate_llm_response(self, query: str, context_list: list) -> str:
        print('\n Gerando resposta da LLM')
        try:
            import mlflow.deployments
            client = mlflow.deployments.get_deploy_client("databricks")
            context = " ".join(context_list)
            response = client.predict(
                endpoint=self.endpoint_llm,
                inputs={"messages": [
                    {
                        "role": "system",
                        "content": (
                            "Você é um assistente especializado em legislação tributária brasileira. Responda às perguntas do usuário APENAS com base no contexto fornecido da nossa base de dados (RAG). Você deve se ater estritamente ao tema de tributação e legislação fiscal brasileira. Se o usuário perguntar sobre assuntos não relacionados a tributação, educadamente redirecione a conversa informando que você é especializado apenas em legislação tributária brasileira. Se a resposta não estiver no contexto fornecido, diga 'Não há informação suficiente no contexto para responder.' Escreva o texto de forma clara, usando formatação markdown. Você pode inserir tabelas se ajudar a organizar as informações e usar bullet points quando necessário. Não inclua referências ao contexto no seu texto final. Sempre responda no mesmo idioma da pergunta do usuário."
                            f"Contexto: {context}"
                        )
                    },
                    {
                        "role": "user",
                        "content": f"{query}"
                    }
                ]}
            )
            return response["choices"][0]["message"]["content"]
        except Exception as e:
            print(f"Error: {e}")
            return ""

    def process_query(self, query_usuario: str) -> dict:
        filtros = MetadataExtractor.extract(query_usuario)
        print(filtros)
        resultados = self.vector_search(query_usuario, filtros)
        merged_context = self.auto_merge_chunks(resultados)
        resposta = self.generate_llm_response(query_usuario, merged_context)
        return {'answer': resposta}

# COMMAND ----------

# DBTITLE 1,Criar Tools (Agentes Filhos)
def create_rag_tool(user_client: WorkspaceClient):
    """Cria agente RAG para consultar Knowledge Base."""
    
    @tool
    def query_tax_legislation_tool(question: str) -> str:
        """
        Consulta legislacao tributaria usando RAG.
        Use para perguntas sobre CONTEÚDO de leis, artigos, impostos específicos.
        
        Args:
            question: A pergunta do usuário sobre legislação tributária
        """
        pipeline = RAGPipeline(
            index_table=f"{CATALOG}.{SCHEMA}.{IX_TABLE}",
            endpoint_llm=LLM_ENDPOINT
        )
        result = pipeline.process_query(question)
        return result['answer']
    
    # Criar agente React com a tool
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT)
    agent = create_react_agent(llm, tools=[query_tax_legislation_tool], name="query_tax_legislation")
    return agent
        
def create_genie_tool(user_client: WorkspaceClient):
    """Cria agente Genie para consultas estruturadas."""

    @tool
    def query_genie_tool(question: str) -> str:
        """
        Perguntas estruturadas: contagens, listas, agrupamentos e metadados.
        Use para perguntas como 'quantas leis', 'liste leis', 'agrupe por estado'.

        Args:
            question: A pergunta do usuário sobre dados estruturados de legislação
        """
        try:
            genie = GenieAgent(
                genie_space_id=GENIE_SPACE_ID,
                genie_agent_name=GENIE_NAME,
                description=GENIE_DESCRIPTION,
                client=user_client,
            )
            from langchain_core.messages import HumanMessage
            res = genie.invoke({"messages": [HumanMessage(content=question)]})
            if isinstance(res, dict) and res.get("messages"):
                last = res["messages"][-1]
                return getattr(last, "content", str(last)) or "Sem resposta do Genie"
            return str(res)
        except Exception as e:
            return f"Erro Genie: {e}"

    # Criar agente React com a tool
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT)
    agent = create_react_agent(llm, tools=[query_genie_tool], name="query_genie")
    return agent

print("✅ Funções create_rag_tool e create_genie_tool definidas")

# COMMAND ----------

# DBTITLE 1,Passo 1: Instanciar Tools (Agentes Filhos)
# Criar cliente workspace
w = WorkspaceClient(
    host=DATABRICKS_HOST,
    token=DATABRICKS_TOKEN
)

# Instanciar os agentes
tool_rag = create_rag_tool(w)
tool_genie = create_genie_tool(w)

print("Agentes instanciados com sucesso:")
print(f"   1. Agente RAG (legislação tributária)")
print(f"   2. Agente Genie (consultas quantitativas)")

# COMMAND ----------

def create_multi_agent_supervisor_with_obo():
    """
    Cria o supervisor LangGraph com Genie e Knowledge Base usando OBO.
    Ambos os agentes usarão as permissões do usuário que fez a requisição.
    
    Args:
        user_client: WorkspaceClient com credenciais OBO
    """
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT)
    
    # ============================================
    # Supervisor Multi-Agente
    # ============================================
    prompt = f"""Você é um supervisor multi-agente. Sua tarefa é direcionar perguntas e transmitir as respostas.

        AGENTES:
        - {tool_genie.name}: consultas QUANTITATIVAS e AGREGAÇÕES (quantas leis, liste todas as leis de SP, agrupe por estado/ano, 
        contagem de artigos, leis mais recentes)
        - {tool_rag.name}: consultas de CONTEÚDO e INTERPRETAÇÃO (o que diz o artigo X da lei Y, explique ICMS, 
        qual a alíquota prevista, quais são as exceções)

        REGRAS DE ROTEAMENTO:
        - Perguntas QUANTITATIVAS (quantas, conte, liste todas, agrupe) → {tool_genie.name}
        - Perguntas de CONTEÚDO (o que diz, explique, qual valor, como funciona) → {tool_rag.name}
        - Se a pergunta combinar ambos (ex: "quantas leis falam sobre X"), priorize {tool_genie.name}

        REGRAS DE RESPOSTA:
        - Transmita a resposta do agente de forma completa e clara ao usuário
        - Mantenha formatação markdown (tabelas, listas) se presente"""
    
    return create_supervisor(
        agents=[tool_genie, tool_rag],
        model=llm,
        prompt=prompt,
        add_handoff_messages=False,
        output_mode="full_history",
    ).compile()

# COMMAND ----------

# DBTITLE 1,Passo 2: Instanciar Supervisor
# Instanciar o supervisor multi-agente
supervisor = create_multi_agent_supervisor_with_obo()

print("Supervisor multi-agente criado com sucesso!")
print("   Agentes disponíveis:")
print(f"   - {tool_genie.name}")
print(f"   - {tool_rag.name}")

# COMMAND ----------

# DBTITLE 1,Teste 1: Pergunta Quantitativa (Genie)
# Teste 1: Pergunta quantitativa - deve ir para Genie
from langchain_core.messages import HumanMessage

question1 = "Quantas legislações existem por estado?"
print(f"Pergunta: {question1}\n")

response1 = supervisor.invoke({"messages": [HumanMessage(content=question1)]})

# Extrair resposta final
for msg in response1["messages"]:
    if hasattr(msg, 'content') and msg.content:
        print(f"{msg.name if hasattr(msg, 'name') else 'Resposta'}: {msg.content}\n")

# COMMAND ----------

# DBTITLE 1,Teste 2: Pergunta de Conteúdo (RAG)
# Teste 2: Pergunta de conteúdo - deve ir para RAG
question2 = "O que é ICMS e como funciona?"
print(f"Pergunta: {question2}\n")

response2 = supervisor.invoke({"messages": [HumanMessage(content=question2)]})

# Extrair resposta final
for msg in response2["messages"]:
    if hasattr(msg, 'content') and msg.content:
        print(f"{msg.name if hasattr(msg, 'name') else 'Resposta'}: {msg.content}\n")

# COMMAND ----------

# DBTITLE 1,Teste 3: Pergunta Mista
# Teste 3: Pergunta mista - deve priorizar Genie
question3 = "Quantas leis falam sobre ICMS?"
print(f"Pergunta: {question3}\n")

response3 = supervisor.invoke({"messages": [HumanMessage(content=question3)]})

# Extrair resposta final
for msg in response3["messages"]:
    if hasattr(msg, 'content') and msg.content:
        print(f"{msg.name if hasattr(msg, 'name') else 'Resposta'}: {msg.content}\n")