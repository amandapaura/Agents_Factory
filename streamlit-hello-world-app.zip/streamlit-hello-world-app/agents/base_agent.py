"""
Classe abstrata base para todos os agentes.
Implementa o padrão Abstract Factory para permitir extensibilidade.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass, field

@dataclass
class AgentConfig:
    """Configuração base para agentes."""
    name: str
    description: str
    endpoint: Optional[str] = None
    additional_params: Optional[Dict[str, Any]] = field(default_factory=dict)


class BaseAgent(ABC):
    """Classe abstrata base para todos os agentes."""
    
    def __init__(self, config: AgentConfig):
        self.name = config.name
        self.description = config.description
        self.config = config
        self._validate_config()
    
    @abstractmethod
    def execute(self, query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Executa a consulta no agente."""
        pass
    
    def validate_input(self, query: str) -> bool:
        """Valida a entrada do usuário."""
        if not query or not isinstance(query, str):
            return False
        if len(query.strip()) == 0:
            return False
        return True
    
    def _validate_config(self) -> None:
        """Valida a configuração do agente."""
        if not self.name:
            raise ValueError("Agent name cannot be empty")
        if not self.description:
            raise ValueError("Agent description cannot be empty")
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Retorna as capacidades do agente."""
        return {
            "name": self.name,
            "description": self.description,
            "type": self.__class__.__name__
        }
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}')"
