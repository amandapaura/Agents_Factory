"""Implementação do agente Knowledge Assistant."""

from typing import Dict, Any, Optional
import requests
import json
from databricks.sdk import WorkspaceClient
from .base_agent import BaseAgent, AgentConfig


class KAAgent(BaseAgent):
    
    def __init__(
        self, 
        config: AgentConfig, 
        ka_endpoint: str,
        workspace_client: WorkspaceClient
    ):
        """Inicializa o KAAgent."""
        super().__init__(config)
        self.ka_endpoint = ka_endpoint
        self.workspace_client = workspace_client
        
        self.keywords = [
            "o que é", "como funciona", "explique", "qual o conteúdo",
            "o que diz", "qual a alíquota", "quais exceções", "artigo",
            "interpretação", "significado", "define", "estabelece",
            "prevê", "determina", "dispõe", "lei", "decreto", "norma",
            "legislação", "tributária", "imposto", "icms", "iss"
        ]
    
    def execute(self, query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Executa consulta no Knowledge Assistant."""
        if not self.validate_input(query):
            return "Erro: Consulta inválida."
        
        try:
            host = self.workspace_client.config.host.rstrip('/')
            headers = self.workspace_client.config._header_factory()
            headers["Content-Type"] = "application/json"
            
            url = f"{host}/serving-endpoints/responses"
            
            payload = {
                "model": self.ka_endpoint,
                "input": [{"role": "user", "content": query}],
                "stream": True
            }
            
            response = requests.post(
                url,
                headers=headers,
                json=payload,
                stream=True,
                timeout=120
            )
            
            response.raise_for_status()
            
            # Processar streaming
            result = ""
            for line in response.iter_lines():
                if line:
                    text = line.decode('utf-8')
                    
                    if text.startswith('data: ') and text != 'data: [DONE]':
                        try:
                            chunk = json.loads(text[6:])
                            chunk_type = chunk.get("type")
                            
                            # Capturar deltas incrementais
                            if chunk_type == "response.output_text.delta":
                                result += chunk.get("delta", "")
                            
                            # Capturar resposta final completa
                            elif chunk_type == "response.output_item.done":
                                item = chunk.get("item", {})
                                if item.get("type") == "message":
                                    for content in item.get("content", []):
                                        if content.get("type") == "output_text":
                                            final_text = content.get("text", "")
                                            if final_text:
                                                result = final_text
                        except json.JSONDecodeError:
                            pass
            
            return result or "Sem resposta do Knowledge Assistant"
            
        except Exception as e:
            return f"Erro ao consultar Knowledge Assistant: {str(e)}"
    
    def is_relevant(self, query: str) -> bool:
        """Verifica se a consulta é relevante para este agente."""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.keywords)
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Retorna as capacidades específicas do KAAgent."""
        base_caps = super().get_capabilities()
        base_caps.update({
            "specialization": "knowledge_assistant_queries",
            "keywords": self.keywords,
            "ka_endpoint": self.ka_endpoint,
            "uses_databricks_ka": True
        })
        return base_caps
