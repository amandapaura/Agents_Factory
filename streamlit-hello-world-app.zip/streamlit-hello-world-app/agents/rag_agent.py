"""Implementação do agente RAG para consultas de conteúdo.

Este agente é especializado em responder perguntas sobre o CONTEÚDO
de legislações tributárias usando Retrieval-Augmented Generation (RAG).

"""

from typing import Dict, Any, Optional, List
import re
import mlflow.deployments
from .base_agent import BaseAgent, AgentConfig
from core.rag_pipeline import RAGPipeline
    
class RAGAgent(BaseAgent):
    """Agente especializado em consultas de CONTEÚDO usando RAG."""
    
    def __init__(self, config: AgentConfig, index_table: str, endpoint_llm: str, workspace_client=None):
        super().__init__(config)
        self.rag_pipeline = RAGPipeline(index_table, endpoint_llm, workspace_client)
        self.keywords = [
            "o que é", "como funciona", "explique", "qual o conteúdo",
            "o que diz", "qual a alíquota", "quais exceções", "artigo",
            "interpretação", "significado", "define", "estabelece",
            "prevê", "determina", "dispõe"
        ]
    
    def execute(self, query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Executa consulta RAG para buscar conteúdo de legislação."""
        if not self.validate_input(query):
            return "Erro: Consulta inválida. Por favor, forneça uma pergunta válida."
        
        try:
            print(f"🔍 [{self.name}] Processando consulta de conteúdo...")
            
            # Processar query via RAG pipeline
            response = self.rag_pipeline.process_query(query)
            
            # Extrair resposta (idêntico ao padrão do Genie)
            if isinstance(response, dict) and response.get("messages"):
                last_message = response["messages"][-1]
                content = last_message.get("content", str(last_message))
                return content or "Sem resposta do RAG"
            
            return str(response)
            
        except Exception as e:
            error_msg = f"Erro ao processar consulta RAG: {str(e)}"
            print(f"❌ {error_msg}")
            return error_msg
    
    def is_relevant(self, query: str) -> bool:
        """Verifica se a consulta é relevante para este agente."""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.keywords)
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Retorna as capacidades específicas do RAGAgent."""
        base_caps = super().get_capabilities()
        base_caps.update({
            "specialization": "content_queries",
            "keywords": self.keywords,
            "supports_filters": True,
            "uses_vector_search": True,
            "index_table": self.rag_pipeline.index_table,
            "llm_endpoint": self.rag_pipeline.endpoint_llm
        })
        return base_caps
