"""Factory para criar agentes dinamicamente."""

from typing import Dict, Type, Any
from .base_agent import BaseAgent, AgentConfig


class AgentFactory:
    """Factory para criar e registrar agentes."""
    
    def __init__(self):
        self._agents: Dict[str, Type[BaseAgent]] = {}
    
    def register(self, agent_type: str, agent_class: Type[BaseAgent]) -> None:
        """Registra um novo tipo de agente.
        
        Args:
            agent_type: Identificador único do agente (ex: "rag", "genie")
            agent_class: Classe do agente (RAGAgent, GenieAgent, etc)
        """
        if agent_type in self._agents:
            raise ValueError(f"Agent type '{agent_type}' already registered")
        self._agents[agent_type] = agent_class
        print(f" Agente '{agent_type}' registrado: {agent_class.__name__}")
    
    def create(self, agent_type: str, config: AgentConfig, **kwargs) -> BaseAgent:
        """Cria uma instância de agente.
        
        Args:
            agent_type: Tipo do agente registrado
            config: Configuração do agente
            **kwargs: Parâmetros adicionais específicos do agente
        
        Returns:
            Instância do agente criado
        """
        if agent_type not in self._agents:
            raise ValueError(
                f"Unknown agent type: '{agent_type}'. "
                f"Available: {list(self._agents.keys())}"
            )
        
        agent_class = self._agents[agent_type]
        return agent_class(config, **kwargs)
    
    def list_agents(self) -> Dict[str, str]:
        """Lista todos os agentes registrados."""
        return {
            agent_type: agent_class.__name__ 
            for agent_type, agent_class in self._agents.items()
        }


# Instância global do factory (singleton)
agent_factory = AgentFactory()