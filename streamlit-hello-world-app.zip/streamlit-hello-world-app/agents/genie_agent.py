"""Implementação do agente Genie para consultas quantitativas."""

from typing import Dict, Any, Optional
from databricks.sdk import WorkspaceClient
from databricks_langchain import GenieAgent as DatabricksGenieAgent
from langchain_core.messages import HumanMessage
from .base_agent import BaseAgent, AgentConfig
import os


class GenieAgent(BaseAgent):
    """Agente especializado em consultas QUANTITATIVAS usando Genie Space."""
    
    def __init__(
        self, 
        config: AgentConfig, 
        genie_space_id: str,
        workspace_client: WorkspaceClient
    ):
        """Inicializa o GenieAgent.
        
        Args:
            config: Configuração do agente
            genie_space_id: ID do Genie Space
            workspace_client: Cliente autenticado do Databricks
        """
        super().__init__(config)
        self.genie_space_id = genie_space_id #self.genie_space_id = os.getenv("genie-space")
        self.workspace_client = workspace_client
        
        # Criar instância do Genie Agent do Databricks
        self.genie = DatabricksGenieAgent(
            genie_space_id=genie_space_id,
            genie_agent_name=config.name,
            description=config.description,
            client=workspace_client,
        )
        
        self.keywords = [
            "quantas", "quantos", "conte", "liste", "listar",
            "agrupe", "total", "soma", "média", "máximo", "mínimo",
            "mostre todas", "mostre todos", "filtre", "ordene"
        ]
    
    def execute(self, query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Executa consulta no Genie Space."""
        if not self.validate_input(query):
            return "Erro: Consulta inválida. Por favor, forneça uma pergunta válida."
        
        try:
            print(f"📊 [{self.name}] Processando consulta quantitativa...")
            
            # Invocar Genie Agent
            response = self.genie.invoke({
                "messages": [HumanMessage(content=query)]
            })
            
            # Extrair resposta
            if isinstance(response, dict) and response.get("messages"):
                last_message = response["messages"][-1]
                content = getattr(last_message, "content", str(last_message))
                return content or "Sem resposta do Genie"
            
            return str(response)
            
        except Exception as e:
            error_msg = f"Erro ao processar consulta Genie: {str(e)}"
            print(f"❌ {error_msg}")
            return error_msg
    
    def is_relevant(self, query: str) -> bool:
        """Verifica se a consulta é relevante para este agente."""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.keywords)
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Retorna as capacidades específicas do GenieAgent."""
        base_caps = super().get_capabilities()
        base_caps.update({
            "specialization": "quantitative_queries",
            "keywords": self.keywords,
            "supports_aggregations": True,
            "supports_sql": True,
            "genie_space_id": self.genie_space_id
        })
        return base_caps