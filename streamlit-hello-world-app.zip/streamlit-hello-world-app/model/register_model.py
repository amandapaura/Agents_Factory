# Databricks notebook source
%pip install -qq -r ../requirements.txt

# COMMAND ----------

%restart_python

# COMMAND ----------

import sys
import os

# Adicionar pasta raiz ao Python path para importar módulos
root_path = os.path.abspath(os.path.join(os.getcwd(), '..'))
if root_path not in sys.path:
    sys.path.insert(0, root_path)

import re
import mlflow
import pandas as pd
import time
from mlflow.models import infer_signature
from mlflow.models.resources import DatabricksGenieSpace, DatabricksServingEndpoint
from mlflow.models.auth_policy import AuthPolicy, SystemAuthPolicy, UserAuthPolicy
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput
from config.settings import CATALOG, SCHEMA, IX_TABLE, GENIE_SPACE_ID, LLM_ENDPOINT, KA_ENDPOINT, MODEL_ENDPOINT, MODEL_NAME, SQL_WAREHOUSE_ID

# Importar o modelo existente
from model.tax_chatbot_model import TaxChatbotModel, extract_response_and_metrics

# Testar se os componentes funcionam
from agents.ka_agent import KAAgent
from agents.agent_factory import agent_factory
from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent
from agents.base_agent import AgentConfig
from supervisor.multi_agent_supervisor import MultiAgentSupervisor

print("🔄 Testando componentes do modelo...")

# Registrar agentes no factory
agent_factory.register("ka", KAAgent)
agent_factory.register("genie", GenieAgent)

# Criar WorkspaceClient
print("🔄 Criando WorkspaceClient...")
workspace_client = WorkspaceClient()

print(f"✅ WorkspaceClient criado")
print(f"   Host: {workspace_client.config.host}")
print(f"   Auth type: {workspace_client.config.auth_type}")

# Criar KAAgent
print(f"🔄 Criando KAAgent...")
ka_agent = agent_factory.create(
    "ka",
    config=AgentConfig(
        name="query_ka",
        description="Consulta conteúdo de legislações"
    ),
    ka_endpoint=KA_ENDPOINT,
    workspace_client=workspace_client
)
print("✅ KAAgent criado")

# Criar GenieAgent
print(f"🔄 Criando GenieAgent...")
genie_agent = agent_factory.create(
    "genie",
    config=AgentConfig(
        name="query_genie",
        description="Consultas quantitativas sobre legislações"
    ),
    genie_space_id=GENIE_SPACE_ID,
    workspace_client=workspace_client
)
print("✅ GenieAgent criado")

# Criar supervisor
print(f"🔄 Criando MultiAgentSupervisor...")
supervisor = MultiAgentSupervisor(
    agents=[ka_agent, genie_agent],
    llm_endpoint=LLM_ENDPOINT,
    workspace_client=workspace_client
)
print("✅ Supervisor criado")

# Testar supervisor
test_input = "O que é ICMS?"
print(f"\n🧪 Testando supervisor com: '{test_input}'")
test_response = supervisor.invoke(test_input)
test_result = extract_response_and_metrics(test_response)

print(f"\n✅ Teste executado com sucesso!")
print(f"   Answer: {test_result['answer'][:200]}...")
print(f"   Tokens: {test_result['total_tokens']}")

# COMMAND ----------

# Logar modelo usando code-based logging com AuthPolicy
print("\n🔄 Registrando modelo no MLflow...")

# Definir recursos de sistema necessários para OBO
print("\n🔐 Configurando recursos de sistema para OBO...")
system_resources = [
    DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT),
    DatabricksGenieSpace(genie_space_id=GENIE_SPACE_ID),
    DatabricksServingEndpoint(endpoint_name=KA_ENDPOINT),
]

print(f"✅ System Resources configurados:")
print(f"   - LLM Endpoint: {LLM_ENDPOINT}")
print(f"   - Genie Space: {GENIE_SPACE_ID}")
print(f"   - KA Endpoint: {KA_ENDPOINT}")

# Definir escopos de API para OBO (On-Behalf-Of)
obo_api_scopes = [
    "serving.serving-endpoints",
    "dashboards.genie",
    "sql.warehouses",
    "sql.statement-execution",
]

print(f"\n✅ OBO API Scopes configurados:")
for scope in obo_api_scopes:
    print(f"   - {scope}")

# Criar política de autenticação combinada (OBO preferencial)
combined_auth_policy = AuthPolicy(
    system_auth_policy=SystemAuthPolicy(resources=system_resources),
    user_auth_policy=UserAuthPolicy(api_scopes=obo_api_scopes),
)

print(f"\n✅ AuthPolicy criada (OBO preferencial com fallback para Service Principal)")

# Definir variáveis de ambiente como fallback (Service Principal)
print(f"\n🔐 Configurando variáveis de ambiente como fallback...")
ENVIRONMENT_VARS = {
    "DATABRICKS_HOST": "https://adb-7534486785283121.1.azuredatabricks.net",
    "DATABRICKS_CLIENT_ID": "00436b36-c0ff-4536-96e8-99db69e9766a",
    "DATABRICKS_CLIENT_SECRET": "doseee883c82063cc1c754b76c14b6cc3c4e",
    "ENABLE_MLFLOW_TRACING": "true"
}

print(f"✅ Environment vars configuradas como fallback:")
for key in ENVIRONMENT_VARS.keys():
    print(f"   - {key}: {'✅' if key != 'DATABRICKS_CLIENT_SECRET' else '✅ *** (oculto)'}")

# Definir experimento
experiment_name = f"/Users/{workspace_client.current_user.me().user_name}/tax_chatbot_experiments"
mlflow.set_experiment(experiment_name)
print(f"\n✅ Experimento configurado: {experiment_name}")

with mlflow.start_run(run_name="tax_chatbot_model") as run:
    
    # Criar input e output examples para gerar signature
    input_example = pd.DataFrame({"question": [test_input],
                                  "session_id": ["test-session-id-12345"]})
    
    # Criar output example como DataFrame com tipos corretos (float para evitar warning)
    output_example = pd.DataFrame([{
        'answer': test_result['answer'],
        'prompt_tokens': float(test_result['prompt_tokens']),
        'completion_tokens': float(test_result['completion_tokens']),
        'total_tokens': float(test_result['total_tokens']),
        'session_id': 'test-session-id-12345'
    }])
    
    # Inferir signature com input e output
    signature = infer_signature(input_example, output_example)
    
    print(f"\n✅ Signature criada:")
    print(f"   Input: {signature.inputs}")
    print(f"   Output: {signature.outputs}")
    
    # Logar modelo com AuthPolicy (OBO) e recursos
    print(f"\n🔄 Logando modelo com AuthPolicy OBO...")
    model_info = mlflow.pyfunc.log_model(
        artifact_path="model",
        python_model="tax_chatbot_model.py",
        code_paths=["../config", "../agents", "../supervisor", "../memory", "../utils", "../core"],
        signature=signature,
        input_example=input_example,
        registered_model_name=MODEL_NAME,
        auth_policy=combined_auth_policy,
        streamable=False,
        pip_requirements=[
            "mlflow[databricks]==3.8.1",
            "databricks-langchain==0.13.0",
            "databricks-sdk==0.78.0",
            "langgraph==1.0.6",
            "langgraph-supervisor==0.0.31",
            "databricks-agents==1.9.2",
            "databricks-ai-bridge==0.12.0",
            "requests==2.32.5",
            "pandas"
        ]
    )
    
    # Logar parâmetros
    mlflow.log_params({
        "catalog": CATALOG,
        "schema": SCHEMA,
        "ix_table": IX_TABLE,
        "llm_endpoint": LLM_ENDPOINT,
        "genie_space_id": GENIE_SPACE_ID,
        "ka_endpoint": KA_ENDPOINT,
        "auth_strategy": "OBO_with_SP_fallback"
    })
    
    # Logar métricas do teste
    mlflow.log_metrics({
        'test_prompt_tokens': test_result['prompt_tokens'],
        'test_completion_tokens': test_result['completion_tokens'],
        'test_total_tokens': test_result['total_tokens']
    })
    
    print(f"\n✅ Modelo logado e registrado!")
    print(f"   Run ID: {run.info.run_id}")
    print(f"   Model URI: {model_info.model_uri}")
    print(f"   UC Model: {MODEL_NAME}")
    print(f"   Versão: {model_info.registered_model_version}")

# COMMAND ----------

# Obter versão registrada
registered_version = model_info.registered_model_version

print(f"\n✅ Modelo registrado: {MODEL_NAME}")
print(f"   Versão: {registered_version}")

# COMMAND ----------

# Criar ou atualizar Model Serving Endpoint

print(f"\n🚀 Gerenciando endpoint: {MODEL_ENDPOINT}")
print("="*60)

try:
    # Verificar se endpoint existe
    all_endpoints = list(workspace_client.serving_endpoints.list())
    
    endpoint_exists = False
    existing_endpoint = None
    
    for ep in all_endpoints:
        if ep.name == MODEL_ENDPOINT:
            endpoint_exists = True
            existing_endpoint = ep
            print(f"✅ Endpoint encontrado: {MODEL_ENDPOINT}")
            if ep.config and ep.config.served_entities:
                print(f"   Versão atual: {ep.config.served_entities[0].entity_version}")
            break
    
    if not endpoint_exists:
        print(f"❌ Endpoint '{MODEL_ENDPOINT}' não encontrado - será criado")
    
    # Configurar served entity
    served_entity = ServedEntityInput(
        entity_name=MODEL_NAME,
        entity_version=str(registered_version),
        workload_size="Small",
        scale_to_zero_enabled=False,
        environment_vars=ENVIRONMENT_VARS
    )
    
    print(f"\n🔄 Atualizando endpoint para versão {registered_version}...")
    
    # Atualizar ou criar endpoint
    if endpoint_exists:
        workspace_client.serving_endpoints.update_config(
            name=MODEL_ENDPOINT,
            served_entities=[served_entity]
        )
        print(f"✅ Comando de atualização enviado!")
    else:
        workspace_client.serving_endpoints.create(
            name=MODEL_ENDPOINT,
            config=EndpointCoreConfigInput(served_entities=[served_entity])
        )
        print(f"✅ Comando de criação enviado!")
    
    print(f"\n⏳ Endpoint está sendo atualizado em background (5-10 minutos)")
    print(f"   Verifique o status em: Serving > {MODEL_ENDPOINT}")
    
except Exception as e:
    print(f"\n❌ Erro ao gerenciar endpoint: {str(e)}")
    import traceback
    print(traceback.format_exc())

# COMMAND ----------

# Atualizar MODEL_VERSION no config/settings.py
settings_path = "../config/settings.py"

print(f"\n🔄 Atualizando MODEL_VERSION em {settings_path}...")

try:
    with open(settings_path, "r") as f:
        settings_content = f.read()
    
    if 'MODEL_VERSION' in settings_content:
        new_settings = re.sub(
            r'MODEL_VERSION\s*=\s*["\']?[^"\']*["\']?',
            f'MODEL_VERSION = "{registered_version}"',
            settings_content
        )
        
        with open(settings_path, "w") as f:
            f.write(new_settings)
        
        print(f"✅ config/settings.py atualizado com MODEL_VERSION = {registered_version}")
    else:
        print(f"⚠️  MODEL_VERSION não encontrado em {settings_path}")
        
except Exception as e:
    print(f"⚠️  Erro ao atualizar settings.py: {str(e)}")

# COMMAND ----------

# Testar modelo registrado
print(f"\n🧪 Testando modelo registrado...")

try:
    loaded_model = mlflow.pyfunc.load_model(f"models:/{MODEL_NAME}/{registered_version}")
    
    test_question = "Resuma o decreto 11491"
    test_session_id = "test-session-123"

    result = loaded_model.predict(pd.DataFrame({"question": [test_question],
                                                "session_id": [test_session_id]}))
    
    print(f"\n✅ Teste do modelo carregado:")
    print(f"Pergunta: {test_question}")
    print(f"Resposta: {result.iloc[0]['answer'][:200]}...")
    print(f"Métricas: prompt={result.iloc[0]['prompt_tokens']}, completion={result.iloc[0]['completion_tokens']}, total={result.iloc[0]['total_tokens']}")

    test_question2 = "Em que Estado esse decreto se aplica?"

    result2 = loaded_model.predict(pd.DataFrame({"question": [test_question2],
                                                "session_id": [test_session_id]}))
    
    print(f"\n✅ Teste do modelo carregado:")
    print(f"Pergunta: {test_question2}")
    print(f"Resposta: {result2.iloc[0]['answer'][:200]}...")
    print(f"Métricas: prompt={result2.iloc[0]['prompt_tokens']}, completion={result2.iloc[0]['completion_tokens']}, total={result2.iloc[0]['total_tokens']}")
    
except Exception as e:
    print(f"\n❌ Erro ao testar modelo: {str(e)}")
    import traceback
    print(traceback.format_exc())

# COMMAND ----------

# Resumo final
print("\n" + "="*60)
print("📋 RESUMO DO REGISTRO")
print("="*60)
print(f"✅ Modelo: {MODEL_NAME}")
print(f"✅ Versão: {registered_version}")
print(f"✅ Endpoint: {MODEL_ENDPOINT}")
print(f"✅ AuthPolicy: OBO (preferencial) + Service Principal (fallback)")
print(f"✅ System Resources: LLM, Genie Space, KA Endpoint")
print(f"\n🔗 Próximos passos:")
print(f"1. Aguarde 5-10 minutos para o endpoint atualizar")
print(f"2. Verifique status em: Serving > {MODEL_ENDPOINT}")
print(f"3. Teste via UI: {{'dataframe_records': [{{'question': 'O que é ICMS?'}}]}}")
print("="*60)
