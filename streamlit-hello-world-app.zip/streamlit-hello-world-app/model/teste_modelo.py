# Databricks notebook source
# %pip install -qq -r ../requirements.txt

# COMMAND ----------

# %restart_python

# COMMAND ----------

import sys
import os

# Adicionar pasta raiz ao Python path para importar módulos
root_path = os.path.abspath(os.path.join(os.getcwd(), '..'))
if root_path not in sys.path:
    sys.path.insert(0, root_path)

import mlflow
import pandas as pd
import time
from mlflow.models import infer_signature
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput
from config.settings import CATALOG, SCHEMA, IX_TABLE, GENIE_SPACE_ID, LLM_ENDPOINT, KA_ENDPOINT, MODEL_ENDPOINT

# Importar o modelo existente
from model.tax_chatbot_model import TaxChatbotModel, extract_response_and_metrics

# Testar se os componentes funcionam
from agents.ka_agent import KAAgent
from agents.agent_factory import agent_factory
from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent
from agents.base_agent import AgentConfig
from supervisor.multi_agent_supervisor import MultiAgentSupervisor

print("🔄 Testando componentes do modelo...")

# Registrar agentes no factory
# agent_factory.register("rag", RAGAgent)  # Comentado temporariamente
agent_factory.register("ka", KAAgent)
agent_factory.register("genie", GenieAgent)

# Criar WorkspaceClient
print("🔄 Criando WorkspaceClient...")
workspace_client = WorkspaceClient()

print(f"✅ WorkspaceClient criado")
print(f"   Host: {workspace_client.config.host}")
print(f"   Auth type: {workspace_client.config.auth_type}")

# Criar KAAgent
print(f"🔄 Criando KAAgent...")
print(f"   KA Endpoint: {KA_ENDPOINT}")

ka_agent = agent_factory.create(
    "ka",
    config=AgentConfig(
        name="query_ka",
        description="Consulta conteúdo de legislações"
    ),
    ka_endpoint=KA_ENDPOINT,
    workspace_client=workspace_client
)
print("✅ KAAgent criado")

# Criar GenieAgent
print(f"🔄 Criando GenieAgent...")
print(f"   Genie Space ID: {GENIE_SPACE_ID}")

genie_agent = agent_factory.create(
    "genie",
    config=AgentConfig(
        name="query_genie",
        description="Consultas quantitativas sobre legislações"
    ),
    genie_space_id=GENIE_SPACE_ID,
    workspace_client=workspace_client
)
print("✅ GenieAgent criado")

# Criar supervisor com AMBOS os agentes
print(f"🔄 Criando MultiAgentSupervisor...")
supervisor = MultiAgentSupervisor(
    agents=[ka_agent, genie_agent],
    llm_endpoint=LLM_ENDPOINT,
    workspace_client=workspace_client
)

print("✅ Componentes inicializados com sucesso!")

# Testar supervisor para gerar exemplo de saída
test_input = "resuma o decreto 11491"
print(f"\n🧪 Testando supervisor com: '{test_input}'")
test_response = supervisor.invoke(test_input)

test_result = extract_response_and_metrics(test_response)

# print(f"\n✅ Teste executado com sucesso!")
# print(f"Input: {test_input}")
# print(f"Output: {test_result['answer'][:200]}...")
# print(f"\n📊 Métricas:")
# print(f"   Prompt tokens: {test_result['prompt_tokens']}")
# print(f"   Completion tokens: {test_result['completion_tokens']}")
print(f"   Total tokens: {test_result['total_tokens']}")