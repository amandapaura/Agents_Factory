
import mlflow
import pandas as pd
import os
from typing import Optional
from databricks.sdk import WorkspaceClient
from config.settings import CATALOG, SCHEMA, IX_TABLE, GENIE_SPACE_ID, LLM_ENDPOINT, KA_ENDPOINT, SESSION_HISTORY_TABLE, SQL_WAREHOUSE_ID
from agents.agent_factory import agent_factory
from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent
from agents.base_agent import AgentConfig
from agents.ka_agent import KAAgent
from supervisor.multi_agent_supervisor import MultiAgentSupervisor
from memory.delta_session_manager import DeltaSessionManager
from memory.conversation_handler import ConversationHandler


def extract_response_and_metrics(response):
    """Função utilitária para extrair resposta e métricas de tokens."""
    messages = response.get("messages", [])
    
    # Procurar a última AIMessage com conteúdo não-vazio
    answer = None
    for msg in reversed(messages):
        msg_type = msg.__class__.__name__ if hasattr(msg, '__class__') else type(msg).__name__
        content = getattr(msg, 'content', '')
        
        # Procurar AIMessage com conteúdo não-vazio
        if msg_type == 'AIMessage' and content and content.strip():
            answer = content
            break
        
        # Fallback: Se não encontrar AIMessage, aceitar ToolMessage
        if not answer and msg_type == 'ToolMessage' and content and content.strip():
            answer = content
    
    # Coletar métricas de tokens
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_tokens = 0
    
    for msg in messages:
        if hasattr(msg, 'response_metadata'):
            usage = msg.response_metadata.get('usage', {})
            total_prompt_tokens += usage.get('prompt_tokens', 0)
            total_completion_tokens += usage.get('completion_tokens', 0)
            total_tokens += usage.get('total_tokens', 0)
    
    return {
        'answer': answer or "Sem resposta",
        'prompt_tokens': float(total_prompt_tokens),
        'completion_tokens': float(total_completion_tokens),
        'total_tokens': float(total_tokens)
    }


def create_workspace_client():
    """Cria WorkspaceClient com fallback inteligente."""
    has_client_id = bool(os.getenv('DATABRICKS_CLIENT_ID'))
    has_client_secret = bool(os.getenv('DATABRICKS_CLIENT_SECRET'))
    has_host = bool(os.getenv('DATABRICKS_HOST'))
    
    if has_client_id and has_client_secret and has_host:
        host = os.getenv('DATABRICKS_HOST')
        if not host.startswith('http'):
            host = f"https://{host}"
        
        return WorkspaceClient(
            host=host,
            client_id=os.getenv('DATABRICKS_CLIENT_ID'),
            client_secret=os.getenv('DATABRICKS_CLIENT_SECRET')
        )
    
    return WorkspaceClient()


class TaxChatbotModel(mlflow.pyfunc.PythonModel): # ResponseAgent
    def load_context(self, context):
        '''Inicializa configurações básicas e sistema de memória.'''
        print("🔄 TaxChatbotModel.load_context() chamado")
        
        # Registrar agentes
        if "ka" not in agent_factory._agents:
            agent_factory.register("ka", KAAgent)

        if "genie" not in agent_factory._agents:
            agent_factory.register("genie", GenieAgent)
        
        # ✅ MUDANÇA: Usar DeltaSessionManager com SQL Warehouse ID
        print(f"🔄 Inicializando DeltaSessionManager...")
        print(f"   Tabela: {SESSION_HISTORY_TABLE}")
        print(f"   Warehouse ID: {SQL_WAREHOUSE_ID}")
        
        self.session_manager = DeltaSessionManager(
            table_name=SESSION_HISTORY_TABLE,
            session_timeout_minutes=60,
            max_messages_per_session=20
        )
        
        print(f"✅ DeltaSessionManager criado: {self.session_manager}")
        print(f"   Sessões ativas no cache: {self.session_manager.get_active_sessions_count()}")
        
        self.conversation_handler = None
        self.supervisor = None
    
    def _initialize_supervisor(self, session_id: Optional[str] = None):
        '''Inicializa o supervisor com WorkspaceClient e memória.
        
        CORREÇÃO: Agora atualiza o session_id do supervisor existente
        ao invés de apenas criar uma vez.
        '''
        # Criar supervisor apenas na primeira vez
        if self.supervisor is None:
            print(f"🔄 Criando supervisor pela primeira vez com session_id={session_id}")
            
            workspace_client = create_workspace_client()
            
            ka_agent = agent_factory.create(
                "ka",
                config=AgentConfig(name="query_ka", description="Consulta conteúdo de legislações"),
                ka_endpoint=KA_ENDPOINT,
                workspace_client=workspace_client
            )
            
            genie_agent = agent_factory.create(
                "genie",
                config=AgentConfig(name="query_genie", description="Consultas quantitativas sobre legislações"),
                genie_space_id=GENIE_SPACE_ID,
                workspace_client=workspace_client
            )
            
            # Criar conversation handler (se ainda não existe)
            if self.conversation_handler is None:
                self.conversation_handler = ConversationHandler(
                    session_manager=self.session_manager,
                    llm_endpoint=LLM_ENDPOINT,
                    enable_metrics=True,
                    keep_last_n_turns=3  # ✅ Sempre mantém últimos 3 turnos
                )
                print(f"✅ ConversationHandler criado")
            
            # Criar supervisor com memória
            self.supervisor = MultiAgentSupervisor(
                agents=[ka_agent, genie_agent],
                llm_endpoint=LLM_ENDPOINT,
                workspace_client=workspace_client,
                conversation_handler=self.conversation_handler,
                session_id=session_id
            )
            print(f"✅ Supervisor criado com session_id={session_id}")
        else:
            # ✅ CORREÇÃO: Atualizar session_id do supervisor existente
            # Isso garante que cada chamada use o session_id correto
            print(f"🔄 Atualizando session_id do supervisor existente")
            print(f"   Anterior: {self.supervisor.session_id}")
            print(f"   Novo: {session_id}")
            
            if session_id:
                self.supervisor.session_id = session_id
                print(f"✅ Session ID atualizado para: {session_id}")
    
    def predict(self, context, model_input: pd.DataFrame) -> pd.DataFrame:
        '''Processa a pergunta do usuário com suporte a memória.'''
        try:
            # Extrair session_id do input (se fornecido)
            session_id = None
            if "session_id" in model_input.columns:
                session_id = str(model_input["session_id"].iloc[0])
            
            print(f"\n{'='*60}")
            print(f"🔵 PREDICT CHAMADO")
            print(f"{'='*60}")
            print(f"Session ID recebido: {session_id}")
            print(f"Sessões ativas no cache: {self.session_manager.get_active_sessions_count()}")
            
            # Se não tiver session_id, criar uma nova sessão
            if not session_id:
                session_id = self.session_manager.create_session()
                print(f"⚠️ Session ID não fornecido, criado novo: {session_id}")
            else:
                # ✅ CORREÇÃO: Garantir que a sessão existe no DeltaSessionManager
                # Se não existir no cache, tenta carregar do Delta
                # Se não existir no Delta, cria nova com o mesmo ID
                session = self.session_manager.get_session(session_id)
                if not session:
                    print(f"⚠️ Sessão {session_id[:8]}... não encontrada no cache ou Delta")
                    print(f"   Criando nova sessão com o mesmo ID...")
                    # Criar sessão com o ID fornecido pelo Streamlit
                    self.session_manager.create_session_with_id(session_id)
                    print(f"✅ Sessão criada com ID: {session_id[:8]}...")
                else:
                    print(f"✅ Sessão {session_id[:8]}... encontrada")
                    # Obter memória da sessão
                    memory = self.session_manager.get_memory(session_id)
                    if memory:
                        messages = memory.get_messages()
                        print(f"   Mensagens na memória: {len(messages)}")
                        for i, msg in enumerate(messages):
                            role = msg.get('role', 'unknown')
                            content_preview = msg.get('content', '')[:50]
                        
            
            # Inicializar/atualizar supervisor com session_id
            self._initialize_supervisor(session_id=session_id)
            
            if "question" not in model_input.columns:
                raise ValueError("DataFrame deve conter coluna 'question'")
            
            if model_input.empty:
                raise ValueError("DataFrame de input está vazio")
            
            question = str(model_input["question"].iloc[0])
            
            if not question.strip():
                raise ValueError("Pergunta não pode estar vazia")
            
            print(f"Pergunta: {question}")
            print(f"{'='*60}\n")
            
            # Invocar supervisor (que já gerencia a memória internamente)
            response = self.supervisor.invoke(question)
            result = extract_response_and_metrics(response)
            
            # Adicionar session_id ao resultado
            result['session_id'] = session_id
            
            print(f"\n{'='*60}")
            print(f"✅ PREDICT CONCLUÍDO")
            print(f"{'='*60}")
            print(f"Session ID retornado: {session_id[:8]}...")
            print(f"Resposta: {result['answer'][:100]}...")
            print(f"{'='*60}\n")
            
            return pd.DataFrame([result])
            
        except Exception as e:
            print(f"\n❌ ERRO NO PREDICT: {str(e)}")
            import traceback
            traceback.print_exc()
            
            return pd.DataFrame([{
                'answer': f"Erro ao processar pergunta: {str(e)}",
                'prompt_tokens': 0.0,
                'completion_tokens': 0.0,
                'total_tokens': 0.0,
                'session_id': session_id if 'session_id' in locals() else ''
            }])

# Registrar o modelo para code-based logging
mlflow.langchain.autolog()
mlflow.models.set_model(TaxChatbotModel())
