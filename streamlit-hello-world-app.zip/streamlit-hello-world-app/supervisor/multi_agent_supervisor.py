"""Orquestrador multi-agente usando LangGraph com suporte a memória."""

from typing import List, Dict, Any, Callable, Optional
from langchain.tools import tool
from databricks_langchain import ChatDatabricks
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph_supervisor import create_supervisor
from langgraph.prebuilt import create_react_agent
from databricks.sdk import WorkspaceClient

from agents.base_agent import BaseAgent


class MultiAgentSupervisor:
    """Supervisor que orquestra múltiplos agentes com suporte a memória."""
    
    def __init__(
        self,
        agents: List[BaseAgent],
        llm_endpoint: str,
        workspace_client: WorkspaceClient,
        conversation_handler: Optional[Any] = None,
        session_id: Optional[str] = None
    ):
        """Inicializa o supervisor multi-agente."""
        self.agents = {agent.name: agent for agent in agents}
        self.llm = ChatDatabricks(endpoint=llm_endpoint)
        self.workspace_client = workspace_client
        self.conversation_handler = conversation_handler
        self.session_id = session_id
        
        # Criar tools a partir dos agentes
        self.tools = self._create_tools_from_agents()
        
        # Criar supervisor LangGraph
        self.supervisor = self._create_supervisor()
    
    def _create_tools_from_agents(self) -> List:
        """Converte agentes em tools do LangGraph."""
        tools = []
        
        for agent_name, agent_instance in self.agents.items():
            def make_agent_tool(agent: BaseAgent) -> Callable:
                @tool
                def agent_tool(question: str) -> str:
                    """Executa o agente com a pergunta do usuário."""
                    return agent.execute(question)
                
                agent_tool.name = agent.name
                agent_tool.description = agent.description
                
                return agent_tool
            
            tools.append(make_agent_tool(agent_instance))
        
        return tools
    
    def _create_supervisor(self):
        """Cria o supervisor LangGraph."""
        react_agents = []
        for tool in self.tools:
            react_agent = create_react_agent(
                self.llm,
                tools=[tohttps://adb-7534486785283121.1.azuredatabricks.net/browse/folders/2192979528495477?o=7534486785283121$0ol],
                name=tool.name
            )
            react_agents.append(react_agent)
        
        prompt = self._build_supervisor_prompt()
        supervisor = create_supervisor(
            agents=react_agents,
            model=self.llm,
            prompt=prompt,
            add_handoff_messages=False,
            output_mode="full_history",
        )
        
        return supervisor.compile()
    
    def _build_supervisor_prompt(self) -> str:
        """Constrói o prompt do supervisor."""
        agent_descriptions = "\n".join([
            f"- {name}: {agent.description}"
            for name, agent in self.agents.items()
        ])
        
        return f"""Você é um supervisor multi-agente especializado em legislação tributária brasileira. 
        Sua tarefa é direcionar perguntas para o agente mais adequado e transmitir as respostas de forma clara.

        AGENTES DISPONÍVEIS:
        {agent_descriptions}

        REGRAS DE ROTEAMENTO:
        - Se as perguntas forem cumprimentos como "bom dia", "olá", "tudo bem", "boa tarde", "boa noite", "obrigado", "obrigada", "valeu", etc, apenas responda "Olá! Como posso ajudar?"
        - Perguntas QUANTITATIVAS (quantas, conte, liste, agrupe, total, soma) → Use query_genie
        - Perguntas de CONTEÚDO (o que é, o que diz, explique, qual valor, como funciona, artigo, resumo, decreto, lei) → Use query_ka
        - Se houver dúvida, priorize query_ka para questões sobre conteúdo de legislação

        IMPORTANTE SOBRE HISTÓRICO:
        - Você TEM ACESSO ao histórico da conversa nas mensagens anteriores
        - Use o histórico para entender perguntas de continuação (ex: "E legislações?" após perguntar sobre decretos)
        - Responda perguntas sobre o histórico quando solicitado (ex: "Qual foi minha primeira pergunta?")
        - Mantenha contexto entre turnos e faça referências cruzadas quando relevante

        REGRAS DE RESPOSTA:
        - Transmita a resposta do agente de forma completa e clara ao usuário
        - Mantenha formatação markdown (tabelas, listas, negrito) se presente na resposta
        - Quando conveniente, adicione bullet points para facilitar leitura
        - Não adicione comentários sobre qual agente foi usado, apenas apresente a resposta
        - Se o agente retornar erro, informe ao usuário de forma educada
        - Não responda nada fora do contexto do agente, caso tenha qualquer pergunta fora do assunto, educadamente diga que você é um especialista em legislação e que deve apenas responder questões sobre legislação tributária brasileira que se enquadrem na Valex
        - Se o agente retornar uma resposta vazia, peça para o usuário reformular a pergunta dele
        """
    
    def invoke(self, query: str) -> Dict[str, Any]:
        """
        Processa uma consulta através do supervisor com suporte a memória.
        
        Args:
            query: Pergunta do usuário
            
        Returns:
            Dicionário com mensagens e metadados
        """
        print(f"DEBUG: session_id = {self.session_id}")
        print(f"DEBUG: conversation_handler = {self.conversation_handler}")
        
        # PASSO 1: Obter histórico ANTES de adicionar a mensagem atual
        messages = []
        
        if self.conversation_handler and self.session_id:
            # Obter histórico (sem a pergunta atual ainda)
            history = self.conversation_handler.get_conversation_context(self.session_id)
            print(f"DEBUG: Histórico tem {len(history)} mensagens")
            print(f"DEBUG: Histórico: {history}")
            
            # Converter histórico para mensagens do LangChain
            if history:
                for msg in history:
                    if msg["role"] == "user":
                        messages.append(HumanMessage(content=msg["content"]))
                    elif msg["role"] == "assistant":
                        messages.append(AIMessage(content=msg["content"]))
                    elif msg["role"] == "system":
                        messages.append(SystemMessage(content=msg["content"]))
        
        # PASSO 2: Adicionar pergunta atual
        messages.append(HumanMessage(content=query))
        
        print(f"DEBUG: Total de mensagens enviadas ao LLM: {len(messages)}")
        
        try:
            # PASSO 3: Invocar supervisor LangGraph
            result = self.supervisor.invoke({"messages": messages})
            
            # PASSO 4: Adicionar mensagem do usuário à memória (DEPOIS de processar com sucesso)
            if self.conversation_handler and self.session_id:
                try:
                    self.conversation_handler.process_user_input(
                        session_id=self.session_id,
                        content=query
                    )
                except Exception as e:
                    print(f"⚠️ Erro ao salvar input do usuário na memória: {e}")
            
            # PASSO 5: Salvar resposta do assistente na memória
            if self.conversation_handler and self.session_id:
                try:
                    response_messages = result.get("messages", [])
                    for msg in reversed(response_messages):
                        if hasattr(msg, '__class__') and msg.__class__.__name__ == 'AIMessage':
                            content = getattr(msg, 'content', '')
                            if content and content.strip():
                                self.conversation_handler.process_agent_response(
                                    session_id=self.session_id,
                                    content=content,
                                    agent_name="supervisor"
                                )
                                break
                except Exception as e:
                    print(f"⚠️ Erro ao salvar resposta do assistente na memória: {e}")
            
            return result
            
        except Exception as e:
            # ✅ CORREÇÃO: Mesmo em caso de erro, tentar salvar a pergunta do usuário
            # para manter histórico consistente
            if self.conversation_handler and self.session_id:
                try:
                    self.conversation_handler.process_user_input(
                        session_id=self.session_id,
                        content=query
                    )
                    # Salvar mensagem de erro também
                    self.conversation_handler.process_agent_response(
                        session_id=self.session_id,
                        content=f"Erro ao processar: {str(e)}",
                        agent_name="supervisor"
                    )
                except Exception as mem_error:
                    print(f"⚠️ Erro ao salvar na memória após falha: {mem_error}")
            
            # Re-lançar exceção original
            raise
