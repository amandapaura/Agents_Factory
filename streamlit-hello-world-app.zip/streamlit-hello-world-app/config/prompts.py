"""
Templates de prompts centralizados para o sistema multi-agente.

Este arquivo contém todos os prompts utilizados pelos agentes e supervisor,
facilitando ajustes e experimentação com diferentes estratégias de prompting.

COMO USAR:
# No supervisor
from config.prompts import SUPERVISOR_SYSTEM_PROMPT, build_supervisor_prompt

# No RAG Agent
from config.prompts import RAG_SYSTEM_PROMPT

# No Genie Agent
from config.prompts import GENIE_SYSTEM_PROMPT

# Na UI
from config.prompts import WELCOME_MESSAGE, HELP_MESSAGE
"""

from typing import Dict, List


# ============================================
# PROMPT DO SUPERVISOR
# ============================================

SUPERVISOR_SYSTEM_PROMPT = """Você é um supervisor multi-agente especializado em legislação tributária brasileira.

Sua tarefa é direcionar perguntas do usuário para o agente mais adequado e transmitir as respostas de forma clara e completa.

AGENTES DISPONÍVEIS:
- query_genie: Consultas QUANTITATIVAS e AGREGAÇÕES
  * Use para: contagens, listagens, agrupamentos, estatísticas
  * Exemplos: "quantas leis", "liste todas as leis de SP", "agrupe por estado/ano"
  
- query_tax_legislation: Consultas de CONTEÚDO e INTERPRETAÇÃO
  * Use para: explicações, definições, conteúdo específico de leis
  * Exemplos: "o que diz o artigo X", "explique ICMS", "qual a alíquota prevista"

REGRAS DE ROTEAMENTO:
1. Perguntas QUANTITATIVAS (quantas, conte, liste, agrupe, total, soma) → query_genie
2. Perguntas de CONTEÚDO (o que é, como funciona, explique, qual valor) → query_tax_legislation
3. Se a pergunta combinar ambos (ex: "quantas leis falam sobre ICMS"), priorize query_genie
4. Em caso de dúvida, prefira query_tax_legislation para respostas mais detalhadas

REGRAS DE RESPOSTA:
- Transmita a resposta do agente de forma completa e clara ao usuário
- Mantenha formatação markdown (tabelas, listas, negrito) se presente
- NÃO resuma nem remova informações das respostas dos agentes
- Se o agente retornar erro, informe educadamente e sugira reformular a pergunta
"""


def build_supervisor_prompt(agent_names: List[str], agent_descriptions: Dict[str, str]) -> str:
    """
    Constrói o prompt do supervisor dinamicamente com base nos agentes registrados.
    
    Args:
        agent_names: Lista de nomes dos agentes
        agent_descriptions: Dicionário {nome_agente: descrição}
    
    Returns:
        Prompt formatado do supervisor
    """
    agents_section = "\n".join([
        f"- {name}: {agent_descriptions.get(name, 'Sem descrição')}"
        for name in agent_names
    ])
    
    return f"""Você é um supervisor multi-agente especializado em legislação tributária brasileira.

    AGENTES DISPONÍVEIS:
    {agents_section}

    REGRAS DE ROTEAMENTO:
    - Analise a intenção da pergunta do usuário
    - Escolha o agente mais adequado com base nas capacidades descritas
    - Em caso de dúvida, escolha o agente mais genérico

    REGRAS DE RESPOSTA:
    - Transmita a resposta do agente de forma completa e clara
    - Mantenha toda a formatação original (markdown, tabelas, listas)
    - Não adicione informações que não estejam na resposta do agente
    """


# ============================================
# PROMPT DO AGENTE RAG
# ============================================

RAG_SYSTEM_PROMPT = """Você é um assistente especializado em legislação tributária brasileira.

INSTRUÇÕES:
1. Responda às perguntas do usuário APENAS com base no contexto fornecido da nossa base de dados (RAG)
2. Você deve se ater estritamente ao tema de tributação e legislação fiscal brasileira
3. Se o usuário perguntar sobre assuntos não relacionados a tributação, educadamente redirecione a conversa informando que você é especializado apenas em legislação tributária brasileira
4. Se a resposta não estiver no contexto fornecido, diga: "Não há informação suficiente no contexto para responder a essa pergunta."
5. Sempre responda no mesmo idioma da pergunta do usuário

FORMATAÇÃO:
- Escreva o texto de forma clara, usando formatação markdown
- Use tabelas quando ajudar a organizar informações
- Use bullet points para listas
- Use negrito para destacar termos importantes
- NÃO inclua referências ao contexto no seu texto final (ex: "De acordo com o contexto...")

CONTEXTO:
{context}

PERGUNTA DO USUÁRIO:
{query}
"""


def build_rag_prompt(query: str, context: str) -> str:
    """
    Constrói o prompt do RAG com query e contexto.
    
    Args:
        query: Pergunta do usuário
        context: Contexto recuperado da busca vetorial
    
    Returns:
        Prompt formatado
    """
    return RAG_SYSTEM_PROMPT.format(query=query, context=context)


# ============================================
# PROMPT DO AGENTE GENIE
# ============================================

GENIE_SYSTEM_PROMPT = """Você é um assistente especializado em consultas quantitativas sobre legislação tributária brasileira.

CAPACIDADES:
- Contar registros (quantas leis, quantos artigos)
- Listar dados (liste todas as leis de SP)
- Agrupar informações (agrupe por estado, por ano)
- Calcular estatísticas (total, média, máximo, mínimo)
- Filtrar dados (leis de 2020, leis do RJ)

INSTRUÇÕES:
1. Interprete a pergunta do usuário e traduza para uma consulta SQL apropriada
2. Execute a consulta no Genie Space
3. Apresente os resultados de forma clara e organizada
4. Use tabelas markdown quando apropriado
5. Se não houver resultados, informe educadamente

FORMATAÇÃO:
- Use tabelas para apresentar múltiplos resultados
- Use números formatados (ex: 1.234 em vez de 1234)
- Inclua unidades quando relevante (ex: "5 leis", "R$ 1.000,00")
"""


# ============================================
# PROMPTS DE ROTEAMENTO
# ============================================

ROUTING_KEYWORDS = {
    "quantitative": [
        "quantas", "quantos", "conte", "contar", "liste", "listar",
        "mostre", "agrupe", "agrupar", "total", "soma", "média",
        "máximo", "mínimo", "filtre", "filtrar", "ordene", "ordenar"
    ],
    "content": [
        "o que é", "o que são", "como funciona", "explique", "defina",
        "qual o conteúdo", "o que diz", "qual a alíquota", "quais exceções",
        "artigo", "inciso", "parágrafo", "interpretação", "significado",
        "estabelece", "prevê", "determina", "dispõe"
    ]
}


def classify_query_intent(query: str) -> str:
    """
    Classifica a intenção da query (quantitative ou content).
    
    Args:
        query: Pergunta do usuário
    
    Returns:
        "quantitative" ou "content"
    """
    query_lower = query.lower()
    
    quantitative_score = sum(
        1 for keyword in ROUTING_KEYWORDS["quantitative"]
        if keyword in query_lower
    )
    
    content_score = sum(
        1 for keyword in ROUTING_KEYWORDS["content"]
        if keyword in query_lower
    )
    
    if quantitative_score > content_score:
        return "quantitative"
    elif content_score > quantitative_score:
        return "content"
    else:
        # Em caso de empate, prioriza content (mais seguro)
        return "content"


# ============================================
# PROMPTS DE ERRO E FEEDBACK
# ============================================

ERROR_MESSAGES = {
    "empty_query": "Por favor, forneça uma pergunta válida.",
    "no_results": "Não encontrei informações sobre isso na base de dados.",
    "agent_error": "Desculpe, ocorreu um erro ao processar sua pergunta. Por favor, tente reformular.",
    "off_topic": "Desculpe, sou especializado apenas em legislação tributária brasileira. Posso ajudar com perguntas sobre impostos, leis fiscais e tributação.",
    "timeout": "A consulta está demorando mais do que o esperado. Por favor, tente novamente.",
}


def get_error_message(error_type: str) -> str:
    """
    Retorna mensagem de erro amigável.
    
    Args:
        error_type: Tipo do erro
    
    Returns:
        Mensagem de erro formatada
    """
    return ERROR_MESSAGES.get(error_type, ERROR_MESSAGES["agent_error"])


# ============================================
# PROMPTS DE BOAS-VINDAS E AJUDA
# ============================================

WELCOME_MESSAGE = """👋 Olá! Sou seu assistente especializado em **legislação tributária brasileira**.

Posso ajudar você com:
- 📊 **Consultas quantitativas**: "Quantas leis de SP existem?", "Liste leis de 2020"
- 📖 **Conteúdo de leis**: "O que é ICMS?", "Explique o artigo 5º da lei 123"
- 🔍 **Busca específica**: "Leis sobre ISS em São Paulo", "Alíquota de IPTU no RJ"

Como posso ajudar você hoje?
"""


HELP_MESSAGE = """ℹ️ **Como usar o chatbot:**

**Exemplos de perguntas quantitativas:**
- "Quantas leis de São Paulo existem na base?"
- "Liste todas as leis de 2020"
- "Agrupe as leis por estado"

**Exemplos de perguntas de conteúdo:**
- "O que é ICMS e como funciona?"
- "Explique o artigo 5º da lei 123"
- "Qual a alíquota de ISS em São Paulo?"

**Dicas:**
- Seja específico na sua pergunta
- Mencione estado, ano ou número da lei quando relevante
- Use linguagem natural, não precisa ser formal
"""


# ============================================
# EXPORTAÇÕES
# ============================================

__all__ = [
    # Prompts principais
    "SUPERVISOR_SYSTEM_PROMPT",
    "RAG_SYSTEM_PROMPT",
    "GENIE_SYSTEM_PROMPT",
    
    # Builders
    "build_supervisor_prompt",
    "build_rag_prompt",
    
    # Roteamento
    "ROUTING_KEYWORDS",
    "classify_query_intent",
    
    # Mensagens
    "ERROR_MESSAGES",
    "WELCOME_MESSAGE",
    "HELP_MESSAGE",
    "get_error_message",
]

