"""
Configurações globais do projeto Tax Legislation Chatbot.

Este arquivo centraliza todas as constantes e configurações do sistema,
permitindo fácil manutenção e adaptação entre ambientes (notebook vs Streamlit).
"""

import os
from typing import Optional


# ============================================
# CONFIGURAÇÕES DE CATÁLOGO E TABELAS
# ============================================

CATALOG = "financefranchise"
SCHEMA = "tax_legislation"
IX_TABLE = "tax_legislation_idx_ka"  # Tabela de índice vetorial (Vector Search)
DELTA_TABLE = "tax_legislation"   # Tabela Delta com dados estruturados


# ============================================
# CONFIGURAÇÕES DO GENIE SPACE
# ============================================

GENIE_SPACE_ID = "01f0f79711e8177fbf6f3fb48a2d4e27"
GENIE_NAME = "[TAX] Legislation"
GENIE_DESCRIPTION = "Este agente responde perguntas sobre legislações tributárias"

# ============================================
# Knowledge Assistant ID
# ============================================
KA_ID = "5fe977da-da77-455a-925f-1a62fcdcbd04"
KA_NAME = "ka-tax-legislation"
KA_ENDPOINT = "ka-5fe977da-endpoint"
KA_DESCRIPTION = "Este agente responde perguntas sobre legislação"

# ============================================
# CONFIGURAÇÕES DE LLM
# ============================================

# Endpoint LLM que suporta tool calling
LLM_ENDPOINT = "databricks-claude-haiku-4-5"
LLM_EMBEDDING = "databricks-gte-large-en"

# Alternativas comentadas:
# LLM_ENDPOINT = "databricks-meta-llama-3-1-70b-instruct"
# LLM_ENDPOINT = "databricks-claude-sonnet-3-5"


# ============================================
# CONFIGURAÇÕES DO MODELO MLFLOW
# ============================================

# Nome do modelo registrado no MLflow 
MODEL_NAME = f"{CATALOG}.{SCHEMA}.tax_chatbot_model"

# Versão do modelo (atualizada automaticamente pelo register_model.py)
MODEL_VERSION = "60"  # Será atualizado automaticamente

MODEL_ENDPOINT = "tax_chatbot_endpoint"

# ============================================
# CONFIGURAÇÕES DE SQL WAREHOUSE
# ============================================

# SQL Warehouse para acesso via REST API (sem Spark)
SQL_WAREHOUSE_ID = "a713154e9cce1b06"  # Tax_Warehouse
SQL_WAREHOUSE_NAME = "Tax_Warehouse"

# ============================================
# AUTENTICAÇÃO OBO (ON-BEHALF-OF)
# ============================================

def get_user_workspace_client():
    """
    Tenta criar WorkspaceClient com OBO (On-Behalf-Of) usando token do usuário.
    
    OBO permite que o app execute com as credenciais do usuário logado,
    proporcionando auditoria e controle de acesso por usuário.
    
    Returns:
        WorkspaceClient autenticado como usuário, ou None se não disponível
    """
    try:
        # Tentar obter token OBO do header (Databricks Apps)
        import streamlit as st
        user_token = st.context.headers.get('x-forwarded-access-token')
        
        if user_token:
            host = os.getenv('DATABRICKS_HOST')
            if not host:
                print("⚠️  DATABRICKS_HOST não encontrado para OBO")
                return None
            
            # Adicionar https:// se necessário
            if not host.startswith('http'):
                host = f"https://{host}"
            
            # Criar cliente com token do usuário
            from databricks.sdk import WorkspaceClient
            client = WorkspaceClient(
                host=host,
                token=user_token
            )
            print("✅ WorkspaceClient criado com OBO (On-Behalf-Of)")
            return client
    except Exception as e:
        print(f"⚠️  OBO não disponível: {e}")
    
    return None


def get_workspace_client():
    """
    Obtém WorkspaceClient com fallback automático:
    1. Tenta OBO (On-Behalf-Of) - usa credenciais do usuário
    2. Fallback para Service Principal - usa credenciais do app
    3. Fallback para ambiente de notebook
    
    Returns:
        WorkspaceClient autenticado
    """
    # Tentar OBO primeiro (melhor para auditoria e segurança)
    obo_client = get_user_workspace_client()
    if obo_client:
        return obo_client
    
    # Fallback para Service Principal (Databricks Apps)
    from databricks.sdk import WorkspaceClient
    client_id = os.getenv('DATABRICKS_CLIENT_ID')
    client_secret = os.getenv('DATABRICKS_CLIENT_SECRET')
    host = os.getenv('DATABRICKS_HOST')
    
    if client_id and client_secret and host:
        print("⚠️  OBO não disponível, usando Service Principal")
        if not host.startswith('http'):
            host = f"https://{host}"
        return WorkspaceClient(
            host=host,
            client_id=client_id,
            client_secret=client_secret
        )
    
    # Fallback para ambiente de notebook (usa credenciais padrão)
    print("⚠️  Usando autenticação padrão (notebook)")
    return WorkspaceClient()


# ============================================
# CREDENCIAIS DATABRICKS
# ============================================

def get_databricks_host() -> str:
    """
    Obtém o host do Databricks.
    
    Prioridade:
    1. Variável de ambiente DATABRICKS_HOST (Databricks Apps)
    2. spark.conf (notebook)
    
    Returns:
        URL do workspace Databricks
    """
    # Primeiro tentar variável de ambiente (Databricks Apps)
    host = os.environ.get('DATABRICKS_HOST')
    if host:
        # Se não tiver https://, adicionar
        if not host.startswith('http'):
            host = f"https://{host}"
        return host
    
    # Fallback para Spark (notebook)
    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        workspace_url = spark.conf.get('spark.databricks.workspaceUrl')
        return f"https://{workspace_url}"
    except Exception as e:
        raise ValueError(
            f"DATABRICKS_HOST não encontrado. "
            f"Configure a variável de ambiente ou execute em um notebook. "
            f"Erro: {e}"
        )


def get_databricks_token() -> str:
    """
    Obtém o token de autenticação do Databricks.
    
    Prioridade:
    1. DATABRICKS_CLIENT_ID/SECRET (Databricks Apps - OAuth)
    2. DATABRICKS_TOKEN (PAT)
    3. dbutils (notebook)
    
    Returns:
        Token de autenticação ou None (para OAuth automático)
    """
    # Databricks Apps usa OAuth automático via CLIENT_ID/SECRET
    client_id = os.environ.get('DATABRICKS_CLIENT_ID')
    client_secret = os.environ.get('DATABRICKS_CLIENT_SECRET')
    
    if client_id and client_secret:
        # Databricks Apps: SDK detecta automaticamente
        # Não precisa retornar token explícito
        return None
    
    # Tentar PAT token
    token = os.environ.get('DATABRICKS_TOKEN')
    if token:
        return token
    
    # Fallback para dbutils (notebook)
    try:
        from databricks.sdk.runtime import dbutils
        token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        return token
    except Exception as e:
        raise ValueError(
            f"Credenciais não encontradas. "
            f"Configure DATABRICKS_TOKEN ou DATABRICKS_CLIENT_ID/SECRET. "
            f"Erro: {e}"
        )


# Inicializar credenciais (lazy loading)
_databricks_host: Optional[str] = None
_databricks_token: Optional[str] = None


def get_host() -> str:
    """Retorna o host do Databricks (cached)."""
    global _databricks_host
    if _databricks_host is None:
        _databricks_host = get_databricks_host()
    return _databricks_host


def get_token() -> str:
    """Retorna o token do Databricks (cached)."""
    global _databricks_token
    if _databricks_token is None:
        _databricks_token = get_databricks_token()
    return _databricks_token


# Aliases para compatibilidade
DATABRICKS_HOST = property(lambda self: get_host())
DATABRICKS_TOKEN = property(lambda self: get_token())


# ============================================
# CONFIGURAÇÕES DE MEMÓRIA E SESSÃO
# ============================================

# Número máximo de mensagens no histórico
MAX_HISTORY_LENGTH = 50

# TTL (Time To Live) de sessões em segundos (1 hora)
SESSION_TTL = 3600

# Backend de memória: "in_memory", "delta_table"
MEMORY_BACKEND = "delta_table"  # ✅ MUDADO para Delta Table

# Tabela Delta para persistir sessões e histórico
SESSION_HISTORY_TABLE = f"{CATALOG}.{SCHEMA}.tax_chatbot_session_history"

# Número de turnos recentes a manter intactos (antes de resumir)
KEEP_LAST_N_TURNS = 3

# Ativar resumo inteligente de conversação
ENABLE_SMART_SUMMARY = True


# ============================================
# CONFIGURAÇÕES DE ANALYTICS
# ============================================

# Ativar logging de analytics de conversação
ENABLE_ANALYTICS = True

# Tabelas para analytics de conversação
ANALYTICS_INTERACTIONS_TABLE = f"{CATALOG}.{SCHEMA}.tax_conversation_interactions"
ANALYTICS_EVENTS_TABLE = f"{CATALOG}.{SCHEMA}.tax_conversation_events"

# Configurações de batch para analytics
ANALYTICS_BATCH_ENABLED = True
ANALYTICS_BATCH_SIZE = 10

# Nível de log para analytics
ANALYTICS_LOG_LEVEL = "INFO"


# ============================================
# CONFIGURAÇÕES DE RAG
# ============================================

# Número de resultados da busca vetorial
RAG_NUM_RESULTS = 3

# Tamanho mínimo para merge de chunks
RAG_MIN_CHUNK_LENGTH = 300

# Colunas a retornar da busca vetorial
RAG_RETURN_COLUMNS = None  # None = todas as colunas


# ============================================
# CONFIGURAÇÕES DE LOGGING
# ============================================

# Nível de log: "DEBUG", "INFO", "WARNING", "ERROR"
LOG_LEVEL = "INFO"

# Formato do log
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


# ============================================
# CONFIGURAÇÕES DE UI (STREAMLIT)
# ============================================

# Título da aplicação
APP_TITLE = "Chatbot de Legislação Tributária"

# Descrição da aplicação
APP_DESCRIPTION = """
Assistente inteligente especializado em legislação tributária brasileira.
Faça perguntas sobre leis, impostos, alíquotas e muito mais!
"""

# Tema de cores
PRIMARY_COLOR = "#1E88E5"
SECONDARY_COLOR = "#FFC107"


# ============================================
# FUNÇÕES AUXILIARES
# ============================================

def get_full_table_name(table: str) -> str:
    """
    Retorna o nome completo da tabela (catalog.schema.table).
    
    Args:
        table: Nome da tabela (IX_TABLE ou DELTA_TABLE)
    
    Returns:
        Nome completo qualificado
    """
    return f"{CATALOG}.{SCHEMA}.{table}"


def print_config() -> None:
    """Imprime todas as configurações (útil para debug)."""
    print("=" * 60)
    print("CONFIGURAÇÕES DO SISTEMA")
    print("=" * 60)
    print(f"Catálogo: {CATALOG}")
    print(f"Schema: {SCHEMA}")
    print(f"Tabela Índice: {IX_TABLE}")
    print(f"Tabela Delta: {DELTA_TABLE}")
    print(f"Tabela Sessões: {SESSION_HISTORY_TABLE}")
    print(f"SQL Warehouse: {SQL_WAREHOUSE_NAME} ({SQL_WAREHOUSE_ID})")
    print(f"Genie Space ID: {GENIE_SPACE_ID}")
    print(f"LLM Endpoint: {LLM_ENDPOINT}")
    print(f"Memory Backend: {MEMORY_BACKEND}")
    print(f"Host: {get_host()}")
    print(f"Token: {'*' * 20} (oculto)")
    print("=" * 60)


# ============================================
# VALIDAÇÃO DE CONFIGURAÇÕES
# ============================================

def validate_config() -> bool:
    """
    Valida se todas as configurações obrigatórias estão presentes.
    
    Returns:
        True se válido, False caso contrário
    """
    required_configs = {
        "CATALOG": CATALOG,
        "SCHEMA": SCHEMA,
        "IX_TABLE": IX_TABLE,
        "GENIE_SPACE_ID": GENIE_SPACE_ID,
        "LLM_ENDPOINT": LLM_ENDPOINT,
        "SQL_WAREHOUSE_ID": SQL_WAREHOUSE_ID,
    }
    
    missing = [key for key, value in required_configs.items() if not value]
    
    if missing:
        print(f"❌ Configurações faltando: {', '.join(missing)}")
        return False
    
    try:
        get_host()
        get_token()
    except ValueError as e:
        print(f"❌ Erro nas credenciais: {e}")
        return False
    
    print("✅ Todas as configurações estão válidas!")
    return True


# ============================================
# EXPORTAÇÕES
# ============================================

__all__ = [
    # Catálogo e Tabelas
    "CATALOG",
    "SCHEMA",
    "IX_TABLE",
    "DELTA_TABLE",
    "SESSION_HISTORY_TABLE",
    
    # SQL Warehouse
    "SQL_WAREHOUSE_ID",
    "SQL_WAREHOUSE_NAME",
    
    # Genie
    "GENIE_SPACE_ID",
    "GENIE_NAME",
    "GENIE_DESCRIPTION",
    
    # LLM
    "LLM_ENDPOINT",
    
    # Modelo
    "MODEL_NAME",
    "MODEL_VERSION",
    
    # Autenticação
    "get_workspace_client",
    "get_user_workspace_client",
    "get_host",
    "get_token",
    
    # Memória
    "MAX_HISTORY_LENGTH",
    "SESSION_TTL",
    "MEMORY_BACKEND",
    "KEEP_LAST_N_TURNS",
    "ENABLE_SMART_SUMMARY",
    
    # Analytics
    "ENABLE_ANALYTICS",
    "ANALYTICS_INTERACTIONS_TABLE",
    "ANALYTICS_EVENTS_TABLE",
    "ANALYTICS_BATCH_ENABLED",
    "ANALYTICS_BATCH_SIZE",
    "ANALYTICS_LOG_LEVEL",
    
    # RAG
    "RAG_NUM_RESULTS",
    "RAG_MIN_CHUNK_LENGTH",
    "RAG_RETURN_COLUMNS",
    
    # Logging
    "LOG_LEVEL",
    "LOG_FORMAT",
    
    # UI
    "APP_TITLE",
    "APP_DESCRIPTION",
    "PRIMARY_COLOR",
    "SECONDARY_COLOR",
    
    # Funções
    "get_full_table_name",
    "print_config",
    "validate_config",
]
