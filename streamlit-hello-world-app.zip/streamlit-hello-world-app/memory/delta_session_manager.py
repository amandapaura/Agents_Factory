"""Gerenciamento de sessões com persistência em Delta Table."""

from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, BooleanType
import uuid
import json
import time
from .conversation_memory import ConversationMemory


class DeltaSessionManager:
    """Gerencia sessões de usuário com persistência em Delta Table.
    
    Diferente do SessionManager em memória, este persiste as sessões
    em uma tabela Delta no Unity Catalog, permitindo que as sessões
    sobrevivam a reinicializações do container/modelo.
    
    Estratégia:
    - Session ID é criado apenas quando o app é aberto/recarregado
    - Limpar histórico NÃO muda o session_id
    - Sessões são persistidas no Delta Table
    """
    
    def __init__(
        self, 
        table_name: str,
        session_timeout_minutes: int = 60,
        max_messages_per_session: int = 20
    ):
        """Inicializa o gerenciador de sessões com Delta Table.
        
        Args:
            table_name: Nome completo da tabela Delta (catalog.schema.table)
            session_timeout_minutes: Tempo em minutos para expirar sessões inativas
            max_messages_per_session: Número máximo de mensagens por sessão
        """
        self.table_name = table_name
        self.session_timeout = timedelta(minutes=session_timeout_minutes)
        self.max_messages_per_session = max_messages_per_session
        
        # Cache em memória para performance
        self._cache: Dict[str, Dict[str, Any]] = {}
        
        # Inicializar tabela Delta
        self._ensure_table_exists()
    
    
    def _ensure_table_exists(self):
        """Garante que a tabela Delta existe, criando se necessário."""
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {self.table_name} (
            session_id STRING NOT NULL,
            user_id STRING,
            messages STRING,
            created_at TIMESTAMP,
            last_activity TIMESTAMP,
            metadata STRING,
            is_active BOOLEAN,
            ended_at TIMESTAMP
        ) USING DELTA
        TBLPROPERTIES (
            'delta.enableChangeDataFeed' = 'true',
            'delta.columnMapping.mode' = 'name'
        )
        """
        
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            spark.sql(create_table_sql)
            print(f"✅ Tabela {self.table_name} pronta (via Spark)")
        except Exception as e:
            print(f"⚠️ Erro ao criar tabela via Spark: {e}")
        
    
    def create_session(
        self, 
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Cria uma nova sessão."""
        session_id = str(uuid.uuid4())
        return self.create_session_with_id(session_id, user_id, metadata)
    
    def create_session_with_id(
        self,
        session_id: str,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Cria uma nova sessão com um ID específico."""
        # Se já existe no cache, atualizar
        if session_id in self._cache:
            self._cache[session_id]["last_activity"] = datetime.now()
            self._save_session_to_delta(session_id)
            print(f"✅ Sessão {session_id[:8]}... já existe no cache")
            return session_id
        
        # Tentar carregar do Delta
        existing_session = self._load_session_from_delta(session_id)
        if existing_session:
            self._cache[session_id] = existing_session
            self._cache[session_id]["last_activity"] = datetime.now()
            self._save_session_to_delta(session_id)
            print(f"✅ Sessão {session_id[:8]}... carregada do Delta")
            return session_id
        
        # Criar nova sessão
        now = datetime.now()
        session_data = {
            "session_id": session_id,
            "user_id": user_id or f"user_{uuid.uuid4().hex[:8]}",
            "memory": ConversationMemory(max_messages=self.max_messages_per_session),
            "created_at": now,
            "last_activity": now,
            "metadata": metadata or {},
            "is_active": True
        }
        
        self._cache[session_id] = session_data
        self._save_session_to_delta(session_id)
        
        print(f"✅ Nova sessão criada: {session_id[:8]}...")
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Recupera uma sessão pelo ID."""
        # Tentar cache primeiro
        
        # Carregar do Delta
        session = self._load_session_from_delta(session_id)
        if session:
            self._cache[session_id] = session
        
        if not session:
            return None
        
        # Verificar expiração
        if self._is_session_expired(session):
            self.end_session(session_id)
            return None
        
        session["last_activity"] = datetime.now()
        return session
    
    def get_memory(self, session_id: str) -> Optional[ConversationMemory]:
        """Recupera a memória de conversação de uma sessão."""
        session = self.get_session(session_id)
        return session["memory"] if session else None
    
    def end_session(self, session_id: str) -> bool:
        """Encerra uma sessão."""
        if session_id in self._cache:
            self._cache[session_id]["is_active"] = False
            self._cache[session_id]["ended_at"] = datetime.now()
            self._save_session_to_delta(session_id)
            del self._cache[session_id]
            print(f"✅ Sessão {session_id[:8]}... encerrada")
            return True
        return False
    
    def _is_session_expired(self, session: Dict[str, Any]) -> bool:
        """Verifica se uma sessão expirou."""
        last_activity = session.get("last_activity", session.get("created_at"))
        return datetime.now() - last_activity > self.session_timeout
    
    def _save_session_to_delta(self, session_id: str):
        """Salva uma sessão no Delta Table via Spark."""
        if session_id not in self._cache:
            return

        try:
            from pyspark.sql import SparkSession
            from pyspark.sql.types import StructType, StructField, StringType, TimestampType, BooleanType
            
            spark = SparkSession.builder.getOrCreate()
            session = self._cache[session_id]
            
            # Serializar dados
            messages_json = json.dumps(session["memory"].to_dict())
            metadata_json = json.dumps(session["metadata"])
            
            schema = StructType([
                StructField("session_id", StringType(), False),
                StructField("user_id", StringType(), True),
                StructField("messages", StringType(), True),
                StructField("created_at", TimestampType(), True),
                StructField("last_activity", TimestampType(), True),
                StructField("metadata", StringType(), True),
                StructField("is_active", BooleanType(), True),
                StructField("ended_at", TimestampType(), True)
            ])

            # Preparar dados para MERGE
            data = [{
                "session_id": session["session_id"],
                "user_id": session["user_id"],
                "messages": messages_json,
                "created_at": session["created_at"],
                "last_activity": session["last_activity"],
                "metadata": metadata_json,
                "is_active": session.get("is_active", True),
                "ended_at": session.get("ended_at")
            }]
            
            # Criar DataFrame e fazer MERGE
            df = spark.createDataFrame(data, schema=schema)
            df.createOrReplaceTempView("session_updates")
            
            spark.sql(f"""
                MERGE INTO {self.table_name} AS target
                USING session_updates AS source
                ON target.session_id = source.session_id
                WHEN MATCHED THEN UPDATE SET *
                WHEN NOT MATCHED THEN INSERT *
            """)
            
            print(f"✅ Sessão {session_id[:8]}... salva no Delta")
            
        except Exception as e:
            print(f"❌ Erro ao salvar sessão no Delta: {e}")
            import traceback
            traceback.print_exc()
    
    
    def _load_session_from_delta(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Carrega uma sessão do Delta Table via Spark."""
        
        print(f"🔍 Carregando sessão {session_id[:8]}... do Delta")
        
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            df = spark.sql(f"""
                SELECT * FROM {self.table_name}
                WHERE session_id = '{session_id}'
                AND is_active = true
                LIMIT 1
            """)
            
            rows = df.collect()
            
            if not rows:
                print(f"   ❌ Sessão não encontrada no Delta")
                return None
            
            row = rows[0]
            
            # Deserializar mensagens
            messages_dict = json.loads(row.messages) if row.messages else {
                "messages": [], 
                "metadata": {}, 
                "config": {}
            }
            memory = ConversationMemory.from_dict(messages_dict)
            metadata = json.loads(row.metadata) if row.metadata else {}
            
            session_data = {
                "session_id": row.session_id,
                "user_id": row.user_id,
                "memory": memory,
                "created_at": row.created_at,
                "last_activity": row.last_activity,
                "metadata": metadata,
                "is_active": row.is_active
            }
            
            if row.ended_at:
                session_data["ended_at"] = row.ended_at
            
            print(f"   ✅ Sessão carregada: {len(memory.get_messages())} mensagens")
            
            return session_data
            
        except Exception as e:
            print(f"   ❌ Erro ao carregar sessão: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_active_sessions_count(self) -> int:
        """Retorna o número de sessões ativas no cache."""
        return len(self._cache)
    
    def cleanup_expired_sessions(self) -> int:
        """Remove sessões expiradas do cache."""
        expired_sessions = [
            sid for sid, session in self._cache.items()
            if self._is_session_expired(session)
        ]
        
        for session_id in expired_sessions:
            self.end_session(session_id)
        
        return len(expired_sessions)
    
