"""Orquestrador de conversações com integração de analytics e resumo inteligente."""

from typing import Dict, Any, Optional, List
from datetime import datetime
from databricks_langchain import ChatDatabricks
from .delta_session_manager import DeltaSessionManager
from .conversation_memory import ConversationMemory


class ConversationHandler:
    """Gerencia o fluxo de conversação com analytics e resumo inteligente.
    
    Estratégia de economia de tokens:
    - SEMPRE mantém 7 mensagens: 1 RESUMO acumulativo + últimos 3 turnos (6 mensagens)
    - A partir do 4º turno: cria/atualiza resumo com TODO o contexto antigo
    - Resumo é ACUMULATIVO: inclui resumo anterior + mensagens antigas
    """
    
    def __init__(
        self, 
        session_manager: DeltaSessionManager,
        llm_endpoint: str,
        analytics_logger: Optional[Any] = None,
        enable_metrics: bool = True,
        keep_last_n_turns: int = 3
    ):
        """Inicializa o handler de conversação.
        
        Args:
            session_manager: Instância do DeltaSessionManager
            llm_endpoint: Endpoint do LLM para fazer resumos
            analytics_logger: Logger de analytics (opcional)
            enable_metrics: Se True, coleta métricas de performance
            keep_last_n_turns: Quantos turnos recentes manter intactos (padrão: 3)
        """
        self.session_manager = session_manager
        self.llm = ChatDatabricks(endpoint=llm_endpoint)
        self.analytics = analytics_logger
        self.enable_metrics = enable_metrics
        self.keep_last_n_turns = keep_last_n_turns
        self._interaction_count = 0
    
    def process_user_input(
        self,
        session_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Processa e armazena input do usuário, com resumo inteligente.
        
        Args:
            session_id: ID da sessão
            content: Conteúdo da mensagem do usuário
            metadata: Metadados adicionais
            
        Returns:
            True se processado com sucesso
        """
        try:
            memory = self.session_manager.get_memory(session_id)
            if not memory:
                raise ValueError(f"Session {session_id} not found or expired")
            
            # Enriquecer metadados
            enriched_metadata = self._enrich_metadata(metadata, role="user")
            
            # Adicionar mensagem à memória
            memory.add_user_message(content, metadata=enriched_metadata)

            self.session_manager._save_session_to_delta(session_id)
            
            # Verificar se precisa resumir (após adicionar a mensagem)
            self._check_and_summarize(session_id, memory)
            
            # Log analytics
            if self.analytics:
                self.analytics.log_interaction(
                    session_id=session_id,
                    role="user",
                    content=content,
                    metadata=enriched_metadata
                )
            
            self._interaction_count += 1
            return True
            
        except Exception:
            return False
    
    def _check_and_summarize(self, session_id: str, memory: ConversationMemory) -> None:
        """Verifica se precisa resumir e mantém estrutura: [RESUMO] + últimos 3 turnos.
        
        Estratégia:
        - Conta turnos completos (user + assistant)
        - Se > 3 turnos: resume tudo exceto últimos 3 turnos
        - Resumo é ACUMULATIVO: inclui resumo anterior (se existir) + mensagens antigas
        - Resultado: SEMPRE 7 mensagens (1 resumo + 6 mensagens)
        
        Args:
            session_id: ID da sessão
            memory: Instância da memória da sessão
        """
        messages = list(memory._messages)
        
        # Separar mensagens por tipo
        system_messages = [msg for msg in messages if msg["role"] == "system"]
        user_assistant_messages = [msg for msg in messages if msg["role"] in ["user", "assistant"]]
        
        # Calcular número de turnos (cada turno = 1 user + 1 assistant)
        total_turns = len(user_assistant_messages) // 2
        
        # Se tiver mais que keep_last_n_turns, resumir
        if total_turns > self.keep_last_n_turns:
            self._summarize_keeping_last_n_turns(memory, system_messages, user_assistant_messages)
    
    def _summarize_keeping_last_n_turns(
        self, 
        memory: ConversationMemory,
        system_messages: List[Dict[str, Any]],
        user_assistant_messages: List[Dict[str, Any]]
    ) -> None:
        """Resume mensagens antigas mantendo os últimos N turnos intactos.
        
        Resumo é ACUMULATIVO:
        - Se já existe resumo anterior: inclui ele + mensagens antigas no novo resumo
        - Se não existe: resume apenas as mensagens antigas
        - Resultado: 1 RESUMO (acumulativo) + últimos 3 turnos (6 mensagens) = 7 mensagens
        
        Args:
            memory: Instância da memória
            system_messages: Lista de mensagens de sistema (resumos anteriores)
            user_assistant_messages: Lista de mensagens user/assistant
        """
        # Calcular quantas mensagens manter (últimos N turnos = N*2 mensagens)
        messages_to_keep = self.keep_last_n_turns * 2  
        
        # Separar mensagens antigas das recentes
        old_messages = user_assistant_messages[:-messages_to_keep]
        recent_messages = user_assistant_messages[-messages_to_keep:]
        
        # Verificar se já existe resumo anterior
        previous_summary = None
        if system_messages:
            # Pegar o resumo mais recente (último system message)
            for msg in reversed(system_messages):
                if msg.get("metadata", {}).get("type") == "summary":
                    previous_summary = msg["content"]
                    break
        
        # Construir texto para resumo
        if previous_summary:
            # RESUMO ACUMULATIVO: inclui resumo anterior + mensagens antigas
            conversation_text = f"""RESUMO ANTERIOR:
            {previous_summary}

            NOVAS MENSAGENS A ADICIONAR AO RESUMO:
            {self._format_messages_for_summary(old_messages)}"""
        else:
            # Primeiro resumo: apenas mensagens antigas
            conversation_text = self._format_messages_for_summary(old_messages)
        
        summary_prompt = f"""Você é um assistente especializado em resumir conversas sobre legislação tributária.

        Resuma a conversa abaixo de forma CONCISA mas mantendo informações importantes:
        - Principais perguntas do usuário
        - Principais respostas fornecidas  
        - Contexto relevante para perguntas futuras
        - Se houver resumo anterior, INTEGRE as novas informações ao contexto existente

        Seja BREVE (máximo 200 palavras). Foque no essencial.

        CONVERSA:
        {conversation_text}

        RESUMO CONCISO E ACUMULATIVO:"""
        
        try:
            # Chamar LLM para resumo
            response = self.llm.invoke(summary_prompt)
            summary = response.content if hasattr(response, 'content') else str(response)
            
            # Reconstruir memória: [RESUMO NOVO] + últimos N turnos
            memory._messages.clear()
            
            # Adicionar resumo ACUMULATIVO como mensagem do sistema
            total_summarized = len(old_messages) + (len(system_messages) if system_messages else 0)
            memory.add_system_message(
                f"Histórico anterior resumido: {summary}",
                metadata={
                    "type": "summary", 
                    "summarized_count": total_summarized,
                    "timestamp": datetime.now().isoformat(),
                    "is_cumulative": bool(previous_summary)
                }
            )
            
            # Re-adicionar últimos N turnos (6 mensagens)
            for msg in recent_messages:
                memory._messages.append(msg)
            
            # Resultado: 1 resumo + 6 mensagens = 7 mensagens SEMPRE
            
        except Exception:
            # Se falhar o resumo, não fazer nada (manter mensagens originais)
            pass
    
    def _format_messages_for_summary(self, messages: List[Dict[str, Any]]) -> str:
        """Formata mensagens para o prompt de resumo."""
        formatted = []
        for msg in messages:
            role = "USUÁRIO" if msg["role"] == "user" else "ASSISTENTE"
            content = msg["content"][:400]  # Limitar tamanho
            formatted.append(f"{role}: {content}")
        
        return "\n\n".join(formatted)
    
    def process_agent_response(
        self,
        session_id: str,
        content: str,
        agent_name: str,
        metrics: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Processa e armazena resposta do agente."""
        try:
            memory = self.session_manager.get_memory(session_id)
            if not memory:
                raise ValueError(f"Session {session_id} not found or expired")
            
            enriched_metadata = self._enrich_metadata(metadata, role="assistant")
            enriched_metadata["agent"] = agent_name
            
            if self.enable_metrics and metrics:
                enriched_metadata["metrics"] = metrics
            
            memory.add_assistant_message(
                content=content,
                agent_name=agent_name,
                metadata=enriched_metadata
            )
            
            self.session_manager._save_session_to_delta(session_id)
            
            if self.analytics:
                self.analytics.log_interaction(
                    session_id=session_id,
                    role="assistant",
                    content=content,
                    metadata=enriched_metadata
                )
            
            self._interaction_count += 1
            return True
            
        except Exception:
            return False
    
    def get_conversation_context(
        self,
        session_id: str,
        limit: Optional[int] = None
    ) -> List[Dict[str, str]]:
        """Recupera o contexto da conversação formatado para LLM."""
        memory = self.session_manager.get_memory(session_id)
        if not memory:
            print(f"⚠️ Nenhuma memória encontrada para session {session_id[:8]}...")
            return []
        
        # 2. Obter mensagens da memória
        messages = memory.get_messages(limit=limit, include_metadata=False)
        
        return messages
    
    
    def _enrich_metadata(
        self,
        metadata: Optional[Dict[str, Any]],
        role: str
    ) -> Dict[str, Any]:
        """Enriquece metadados com informações adicionais."""
        enriched = metadata.copy() if metadata else {}
        enriched.update({
            "timestamp": datetime.now().isoformat(),
            "role": role,
            "interaction_number": self._interaction_count
        })
        return enriched
