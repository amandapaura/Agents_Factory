"""Gerenciamento de histórico de conversação para contexto multi-turno."""

from typing import List, Dict, Any, Optional
from datetime import datetime
from collections import deque


class ConversationMemory:
    """Gerencia o histórico de mensagens de uma conversação.
    
    Mantém um buffer de mensagens com limite configurável para evitar
    crescimento ilimitado e custos excessivos de tokens.
    """
    
    def __init__(self, max_messages: int = 20, max_tokens: Optional[int] = None):
        """Inicializa o gerenciador de memória.
        
        Args:
            max_messages: Número máximo de mensagens a manter no histórico
            max_tokens: Limite opcional de tokens (não implementado ainda)
        """
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        self._messages: deque = deque(maxlen=max_messages)
        self._metadata: Dict[str, Any] = {
            "created_at": datetime.now().isoformat(),
            "message_count": 0
        }
    
    def add_message(
        self, 
        role: str, 
        content: str, 
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Adiciona uma mensagem ao histórico.
        
        Args:
            role: Papel da mensagem ('user', 'assistant', 'system')
            content: Conteúdo da mensagem
            metadata: Metadados adicionais (agente usado, timestamp, etc.)
        """
        if not content or not isinstance(content, str):
            raise ValueError("Content must be a non-empty string")
        
        if role not in ["user", "assistant", "system"]:
            raise ValueError(f"Invalid role: {role}. Must be 'user', 'assistant', or 'system'")
        
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        self._messages.append(message)
        self._metadata["message_count"] += 1
        self._metadata["last_updated"] = datetime.now().isoformat()
    
    def add_user_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Atalho para adicionar mensagem do usuário."""
        self.add_message("user", content, metadata)
    
    def add_assistant_message(
        self, 
        content: str, 
        agent_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Atalho para adicionar mensagem do assistente.
        
        Args:
            content: Resposta do assistente
            agent_name: Nome do agente que gerou a resposta
            metadata: Metadados adicionais
        """
        meta = metadata or {}
        if agent_name:
            meta["agent"] = agent_name
        self.add_message("assistant", content, meta)
    
    def add_system_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Atalho para adicionar mensagem do sistema."""
        self.add_message("system", content, metadata)
    
    def get_messages(
        self, 
        limit: Optional[int] = None,
        include_metadata: bool = False
    ) -> List[Dict[str, Any]]:
        """Retorna o histórico de mensagens.
        
        Args:
            limit: Número máximo de mensagens a retornar (None = todas)
            include_metadata: Se True, inclui timestamp e metadata
            
        Returns:
            Lista de mensagens no formato [{"role": "user", "content": "..."}]
        """
        messages = list(self._messages)
        
        if limit:
            messages = messages[-limit:]
        
        if not include_metadata:
            # Retornar apenas role e content (formato padrão para LLMs)
            return [
                {"role": msg["role"], "content": msg["content"]}
                for msg in messages
            ]
        
        return messages
    
    def get_context_for_llm(self, limit: Optional[int] = None) -> List[Dict[str, str]]:
        """Retorna mensagens formatadas para envio ao LLM.
        
        Args:
            limit: Número de mensagens recentes a incluir
            
        Returns:
            Lista no formato [{"role": "user", "content": "..."}, ...]
        """
        return self.get_messages(limit=limit, include_metadata=False)

    def get_summary(self) -> Dict[str, Any]:
        """Retorna resumo do estado da memória."""
        return {
            "total_messages": len(self._messages),
            "max_capacity": self.max_messages,
            "total_processed": self._metadata.get("message_count", 0),
            "created_at": self._metadata.get("created_at"),
            "last_updated": self._metadata.get("last_updated")
        }

    def clear(self) -> None:
        """Limpa todo o histórico de mensagens."""
        self._messages.clear()
        self._metadata["message_count"] = 0
        self._metadata["cleared_at"] = datetime.now().isoformat()
    
       
    def to_dict(self) -> Dict[str, Any]:
        """Serializa a memória para dicionário (útil para persistência)."""
        return {
            "messages": list(self._messages),
            "metadata": self._metadata,
            "config": {
                "max_messages": self.max_messages,
                "max_tokens": self.max_tokens
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationMemory":
        """Reconstrói a memória a partir de um dicionário."""
        config = data.get("config", {})
        memory = cls(
            max_messages=config.get("max_messages", 20),
            max_tokens=config.get("max_tokens")
        )
        
        # Restaurar mensagens
        for msg in data.get("messages", []):
            memory._messages.append(msg)
        
        # Restaurar metadata
        memory._metadata = data.get("metadata", memory._metadata)
        
        return memory
    