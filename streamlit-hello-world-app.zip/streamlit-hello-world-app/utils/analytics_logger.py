"""Sistema de analytics para rastreamento de conversações e padrões de uso.

Este módulo coleta dados de interações para análise posterior, permitindo:
- Identificar padrões de perguntas frequentes
- Otimizar filtros de payload para RAG
- Criar agentes especializados baseados em tópicos recorrentes
- Monitorar performance e qualidade das respostas
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
from abc import ABC, abstractmethod
import json


class BaseAnalyticsLogger(ABC):
    """Interface base para loggers de analytics.
    
    Permite implementações diferentes (Delta Table, arquivo local, API externa, etc)
    mantendo a mesma interface para o ConversationHandler.
    """
    
    @abstractmethod
    def log_interaction(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra uma interação (mensagem) na conversação."""
        pass
    
    @abstractmethod
    def log_event(
        self,
        session_id: str,
        event_type: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra um evento do sistema (ex: sessão criada, conversação limpa)."""
        pass
    
    @abstractmethod
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas gerais do logger."""
        pass


class DeltaTableAnalyticsLogger(BaseAnalyticsLogger):
    """Logger que persiste dados em Delta Tables no Databricks.
    
    Estrutura de tabelas:
    - interactions: Todas as mensagens trocadas
    - events: Eventos do sistema
    - session_metrics: Métricas agregadas por sessão
    """
    
    def __init__(
        self,
        catalog: str,
        schema: str,
        interactions_table: str = "conversation_interactions",
        events_table: str = "conversation_events",
        enable_batch: bool = True,
        batch_size: int = 10
    ):
        """Inicializa o logger com Delta Tables.
        
        Args:
            catalog: Nome do catálogo Unity Catalog
            schema: Nome do schema
            interactions_table: Nome da tabela de interações
            events_table: Nome da tabela de eventos
            enable_batch: Se True, acumula registros antes de gravar
            batch_size: Número de registros para acumular antes de gravar
        """
        self.catalog = catalog
        self.schema = schema
        self.interactions_table = f"{catalog}.{schema}.{interactions_table}"
        self.events_table = f"{catalog}.{schema}.{events_table}"
        self.enable_batch = enable_batch
        self.batch_size = batch_size
        
        # Buffers para batch processing
        self._interaction_buffer: List[Dict[str, Any]] = []
        self._event_buffer: List[Dict[str, Any]] = []
        
        # Estatísticas
        self._stats = {
            "interactions_logged": 0,
            "events_logged": 0,
            "batches_written": 0,
            "errors": 0
        }
        
        # Inicializar tabelas se não existirem
        self._initialize_tables()
    
    def _initialize_tables(self) -> None:
        """Cria as tabelas Delta se não existirem."""
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            # Tabela de interações
            interactions_ddl = f"""
            CREATE TABLE IF NOT EXISTS {self.interactions_table} (
                interaction_id STRING,
                session_id STRING,
                role STRING,
                content STRING,
                agent_name STRING,
                timestamp TIMESTAMP,
                interaction_number INT,
                metadata STRING,
                metrics STRING,
                created_at TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (DATE(timestamp))
            """
            
            # Tabela de eventos
            events_ddl = f"""
            CREATE TABLE IF NOT EXISTS {self.events_table} (
                event_id STRING,
                session_id STRING,
                event_type STRING,
                metadata STRING,
                timestamp TIMESTAMP,
                created_at TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (DATE(timestamp))
            """
            
            spark.sql(interactions_ddl)
            spark.sql(events_ddl)
            
        except Exception as e:
            print(f"Warning: Could not initialize Delta tables: {e}")
            print("Analytics will continue but data may not be persisted.")
    
    def log_interaction(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra uma interação na conversação.
        
        Args:
            session_id: ID da sessão
            role: Papel (user/assistant/system)
            content: Conteúdo da mensagem
            metadata: Metadados enriquecidos
            
        Returns:
            True se registrado com sucesso
        """
        try:
            import uuid
            
            interaction_data = {
                "interaction_id": str(uuid.uuid4()),
                "session_id": session_id,
                "role": role,
                "content": content,
                "agent_name": metadata.get("agent") if metadata else None,
                "timestamp": metadata.get("timestamp") if metadata else datetime.now().isoformat(),
                "interaction_number": metadata.get("interaction_number") if metadata else None,
                "metadata": json.dumps(metadata) if metadata else None,
                "metrics": json.dumps(metadata.get("metrics")) if metadata and "metrics" in metadata else None,
                "created_at": datetime.now().isoformat()
            }
            
            if self.enable_batch:
                self._interaction_buffer.append(interaction_data)
                if len(self._interaction_buffer) >= self.batch_size:
                    self._flush_interactions()
            else:
                self._write_interaction(interaction_data)
            
            self._stats["interactions_logged"] += 1
            return True
            
        except Exception as e:
            print(f"Error logging interaction: {e}")
            self._stats["errors"] += 1
            return False
    
    def log_event(
        self,
        session_id: str,
        event_type: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra um evento do sistema.
        
        Args:
            session_id: ID da sessão
            event_type: Tipo do evento (ex: session_created, conversation_cleared)
            metadata: Metadados do evento
            
        Returns:
            True se registrado com sucesso
        """
        try:
            import uuid
            
            event_data = {
                "event_id": str(uuid.uuid4()),
                "session_id": session_id,
                "event_type": event_type,
                "metadata": json.dumps(metadata) if metadata else None,
                "timestamp": metadata.get("timestamp") if metadata else datetime.now().isoformat(),
                "created_at": datetime.now().isoformat()
            }
            
            if self.enable_batch:
                self._event_buffer.append(event_data)
                if len(self._event_buffer) >= self.batch_size:
                    self._flush_events()
            else:
                self._write_event(event_data)
            
            self._stats["events_logged"] += 1
            return True
            
        except Exception as e:
            print(f"Error logging event: {e}")
            self._stats["errors"] += 1
            return False
    
    def _write_interaction(self, data: Dict[str, Any]) -> None:
        """Grava uma interação na Delta Table."""
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            df = spark.createDataFrame([data])
            df.write.format("delta").mode("append").saveAsTable(self.interactions_table)
            
        except Exception as e:
            print(f"Error writing interaction to Delta: {e}")
            raise
    
    def _write_event(self, data: Dict[str, Any]) -> None:
        """Grava um evento na Delta Table."""
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            df = spark.createDataFrame([data])
            df.write.format("delta").mode("append").saveAsTable(self.events_table)
            
        except Exception as e:
            print(f"Error writing event to Delta: {e}")
            raise
    
    def _flush_interactions(self) -> None:
        """Grava todas as interações do buffer."""
        if not self._interaction_buffer:
            return
        
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            df = spark.createDataFrame(self._interaction_buffer)
            df.write.format("delta").mode("append").saveAsTable(self.interactions_table)
            
            self._stats["batches_written"] += 1
            self._interaction_buffer.clear()
            
        except Exception as e:
            print(f"Error flushing interactions: {e}")
            self._stats["errors"] += 1
    
    def _flush_events(self) -> None:
        """Grava todos os eventos do buffer."""
        if not self._event_buffer:
            return
        
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.builder.getOrCreate()
            
            df = spark.createDataFrame(self._event_buffer)
            df.write.format("delta").mode("append").saveAsTable(self.events_table)
            
            self._stats["batches_written"] += 1
            self._event_buffer.clear()
            
        except Exception as e:
            print(f"Error flushing events: {e}")
            self._stats["errors"] += 1
    
    def flush_all(self) -> None:
        """Força a gravação de todos os buffers."""
        self._flush_interactions()
        self._flush_events()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do logger."""
        return {
            **self._stats,
            "buffer_sizes": {
                "interactions": len(self._interaction_buffer),
                "events": len(self._event_buffer)
            },
            "tables": {
                "interactions": self.interactions_table,
                "events": self.events_table
            }
        }
    
    def __del__(self):
        """Garante que buffers sejam gravados ao destruir o objeto."""
        try:
            self.flush_all()
        except:
            pass


class InMemoryAnalyticsLogger(BaseAnalyticsLogger):
    """Logger simples que mantém dados em memória (útil para testes/desenvolvimento)."""
    
    def __init__(self):
        """Inicializa o logger em memória."""
        self.interactions: List[Dict[str, Any]] = []
        self.events: List[Dict[str, Any]] = []
    
    def log_interaction(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra interação em memória."""
        self.interactions.append({
            "session_id": session_id,
            "role": role,
            "content": content,
            "metadata": metadata,
            "timestamp": datetime.now().isoformat()
        })
        return True
    
    def log_event(
        self,
        session_id: str,
        event_type: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Registra evento em memória."""
        self.events.append({
            "session_id": session_id,
            "event_type": event_type,
            "metadata": metadata,
            "timestamp": datetime.now().isoformat()
        })
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas."""
        return {
            "interactions_count": len(self.interactions),
            "events_count": len(self.events)
        }
    
    def get_all_interactions(self) -> List[Dict[str, Any]]:
        """Retorna todas as interações (útil para debugging)."""
        return self.interactions.copy()
    
    def get_all_events(self) -> List[Dict[str, Any]]:
        """Retorna todos os eventos (útil para debugging)."""
        return self.events.copy()
    
    def clear(self) -> None:
        """Limpa todos os dados."""
        self.interactions.clear()
        self.events.clear()
