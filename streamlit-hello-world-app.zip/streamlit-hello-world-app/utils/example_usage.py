# ============ SETUP (app.py) ============
from memory import SessionManager, ConversationHandler
from utils import (
    DeltaTableAnalyticsLogger,
    SessionPersistence,
    MLflowSessionTracker
)

# 1. Analytics (tempo real - cada mensagem)
analytics = DeltaTableAnalyticsLogger(
    catalog="main",
    schema="analytics"
)

# 2. Session Manager + Handler
session_manager = SessionManager()
conversation_handler = ConversationHandler(
    session_manager=session_manager,
    analytics_logger=analytics  # Conectado!
)

# 3. Persistence (backup de sessões)
persistence = SessionPersistence(
    catalog="main",
    schema="agent_sessions"
)

# 4. MLflow Tracker (métricas de ML)
mlflow_tracker = MLflowSessionTracker(
    experiment_name="/chatbot-production"
)

# ============ DURANTE A CONVERSAÇÃO ============
session_id, _ = session_manager.get_or_create_session(user_id="user_123")

# Usuário envia mensagem
user_input = "Como criar uma tabela Delta?"

# 1. Adicionar ao histórico + analytics (automático)
conversation_handler.process_user_input(
    session_id=session_id,
    content=user_input
)

# 2. Processar com LLM
import time
start_time = time.time()
response = supervisor.process(user_input)
latency = time.time() - start_time

# 3. Adicionar resposta + analytics (automático)
conversation_handler.process_agent_response(
    session_id=session_id,
    content=response["content"],
    agent_name="rag_agent",
    metrics={
        "latency_ms": latency * 1000,
        "tokens_used": response.get("tokens")
    }
)

# 4. Track no MLflow (métricas de ML)
mlflow_tracker.log_interaction(
    session_id=session_id,
    user_message=user_input,
    agent_response=response["content"],
    agent_name="rag_agent",
    latency_ms=latency * 1000,
    tokens_used=response.get("tokens"),
    metadata={"model": "dbrx-instruct"}
)

# ============ QUANDO SESSÃO TERMINA ============
# Backup completo da sessão
session_data = session_manager.export_session(session_id)
persistence.save_session(session_data)

# Encerrar sessão
session_manager.end_session(session_id)

# Finalizar run do MLflow
mlflow_tracker.end_session(session_id)