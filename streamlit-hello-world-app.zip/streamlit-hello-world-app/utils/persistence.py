"""Persistência de sessões em Delta Tables para análise histórica."""

from typing import Dict, Any, Optional, List
from datetime import datetime
import json
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType
from pyspark.sql import functions as F


class SessionPersistence:
    """Gerencia persistência de sessões em Delta Tables.
    
    Permite:
    - Salvar sessões completas em Delta
    - Recuperar histórico de conversas
    - Análise de uso via SQL
    - Métricas agregadas por usuário/período
    """
    
    def __init__(
        self,
        catalog: str,
        schema: str = "agent_sessions",
        table_name: str = "conversation_history"
    ):
        """Inicializa o gerenciador de persistência.
        
        Args:
            catalog: Nome do catálogo Unity Catalog
            schema: Nome do schema
            table_name: Nome da tabela
        """
        self.catalog = catalog
        self.schema = schema
        self.table_name = table_name
        self.full_table_name = f"{catalog}.{schema}.{table_name}"
        
        try:
            self.spark = SparkSession.builder.getOrCreate()
            self._ensure_table_exists()
        except Exception as e:
            print(f"Aviso: Não foi possível inicializar Spark: {e}")
            self.spark = None
    
    def _ensure_table_exists(self):
        """Cria a tabela se não existir."""
        if not self.spark:
            return
        
        try:
            # Verificar se schema existe, criar se não
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {self.catalog}.{self.schema}")
            
            # Criar tabela se não existir
            create_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {self.full_table_name} (
                session_id STRING,
                user_id STRING,
                message_index INT,
                role STRING,
                content STRING,
                timestamp TIMESTAMP,
                tokens INT,
                latency_ms DOUBLE,
                metadata STRING,
                created_at TIMESTAMP,
                session_start TIMESTAMP,
                session_end TIMESTAMP
            )
            USING DELTA
            PARTITIONED BY (DATE(timestamp))
            """
            
            self.spark.sql(create_table_sql)
            print(f"✓ Tabela {self.full_table_name} pronta")
            
        except Exception as e:
            print(f"Erro ao criar tabela: {e}")
    
    def save_session(self, session_data: Dict[str, Any]) -> bool:
        """Salva uma sessão completa na Delta Table.
        
        Args:
            session_data: Dados exportados do SessionManager
            
        Returns:
            True se salvo com sucesso
        """
        if not self.spark:
            print("Spark não disponível")
            return False
        
        try:
            # Extrair mensagens
            messages = session_data.get("memory", {}).get("messages", [])
            
            if not messages:
                return True  # Nada para salvar
            
            # Preparar dados para inserção
            rows = []
            session_start = datetime.fromisoformat(session_data["created_at"])
            session_end = datetime.fromisoformat(session_data["last_activity"])
            
            for idx, msg in enumerate(messages):
                row = {
                    "session_id": session_data["session_id"],
                    "user_id": session_data["user_id"],
                    "message_index": idx,
                    "role": msg.get("role"),
                    "content": msg.get("content"),
                    "timestamp": datetime.fromisoformat(msg.get("timestamp", datetime.now().isoformat())),
                    "tokens": msg.get("tokens"),
                    "latency_ms": msg.get("latency_ms"),
                    "metadata": json.dumps(msg.get("metadata", {})),
                    "created_at": datetime.now(),
                    "session_start": session_start,
                    "session_end": session_end
                }
                rows.append(row)
            
            # Criar DataFrame e salvar
            df = self.spark.createDataFrame(rows)
            df.write.mode("append").saveAsTable(self.full_table_name)
            
            print(f"✓ Sessão {session_data['session_id'][:8]} salva com {len(rows)} mensagens")
            return True
            
        except Exception as e:
            print(f"Erro ao salvar sessão: {e}")
            return False
    
    def load_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Carrega uma sessão da Delta Table.
        
        Args:
            session_id: ID da sessão
            
        Returns:
            Dados da sessão no formato do SessionManager
        """
        if not self.spark:
            return None
        
        try:
            # Buscar mensagens da sessão
            df = self.spark.sql(f"""
                SELECT *
                FROM {self.full_table_name}
                WHERE session_id = '{session_id}'
                ORDER BY message_index
            """)
            
            rows = df.collect()
            
            if not rows:
                return None
            
            # Reconstruir estrutura da sessão
            messages = []
            for row in rows:
                msg = {
                    "role": row.role,
                    "content": row.content,
                    "timestamp": row.timestamp.isoformat(),
                    "tokens": row.tokens,
                    "latency_ms": row.latency_ms,
                    "metadata": json.loads(row.metadata) if row.metadata else {}
                }
                messages.append(msg)
            
            session_data = {
                "session_id": session_id,
                "user_id": rows[0].user_id,
                "created_at": rows[0].session_start.isoformat(),
                "last_activity": rows[0].session_end.isoformat(),
                "metadata": {},
                "memory": {
                    "messages": messages,
                    "max_messages": len(messages)
                }
            }
            
            return session_data
            
        except Exception as e:
            print(f"Erro ao carregar sessão: {e}")
            return None
    
    def get_user_sessions(self, user_id: str, limit: int = 10) -> List[str]:
        """Lista sessões de um usuário.
        
        Args:
            user_id: ID do usuário
            limit: Número máximo de sessões
            
        Returns:
            Lista de session_ids
        """
        if not self.spark:
            return []
        
        try:
            df = self.spark.sql(f"""
                SELECT DISTINCT session_id, MAX(timestamp) as last_msg
                FROM {self.full_table_name}
                WHERE user_id = '{user_id}'
                GROUP BY session_id
                ORDER BY last_msg DESC
                LIMIT {limit}
            """)
            
            return [row.session_id for row in df.collect()]
            
        except Exception as e:
            print(f"Erro ao buscar sessões do usuário: {e}")
            return []
    
    def get_session_metrics(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Calcula métricas de uma sessão.
        
        Args:
            session_id: ID da sessão
            
        Returns:
            Dicionário com métricas
        """
        if not self.spark:
            return None
        
        try:
            df = self.spark.sql(f"""
                SELECT 
                    COUNT(*) as total_messages,
                    SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as user_messages,
                    SUM(CASE WHEN role = 'assistant' THEN 1 ELSE 0 END) as assistant_messages,
                    SUM(tokens) as total_tokens,
                    AVG(latency_ms) as avg_latency_ms,
                    MIN(timestamp) as first_message,
                    MAX(timestamp) as last_message
                FROM {self.full_table_name}
                WHERE session_id = '{session_id}'
            """)
            
            row = df.first()
            
            if not row:
                return None
            
            return {
                "total_messages": row.total_messages,
                "user_messages": row.user_messages,
                "assistant_messages": row.assistant_messages,
                "total_tokens": row.total_tokens,
                "avg_latency_ms": row.avg_latency_ms,
                "first_message": row.first_message.isoformat() if row.first_message else None,
                "last_message": row.last_message.isoformat() if row.last_message else None
            }
            
        except Exception as e:
            print(f"Erro ao calcular métricas: {e}")
            return None
