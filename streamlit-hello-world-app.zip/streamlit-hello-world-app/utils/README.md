# Utils - Tracking e Persistência

Módulo simples para salvar e monitorar conversas do agente.

## O que faz?

* **MLflowSessionTracker** - Registra métricas no MLflow (tokens, latência, custos)
* **SessionPersistence** - Salva conversas em Delta Tables para análise

## Como usar?

```python
from utils import MLflowSessionTracker, SessionPersistence

# Inicializar
tracker = MLflowSessionTracker()
persistence = SessionPersistence()

# Durante a conversa
tracker.start_session_run(session_id, user_id)
tracker.log_message(role="user", content="Olá", tokens=5)
tracker.end_session_run()

# Salvar no Delta
session_data = session_manager.export_session(session_id)
persistence.save_session(session_data)
```

## Onde os dados ficam?

* **MLflow**: `/Users/shared/agent_conversations` (experimento)
* **Delta**: `main.agent_sessions.conversation_history` (tabela)

## Análise rápida

```sql
-- Ver últimas conversas
SELECT * FROM main.agent_sessions.conversation_history
ORDER BY timestamp DESC LIMIT 100;

-- Tokens por usuário
SELECT user_id, SUM(tokens) as total_tokens
FROM main.agent_sessions.conversation_history
GROUP BY user_id;
```

## Configuração

```python
# Mudar local do experimento
tracker = MLflowSessionTracker(
    experiment_name="/Users/seu_email@vale.com/meu_agente"
)

# Mudar tabela Delta
persistence = SessionPersistence(
    catalog="main",
    schema="meu_schema",
    table_name="minhas_conversas"
)
```

Veja `example_usage.py` para exemplo completo.
