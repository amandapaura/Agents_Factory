"""Tracking de sessões e métricas usando MLflow para monitoramento de agentes."""

import mlflow
from typing import Dict, Any, Optional, List
from datetime import datetime
import json


class MLflowSessionTracker:
    """Gerencia tracking de sessões de conversação usando MLflow.
    
    Permite monitorar:
    - Tokens usados (input/output)
    - Latência de respostas
    - Custo estimado
    - Palavras-chave mais usadas
    - Histórico completo de conversas
    - Métricas customizadas
    
    Integra-se com Databricks MLflow UI para visualização e análise.
    """
    
    def __init__(
        self,
        experiment_name: str = "/Users/shared/agent_conversations",
        enable_tracing: bool = True
    ):
        """Inicializa o tracker MLflow.
        
        Args:
            experiment_name: Nome do experimento MLflow
            enable_tracing: Se True, habilita MLflow Tracing para LLMs
        """
        self.experiment_name = experiment_name
        self.enable_tracing = enable_tracing
        
        # Criar ou obter experimento
        try:
            mlflow.set_experiment(experiment_name)
        except Exception as e:
            print(f"Aviso: Não foi possível configurar experimento MLflow: {e}")
        
        # Habilitar tracing se solicitado
        if enable_tracing:
            try:
                mlflow.langchain.autolog()
            except Exception as e:
                print(f"Aviso: Não foi possível habilitar autolog: {e}")
    
    def start_session_run(
        self,
        session_id: str,
        user_id: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Inicia um run MLflow para uma sessão.
        
        Args:
            session_id: ID da sessão
            user_id: ID do usuário
            metadata: Metadados adicionais
            
        Returns:
            run_id do MLflow ou None se falhar
        """
        try:
            run = mlflow.start_run(run_name=f"session_{session_id[:8]}")
            
            # Logar tags
            mlflow.set_tag("session_id", session_id)
            mlflow.set_tag("user_id", user_id)
            mlflow.set_tag("session_start", datetime.now().isoformat())
            
            # Logar metadados adicionais
            if metadata:
                for key, value in metadata.items():
                    mlflow.set_tag(f"metadata.{key}", str(value))
            
            return run.info.run_id
        except Exception as e:
            print(f"Erro ao iniciar run MLflow: {e}")
            return None
    
    def log_message(
        self,
        role: str,
        content: str,
        tokens: Optional[int] = None,
        latency_ms: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Loga uma mensagem individual da conversação.
        
        Args:
            role: 'user', 'assistant', ou 'system'
            content: Conteúdo da mensagem
            tokens: Número de tokens (se disponível)
            latency_ms: Latência em milissegundos
            metadata: Metadados adicionais
        """
        try:
            timestamp = datetime.now().isoformat()
            
            # Logar como parâmetro estruturado
            message_data = {
                "timestamp": timestamp,
                "role": role,
                "content": content[:500],  # Limitar tamanho
                "content_length": len(content),
                "tokens": tokens,
                "latency_ms": latency_ms
            }
            
            if metadata:
                message_data.update(metadata)
            
            # Logar métricas
            if tokens:
                mlflow.log_metric(f"{role}_tokens", tokens, step=self._get_step())
            
            if latency_ms:
                mlflow.log_metric(f"{role}_latency_ms", latency_ms, step=self._get_step())
            
            # Logar comprimento da mensagem
            mlflow.log_metric(f"{role}_message_length", len(content), step=self._get_step())
            
        except Exception as e:
            print(f"Erro ao logar mensagem: {e}")
    
    def log_conversation_metrics(
        self,
        total_messages: int,
        total_tokens: int,
        avg_latency_ms: float,
        user_messages: int,
        assistant_messages: int,
        estimated_cost: Optional[float] = None
    ):
        """Loga métricas agregadas da conversação.
        
        Args:
            total_messages: Total de mensagens na sessão
            total_tokens: Total de tokens usados
            avg_latency_ms: Latência média
            user_messages: Número de mensagens do usuário
            assistant_messages: Número de respostas do assistente
            estimated_cost: Custo estimado em USD
        """
        try:
            mlflow.log_metric("total_messages", total_messages)
            mlflow.log_metric("total_tokens", total_tokens)
            mlflow.log_metric("avg_latency_ms", avg_latency_ms)
            mlflow.log_metric("user_messages", user_messages)
            mlflow.log_metric("assistant_messages", assistant_messages)
            
            if estimated_cost:
                mlflow.log_metric("estimated_cost_usd", estimated_cost)
            
            # Calcular taxa de resposta
            if user_messages > 0:
                response_rate = assistant_messages / user_messages
                mlflow.log_metric("response_rate", response_rate)
                
        except Exception as e:
            print(f"Erro ao logar métricas de conversação: {e}")
    
    def log_keywords(self, keywords: Dict[str, int]):
        """Loga palavras-chave mais usadas na conversação.
        
        Args:
            keywords: Dicionário {palavra: frequência}
        """
        try:
            # Logar top 20 palavras
            top_keywords = dict(sorted(keywords.items(), key=lambda x: x[1], reverse=True)[:20])
            
            for word, count in top_keywords.items():
                mlflow.log_metric(f"keyword_{word}", count)
                
        except Exception as e:
            print(f"Erro ao logar keywords: {e}")
    
    def log_conversation_history(self, messages: List[Dict[str, Any]]):
        """Loga histórico completo da conversação como artifact.
        
        Args:
            messages: Lista de mensagens da conversação
        """
        try:
            # Salvar como JSON
            history_file = "conversation_history.json"
            with open(history_file, "w") as f:
                json.dump(messages, f, indent=2, ensure_ascii=False)
            
            mlflow.log_artifact(history_file)
            
        except Exception as e:
            print(f"Erro ao logar histórico: {e}")
    
    def end_session_run(self, status: str = "FINISHED"):
        """Finaliza o run MLflow da sessão.
        
        Args:
            status: Status final ('FINISHED', 'FAILED', 'KILLED')
        """
        try:
            mlflow.set_tag("session_end", datetime.now().isoformat())
            mlflow.end_run(status=status)
        except Exception as e:
            print(f"Erro ao finalizar run MLflow: {e}")
    
    def log_error(self, error_message: str, error_type: str):
        """Loga erros ocorridos durante a sessão.
        
        Args:
            error_message: Mensagem de erro
            error_type: Tipo do erro
        """
        try:
            mlflow.set_tag("error_occurred", "true")
            mlflow.set_tag("error_type", error_type)
            mlflow.log_param("last_error", error_message[:500])
        except Exception as e:
            print(f"Erro ao logar erro: {e}")
    
    def _get_step(self) -> int:
        """Retorna o step atual para métricas incrementais."""
        try:
            run = mlflow.active_run()
            if run:
                # Contar métricas já logadas
                return len(run.data.metrics) // 3  # Aproximação
            return 0
        except:
            return 0
    
    @staticmethod
    def calculate_token_cost(
        input_tokens: int,
        output_tokens: int,
        model: str = "gpt-4"
    ) -> float:
        """Calcula custo estimado baseado em tokens.
        
        Args: 
            input_tokens: Tokens de entrada
            output_tokens: Tokens de saída
            model: Nome do modelo
            
        Returns:
            Custo estimado em USD
        """
        # Preços aproximados (atualizar conforme necessário)
        pricing = {
            "gpt-4": {"input": 0.03 / 1000, "output": 0.06 / 1000},
            "gpt-3.5-turbo": {"input": 0.0015 / 1000, "output": 0.002 / 1000},
            "claude-3": {"input": 0.015 / 1000, "output": 0.075 / 1000},
            "databricks-claude-haiku-4-5": {"input": 0.00025 / 1000, "output": 0.00125 / 1000}
        }
        
        model_pricing = pricing.get(model, pricing["gpt-4"])
        
        cost = (input_tokens * model_pricing["input"]) + \
               (output_tokens * model_pricing["output"])
        
        return round(cost, 6)
