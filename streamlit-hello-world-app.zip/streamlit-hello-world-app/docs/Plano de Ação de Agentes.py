# Databricks notebook source
# MAGIC %md
# MAGIC ## 📋 PLANO DE AÇÃO - DATABRICKS APPS COM MULTI-AGENTE
# MAGIC
# MAGIC ### 🎯 OBJETIVOS DO PROJETO
# MAGIC 1. Modularizar o código do multi-agente atual
# MAGIC 2. Criar padrão de projeto (Builder Pattern) para adicionar tools facilmente
# MAGIC 3. Implementar gerenciamento de histórico de conversas
# MAGIC 4. Desenvolver interface Streamlit como Databricks App
# MAGIC 5. Preparar para produção com boas práticas
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###📁 ESTRUTURA DE PASTAS E ARQUIVOS

# COMMAND ----------

tax-legislation-chatbot/
│
├── app.py                          # Ponto de entrada do Streamlit
│
├── requirements.txt                # Dependências do projeto
│
├── config/
│   ├── __init__.py
│   ├── settings.py                 # Configurações globais (endpoints, IDs, catálogos)
│   └── prompts.py                  # Templates de prompts centralizados
│
├── core/
│   ├── __init__.py
│   ├── rag_pipeline.py             # Classe RAGPipeline refatorada
│   ├── metadata_extractor.py      # Classe MetadataExtractor
│   └── vector_search.py            # Lógica de busca vetorial isolada
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py               # Classe abstrata BaseAgent (padrão de projeto)
│   ├── rag_agent.py                # Implementação do agente RAG
│   ├── genie_agent.py              # Implementação do agente Genie
│   └── agent_factory.py            # Factory para criar agentes dinamicamente
│
├── supervisor/
│   ├── __init__.py
│   ├── multi_agent_supervisor.py  # Orquestrador dos agentes
│   └── routing_strategy.py        # Lógica de roteamento de perguntas
│
├── memory/
│   ├── __init__.py
|   ├── conversation_handle.py     # Gerenciamento de conversas
│   ├── conversation_memory.py     # Gerenciamento de histórico de conversas
│   └── session_manager.py         # Gerenciamento de sessões de usuário
│
├── ui/
│   ├── __init__.py
│   ├── chat_interface.py          # Componentes Streamlit do chat
│   ├── sidebar.py                 # Configurações e filtros na sidebar
│   └── styles.py                  # CSS customizado para o Streamlit
│
├── utils/
│   ├── __init__.py
│   ├── auth.py                    # Autenticação e OBO
│   ├── logging.py                 # Configuração de logs
│   ├── validators.py              # Validações de entrada
|   ├── mlflow_tracking.py         # Tracking de sessões e métricas
|   └── persistence.py             # Save/load em Delta Tables
│
└── tests/
    ├── __init__.py
    ├── test_rag_pipeline.py
    ├── test_agents.py
    └── test_supervisor.py

# COMMAND ----------

# MAGIC %md
# MAGIC ###📋 DETALHAMENTO DE CADA ARQUIVO
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 1. `app.py` **(Ponto de entrada)**
# MAGIC
# MAGIC     **Responsabilidade:** Inicializar o Streamlit, gerenciar sessão, renderizar UI
# MAGIC
# MAGIC - Importa componentes de `ui/`
# MAGIC - Inicializa `MultiAgentSupervisor`
# MAGIC - Gerencia estado da sessão (histórico)
# MAGIC - Orquestra fluxo: input → supervisor → output
# MAGIC
# MAGIC
# MAGIC 2. `config/settings.py` **(Configurações centralizadas)**
# MAGIC
# MAGIC     **Responsabilidade:** Todas as constantes e configurações
# MAGIC
# MAGIC - `CATALOG`, `SCHEMA`, `IX_TABLE`, `DELTA_TABLE`
# MAGIC - `GENIE_SPACE_ID`, `LLM_ENDPOINT`
# MAGIC - `DATABRICKS_HOST`, `DATABRICKS_TOKEN`
# MAGIC - Configurações de memória (max_history, ttl)
# MAGIC
# MAGIC
# MAGIC 3. `config/prompts.py` **(Templates de prompts)**
# MAGIC
# MAGIC     **Responsabilidade:** Centralizar todos os prompts do sistema
# MAGIC
# MAGIC - `SUPERVISOR_PROMPT:` Prompt do supervisor
# MAGIC - `RAG_SYSTEM_PROMPT:` Prompt do agente RAG
# MAGIC - `GENIE_SYSTEM_PROMPT:` Prompt do agente Genie
# MAGIC - `ROUTING_RULES:` Regras de roteamento
# MAGIC
# MAGIC 4. `core/rag_pipeline.py` **(Pipeline RAG refatorado)**
# MAGIC
# MAGIC     **Responsabilidade:** Lógica de RAG isolada e testável
# MAGIC
# MAGIC - Classe RAGPipeline (já existe, mas será refatorada)
# MAGIC - Métodos: process_query(), generate_response()
# MAGIC - Sem dependências de agentes ou supervisor
# MAGIC
# MAGIC 5. `core/metadata_extractor.py` **(Extração de metadados)**
# MAGIC
# MAGIC     **Responsabilidade:** Extrair filtros da query do usuário
# MAGIC
# MAGIC - Classe `MetadataExtractor` (já existe)
# MAGIC - Métodos: `extract()`, validações de estados/cidades
# MAGIC
# MAGIC 6. `core/vector_search.py` **(Busca vetorial)**
# MAGIC
# MAGIC     **Responsabilidade:** Interface com Vector Search
# MAGIC
# MAGIC - Classe `VectorSearchClient` wrapper
# MAGIC - Métodos: `similarity_search()`, `auto_merge_chunks()`
# MAGIC
# MAGIC 7. `agents/base_agent.py `**(Padrão Abstract Factory)**
# MAGIC
# MAGIC     **Responsabilidade:** Classe abstrata para todos os agentes
# MAGIC
# MAGIC

# COMMAND ----------

BaseAgent (ABC)
├── name: str
├── description: str
├── execute(query: str, context: dict) -> str  [abstract]
└── validate_input(query: str) -> bool

# COMMAND ----------

# MAGIC %md
# MAGIC 8. `agents/rag_agent.py` **(Agente RAG)**
# MAGIC
# MAGIC     **Responsabilidade:** Implementação concreta do agente RAG
# MAGIC
# MAGIC - Herda de BaseAgent
# MAGIC - Usa RAGPipeline internamente
# MAGIC - Implementa execute() para consultas de conteúdo
# MAGIC
# MAGIC 9. `agents/genie_agent.py` **(Agente Genie)**
# MAGIC
# MAGIC     **Responsabilidade:** Implementação concreta do agente Genie
# MAGIC
# MAGIC - Herda de `BaseAgent`
# MAGIC - Usa `GenieAgent` do Databricks
# MAGIC - Implementa `execute()` para consultas quantitativas
# MAGIC
# MAGIC 10. `agents/agent_factory.py` **(Factory Pattern)**
# MAGIC
# MAGIC     **Responsabilidade:** Criar agentes dinamicamente

# COMMAND ----------

AgentFactory
├── register_agent(name, agent_class)
├── create_agent(name, config) -> BaseAgent
└── list_available_agents() -> List[str]

# COMMAND ----------

# MAGIC %md
# MAGIC 11. `supervisor/multi_agent_supervisor.py` **(Orquestrador)**
# MAGIC
# MAGIC     **Responsabilidade:** Coordenar múltiplos agentes
# MAGIC
# MAGIC - Classe MultiAgentSupervisor
# MAGIC - Métodos: `route_query()`, `execute()`, `add_agent()`
# MAGIC - Usa `RoutingStrategy` para decidir qual agente chamar
# MAGIC
# MAGIC 12. `supervisor/routing_strategy.py` **(Roteamento)**
# MAGIC
# MAGIC     **Responsabilidade:** Lógica de decisão de roteamento
# MAGIC
# MAGIC - Classe `RoutingStrategy`
# MAGIC - Métodos: `classify_intent()`, `select_agent()`
# MAGIC - Pode usar LLM ou regras baseadas em keywords
# MAGIC
# MAGIC 13. `memory/conversation_memory.py` **(Histórico)**
# MAGIC
# MAGIC     **Responsabilidade:** Gerenciar histórico de conversas
# MAGIC
# MAGIC - Classe ConversationMemory
# MAGIC - Métodos: `add_message()`, `get_history()`, `clear()`
# MAGIC - Suporta diferentes backends (in-memory, Delta Table, Redis)
# MAGIC
# MAGIC 14. `memory/session_manager.py` **(Sessões)**
# MAGIC
# MAGIC     **Responsabilidade:** Gerenciar sessões de usuários
# MAGIC
# MAGIC - Classe `SessionManager`
# MAGIC - Métodos: `create_session()`, `get_session()`,`expire_session()`
# MAGIC - Integração com Streamlit session_state
# MAGIC
# MAGIC 15. `ui/chat_interface.py` **(Interface do chat)**
# MAGIC
# MAGIC     **Responsabilidade:** Componentes visuais do chat
# MAGIC
# MAGIC - Função `render_chat_history()`
# MAGIC - Função `render_input_box()`
# MAGIC - Função `render_message(role, content)`
# MAGIC
# MAGIC 16. `ui/sidebar.py` **(Sidebar)**
# MAGIC
# MAGIC     **Responsabilidade:** Configurações e filtros
# MAGIC
# MAGIC - Função `render_sidebar()`
# MAGIC - Seletores: estado, ano, tipo de consulta
# MAGIC - Botão "Limpar histórico"
# MAGIC
# MAGIC 17. `ui/styles.py` **(Estilos CSS)**
# MAGIC     **Responsabilidade:** Customização visual
# MAGIC
# MAGIC - CSS para mensagens do chat
# MAGIC - Cores, fontes, espaçamentos
# MAGIC - Tema customizado
# MAGIC
# MAGIC 18. `utils/auth.py` **(Autenticação)**
# MAGIC
# MAGIC     **Responsabilidade:** Gerenciar credenciais e OBO
# MAGIC
# MAGIC - Função get_workspace_client()
# MAGIC - Função get_user_token()
# MAGIC - Validação de permissões
# MAGIC
# MAGIC 19. `utils/logging.py` **(Logs)**
# MAGIC
# MAGIC     **Responsabilidade:** Configuração de logging
# MAGIC
# MAGIC - Setup de loggers
# MAGIC - Formatação de logs
# MAGIC - Integração com MLflow tracking
# MAGIC
# MAGIC 20. `utils/validators.py` **(Validações)**
# MAGIC
# MAGIC     **Responsabilidade:** Validar inputs do usuário
# MAGIC
# MAGIC - Função `validate_query()`
# MAGIC - Função `sanitize_input()`
# MAGIC - Prevenção de injection
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### 🎯 PADRÃO DE PROJETO ESCOLHIDO: ABSTRACT FACTORY + BUILDER
# MAGIC **Por quê?**
# MAGIC
# MAGIC - **Abstract Factory** (`BaseAgent` + `AgentFactory`): Permite adicionar novos agentes sem modificar código existente
# MAGIC - **Builder** (`MultiAgentSupervisor`): Permite configurar o supervisor de forma fluente

# COMMAND ----------

# MAGIC %md
# MAGIC ### 📝 PRÓXIMOS PASSOS (ROADMAP)
# MAGIC Divido em fases para facilitar o trabalho colaborativo:
# MAGIC
# MAGIC **FASE 1: Refatoração do Core ✅**
# MAGIC - Criar estrutura de pastas
# MAGIC - Mover `RAGPipeline` e `MetadataExtractor` para core/
# MAGIC - Criar `config/settings.py` com todas as constantes
# MAGIC
# MAGIC **FASE 2: Padrão de Projeto (Agents)** 🔨
# MAGIC - Criar `BaseAgent` abstrato
# MAGIC - Implementar `RAGAgent` e `GenieAgent`
# MAGIC - Criar `AgentFactory`
# MAGIC
# MAGIC **FASE 3: Supervisor** 🎯
# MAGIC - Criar `MultiAgentSupervisor`
# MAGIC - Implementar `RoutingStrategy`
# MAGIC - Integrar com agentes
# MAGIC
# MAGIC **FASE 4: Memória e Histórico** 💾
# MAGIC - Implementar `ConversationMemory`
# MAGIC - Criar `SessionManager`
# MAGIC - Integrar com Streamlit session_state
# MAGIC
# MAGIC **FASE 5: Interface Streamlit** 🎨
# MAGIC - Criar `app.py` básico
# MAGIC - Implementar componentes de `ui/`
# MAGIC - Adicionar estilos e customizações
# MAGIC
# MAGIC **FASE 6: Testes e Deploy** 🚀
# MAGIC - Criar testes unitários
# MAGIC - Configurar Databricks Apps
# MAGIC - Deploy e monitoramento