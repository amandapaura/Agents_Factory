# Databricks notebook source
# MAGIC %md
# MAGIC ## 📑 Documentação Técnica: Databricks Multi-Agent Architecture

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Visão Geral
# MAGIC O sistema é um ecossistema de agentes inteligentes projetado para atuar como um consultor especializado. Ele utiliza um Agente Supervisor central que orquestra agentes filhos especializados (KA, Genie, RAG), instanciados dinamicamente via uma fábrica abstrata, para resolver consultas complexas de usuários através de uma interface Streamlit.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Estrutura de Componentes e Diretórios
# MAGIC **🎨 Camada de Interface (Frontend) - `streamlit-hello-world-app/`**
# MAGIC
# MAGIC Interface de usuário reativa que gerencia a experiência final e o estado da conversa.
# MAGIC - `app.py:` Ponto de entrada que consome o modelo via requisições de API (REST) ao endpoint do Databricks.
# MAGIC - `config/`: Centraliza as settings.py e os templates de prompts.py utilizados pelos agentes.
# MAGIC
# MAGIC **🧠 Camada de Orquestração e Agentes - `agents/ & supervisor/`**
# MAGIC
# MAGIC O núcleo lógico onde reside a inteligência e a seleção de ferramentas.
# MAGIC - **`multi_agent_supervisor.py`**: O "cérebro" do sistema. Analisa a intenção do usuário e decide qual agente ativar.
# MAGIC - **`agent_factory.py`**: Implementação do Abstract Factory Pattern. Cria instâncias dos agentes filhos conforme a necessidade.
# MAGIC - **Agentes Filhos**:
# MAGIC     - **KA Agent (`ka_agent.py`)**: Focado em Documentos/Knowledge Assets.
# MAGIC     - **Genie Agent (g`enie_agent.py`)**: Interface com Databricks Genie para consultas SQL/Dados.
# MAGIC     - **RAG Agent (`rag_agent.py`)**: Pipeline de busca vetorial para recuperação de informações.
# MAGIC
# MAGIC - **`base_agent.py`**: Classe abstrata que define o contrato (métodos obrigatórios) para todos os agentes.
# MAGIC
# MAGIC **💾 Camada de Memória e Sessão - `memory/`**
# MAGIC
# MAGIC Gerencia a persistência de curto prazo e o histórico contextual.
# MAGIC
# MAGIC - **`conversation_memory.py`**: Armazena o histórico da interação atual.
# MAGIC - **`conversation_handler.py`**: Processa o histórico para gerar resumos inteligentes, otimizando o envio de tokens para o LLM.
# MAGIC
# MAGIC **⚙️ Camada de Modelo e Registro - `model/`**
# MAGIC
# MAGIC Define como o projeto é empacotado e servido dentro do ecossistema Databricks.
# MAGIC
# MAGIC - **`tax_chatbot_model.py`**: Wrapper MLflow PyFunc que encapsula toda a lógica do supervisor para ser implantado como um modelo único.
# MAGIC - **`register_model.py`**: Script que automatiza o log e o registro do modelo no Unity Catalog.

# COMMAND ----------

# MAGIC %md
# MAGIC **3. Governança e Operações (MLOps) - `utils/ & core/`**
# MAGIC
# MAGIC Integração nativa com ferramentas Databricks para monitoramento e processamento.
# MAGIC
# MAGIC - **`mlflow_tracking.py`**: Rastreia experimentos, hiperparâmetros e versões do modelo.
# MAGIC - **`analytics_logger.py`**: Grava logs de uso e métricas em tabelas Delta no Unity Catalog para análise posterior.
# MAGIC - **`rag_pipeline.py`**: Lógica de backend para ingestão e processamento de documentos para o agente RAG.

# COMMAND ----------

# MAGIC %md
# MAGIC **4. Fluxo de Execução (Data Flow)**
# MAGIC - **Input:** O usuário insere uma pergunta no Streamlit.
# MAGIC - **Request:** O App envia um POST para o Databricks Model Serving Endpoint.
# MAGIC - **Supervisor:** O modelo invoca o multi_agent_supervisor.py.
# MAGIC - **Factory:** O supervisor solicita à agent_factory.py o agente mais apto para a tarefa.
# MAGIC - **Execução:** O agente (ex: Genie) processa a consulta e retorna a resposta ao supervisor.
# MAGIC - **Persistence:** O analytics_logger.py registra os metadados da transação no Unity Catalog.
# MAGIC - **Output:** O endpoint retorna a resposta final para o frontend exibir ao usuário.

# COMMAND ----------

# MAGIC %md
# MAGIC **5. Requisitos de Ambiente**
# MAGIC - **Runtime:** Python 3.10+
# MAGIC - **Databricks:** Unity Catalog habilitado e Model Serving disponível.
# MAGIC - **Bibliotecas:** Listadas em `requirements.txt` (incluindo `mlflow`, `streamlit`, `databricks-sdk`).

# COMMAND ----------

# DBTITLE 1,Generate PDF from Notebook
# MAGIC %pip install reportlab
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Generate PDF with Document Content
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.enums import TA_LEFT, TA_JUSTIFY
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime

# Definir o caminho do PDF
pdf_path = "/Workspace/Users/amanda.paura@vale.com/databricks_apps/chatbot-tax-legislation_2026_02_05-17_19/streamlit-hello-world-app/docs/Doc. Técnica.pdf"

# Criar o documento PDF
doc = SimpleDocTemplate(pdf_path, pagesize=A4,
                        rightMargin=72, leftMargin=72,
                        topMargin=72, bottomMargin=18)

# Container para os elementos do PDF
story = []

# Estilos
styles = getSampleStyleSheet()

# Customizar estilos
title_style = ParagraphStyle(
    'CustomTitle',
    parent=styles['Heading1'],
    fontSize=24,
    textColor='#1F4788',
    spaceAfter=30,
    alignment=TA_LEFT
)

heading2_style = ParagraphStyle(
    'CustomHeading2',
    parent=styles['Heading2'],
    fontSize=16,
    textColor='#2E5C8A',
    spaceAfter=12,
    spaceBefore=12,
    alignment=TA_LEFT
)

heading3_style = ParagraphStyle(
    'CustomHeading3',
    parent=styles['Heading3'],
    fontSize=14,
    textColor='#3A6EA5',
    spaceAfter=10,
    spaceBefore=10,
    alignment=TA_LEFT,
    fontName='Helvetica-Bold'
)

body_style = ParagraphStyle(
    'CustomBody',
    parent=styles['BodyText'],
    fontSize=11,
    alignment=TA_JUSTIFY,
    spaceAfter=12,
    leading=14
)

bullet_style = ParagraphStyle(
    'CustomBullet',
    parent=styles['BodyText'],
    fontSize=11,
    leftIndent=20,
    spaceAfter=6,
    leading=14
)

# Adicionar título principal
story.append(Paragraph("Documentação Técnica: Databricks Multi-Agent Architecture", title_style))
story.append(Spacer(1, 0.3*inch))

# Seção 1
story.append(Paragraph("1. Visão Geral", heading2_style))
story.append(Paragraph(
    "O sistema é um ecossistema de agentes inteligentes projetado para atuar como um consultor especializado. "
    "Ele utiliza um Agente Supervisor central que orquestra agentes filhos especializados (KA, Genie, RAG), "
    "instanciados dinamicamente via uma fábrica abstrata, para resolver consultas complexas de usuários através "
    "de uma interface Streamlit.",
    body_style
))
story.append(Spacer(1, 0.2*inch))

# Seção 2
story.append(Paragraph("2. Estrutura de Componentes e Diretórios", heading2_style))

story.append(Paragraph("Camada de Interface (Frontend) - <i>streamlit-hello-world-app/</i>", heading3_style))
story.append(Paragraph(
    "Interface de usuário reativa que gerencia a experiência final e o estado da conversa.",
    body_style
))
story.append(Paragraph("• <b>app.py:</b> Ponto de entrada que consome o modelo via requisições de API (REST) ao endpoint do Databricks.", bullet_style))
story.append(Paragraph("• <b>config/:</b> Centraliza as settings.py e os templates de prompts.py utilizados pelos agentes.", bullet_style))
story.append(Spacer(1, 0.15*inch))

story.append(Paragraph("Camada de Orquestração e Agentes - <i>agents/ &amp; supervisor/</i>", heading3_style))
story.append(Paragraph(
    "O núcleo lógico onde reside a inteligência e a seleção de ferramentas.",
    body_style
))
story.append(Paragraph("• <b>multi_agent_supervisor.py:</b> O 'cérebro' do sistema. Analisa a intenção do usuário e decide qual agente ativar.", bullet_style))
story.append(Paragraph("• <b>agent_factory.py:</b> Implementação do Abstract Factory Pattern. Cria instâncias dos agentes filhos conforme a necessidade.", bullet_style))
story.append(Paragraph("• <b>Agentes Filhos:</b>", bullet_style))
story.append(Paragraph("&nbsp;&nbsp;&nbsp;&nbsp;◦ <b>KA Agent (ka_agent.py):</b> Focado em Documentos/Knowledge Assets.", bullet_style))
story.append(Paragraph("&nbsp;&nbsp;&nbsp;&nbsp;◦ <b>Genie Agent (genie_agent.py):</b> Interface com Databricks Genie para consultas SQL/Dados.", bullet_style))
story.append(Paragraph("&nbsp;&nbsp;&nbsp;&nbsp;◦ <b>RAG Agent (rag_agent.py):</b> Pipeline de busca vetorial para recuperação de informações.", bullet_style))
story.append(Paragraph("• <b>base_agent.py:</b> Classe abstrata que define o contrato (métodos obrigatórios) para todos os agentes.", bullet_style))
story.append(Spacer(1, 0.15*inch))

story.append(Paragraph("Camada de Memória e Sessão - <i>memory/</i>", heading3_style))
story.append(Paragraph(
    "Gerencia a persistência de curto prazo e o histórico contextual.",
    body_style
))
story.append(Paragraph("• <b>conversation_memory.py:</b> Armazena o histórico da interação atual.", bullet_style))
story.append(Paragraph("• <b>conversation_handler.py:</b> Processa o histórico para gerar resumos inteligentes, otimizando o envio de tokens para o LLM.", bullet_style))
story.append(Spacer(1, 0.15*inch))

story.append(Paragraph("Camada de Modelo e Registro - <i>model/</i>", heading3_style))
story.append(Paragraph(
    "Define como o projeto é empacotado e servido dentro do ecossistema Databricks.",
    body_style
))
story.append(Paragraph("• <b>tax_chatbot_model.py:</b> Wrapper MLflow PyFunc que encapsula toda a lógica do supervisor para ser implantado como um modelo único.", bullet_style))
story.append(Paragraph("• <b>register_model.py:</b> Script que automatiza o log e o registro do modelo no Unity Catalog.", bullet_style))
story.append(Spacer(1, 0.2*inch))

# Seção 3
story.append(Paragraph("3. Governança e Operações (MLOps) - <i>utils/ &amp; core/</i>", heading2_style))
story.append(Paragraph(
    "Integração nativa com ferramentas Databricks para monitoramento e processamento.",
    body_style
))
story.append(Paragraph("• <b>mlflow_tracking.py:</b> Rastreia experimentos, hiperparâmetros e versões do modelo.", bullet_style))
story.append(Paragraph("• <b>analytics_logger.py:</b> Grava logs de uso e métricas em tabelas Delta no Unity Catalog para análise posterior.", bullet_style))
story.append(Paragraph("• <b>rag_pipeline.py:</b> Lógica de backend para ingestão e processamento de documentos para o agente RAG.", bullet_style))
story.append(Spacer(1, 0.2*inch))

# Seção 4
story.append(Paragraph("4. Fluxo de Execução (Data Flow)", heading2_style))
story.append(Paragraph("• <b>Input:</b> O usuário insere uma pergunta no Streamlit.", bullet_style))
story.append(Paragraph("• <b>Request:</b> O App envia um POST para o Databricks Model Serving Endpoint.", bullet_style))
story.append(Paragraph("• <b>Supervisor:</b> O modelo invoca o multi_agent_supervisor.py.", bullet_style))
story.append(Paragraph("• <b>Factory:</b> O supervisor solicita à agent_factory.py o agente mais apto para a tarefa.", bullet_style))
story.append(Paragraph("• <b>Execução:</b> O agente (ex: Genie) processa a consulta e retorna a resposta ao supervisor.", bullet_style))
story.append(Paragraph("• <b>Persistence:</b> O analytics_logger.py registra os metadados da transação no Unity Catalog.", bullet_style))
story.append(Paragraph("• <b>Output:</b> O endpoint retorna a resposta final para o frontend exibir ao usuário.", bullet_style))
story.append(Spacer(1, 0.2*inch))

# Seção 5
story.append(Paragraph("5. Requisitos de Ambiente", heading2_style))
story.append(Paragraph("• <b>Runtime:</b> Python 3.10+", bullet_style))
story.append(Paragraph("• <b>Databricks:</b> Unity Catalog habilitado e Model Serving disponível.", bullet_style))
story.append(Paragraph("• <b>Bibliotecas:</b> Listadas em requirements.txt (incluindo mlflow, streamlit, databricks-sdk).", bullet_style))

# Construir o PDF
doc.build(story)

print(f"✅ PDF gerado com sucesso em: {pdf_path}")
print(f"📄 Documento: Doc. Técnica")
print(f"📅 Data de geração: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")