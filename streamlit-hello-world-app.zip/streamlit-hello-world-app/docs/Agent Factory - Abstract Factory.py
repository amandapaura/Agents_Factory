# Databricks notebook source
# MAGIC %md
# MAGIC ## 🏭 O QUE É O AGENT FACTORY?
# MAGIC O `AgentFactory` é um **registro centralizado** que:
# MAGIC
# MAGIC 1. **Armazena** classes de agentes (RAGAgent, GenieAgent, etc.)
# MAGIC 2. **Cria instâncias** dessas classes sob demanda
# MAGIC 3. **Desacopla** a criação de agentes do código que os usa

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🎯 PADRÃO ABSTRACT FACTORY - VISÃO GERAL

# COMMAND ----------

┌─────────────────────────────────────────────────────────┐
│                    ABSTRACT FACTORY                      │
│                                                          │
│  BaseAgent (ABC)  ←──────────────────────────────────┐  │
│       ↑                                               │  │
│       │ herda                                         │  │
│       │                                               │  │
│  ┌────┴────┐                                          │  │
│  │         │                                          │  │
│  │         │                                          │  │
│ RAGAgent  GenieAgent  (classes concretas)            │  │
│                                                       │  │
│                                                       │  │
│  AgentFactory  ←──────────────────────────────────────┘  │
│  (registra e cria agentes)                               │
└─────────────────────────────────────────────────────────┘

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📚 COMPONENTES DO PADRÃO
# MAGIC #### 1. BaseAgent (Classe Abstrata)

# COMMAND ----------

class BaseAgent(ABC):
    """Define o CONTRATO que todos os agentes devem seguir."""
    
    @abstractmethod
    def execute(self, query: str, context=None) -> str:
        """Método obrigatório - cada agente implementa sua lógica."""
        pass
    
    def validate_input(self, query: str) -> bool:
        """Método comum - todos os agentes herdam."""
        return bool(query and query.strip())

# COMMAND ----------

# MAGIC %md
# MAGIC **Papel:** Define a **interface comum** que todos os agentes devem implementar.

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2. RAGAgent e GenieAgent (Classes Concretas)

# COMMAND ----------

class RAGAgent(BaseAgent):
    """Implementação CONCRETA para consultas de conteúdo."""
    
    def execute(self, query: str, context=None) -> str:
        # Lógica específica do RAG
        return self.rag_pipeline.process_query(query)


class GenieAgent(BaseAgent):
    """Implementação CONCRETA para consultas quantitativas."""
    
    def execute(self, query: str, context=None) -> str:
        # Lógica específica do Genie
        return self.genie.invoke({"messages": [...]})

# COMMAND ----------

# MAGIC %md
# MAGIC **Papel:** Implementam a **lógica específica** de cada tipo de agente.

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3. AgentFactory (Fábrica)

# COMMAND ----------

class AgentFactory:
    """Gerencia o REGISTRO e CRIAÇÃO de agentes."""
    
    def __init__(self):
        self._agents = {}  # Dicionário: {"rag": RAGAgent, "genie": GenieAgent}
    
    def register(self, agent_type: str, agent_class: Type[BaseAgent]):
        """Registra uma classe de agente."""
        self._agents[agent_type] = agent_class
    
    def create(self, agent_type: str, config: AgentConfig, **kwargs) -> BaseAgent:
        """Cria uma instância do agente."""
        agent_class = self._agents[agent_type]
        return agent_class(config, **kwargs)

# COMMAND ----------

# MAGIC %md
# MAGIC **Papel:** **Desacopla** a criação de agentes do código que os usa.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 🔄 FLUXO COMPLETO - PASSO A PASSO
# MAGIC PASSO 1: Registrar Agentes (Setup Inicial)

# COMMAND ----------

# No app.py ou em um arquivo de inicialização

from agents.agent_factory import agent_factory
from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent

# Registrar as classes no factory
agent_factory.register("rag", RAGAgent)
agent_factory.register("genie", GenieAgent)

# Agora o factory sabe que:
# - "rag" → RAGAgent
# - "genie" → GenieAgent

# COMMAND ----------

# MAGIC %md
# MAGIC **O que acontece internamente:**

# COMMAND ----------

# Dentro do AgentFactory
self._agents = {
    "rag": RAGAgent,      # Classe (não instância!)
    "genie": GenieAgent   # Classe (não instância!)
}

# COMMAND ----------

# MAGIC %md
# MAGIC PASSO 2: Criar Instâncias de Agentes

# COMMAND ----------

# Criar configuração do agente RAG
rag_config = AgentConfig(
    name="query_tax_legislation",
    description="Consulta conteúdo de legislações"
)

# Criar instância usando o factory
rag_agent = agent_factory.create(
    "rag",                              # Tipo do agente
    config=rag_config,                  # Configuração base
    index_table="catalog.schema.table", # Parâmetro específico do RAG
    endpoint_llm="databricks-claude"    # Parâmetro específico do RAG
)

# O factory faz:
# 1. Busca a classe: agent_class = self._agents["rag"]  → RAGAgent
# 2. Instancia: return RAGAgent(config, index_table=..., endpoint_llm=...)

# COMMAND ----------

# MAGIC %md
# MAGIC **O que acontece internamente:**

# COMMAND ----------

# Dentro do AgentFactory.create()
agent_class = self._agents["rag"]  # Pega a classe RAGAgent
return agent_class(config, **kwargs)  # Chama RAGAgent(config, index_table=..., endpoint_llm=...)

# COMMAND ----------

# MAGIC %md
# MAGIC PASSO 3: Usar o Agente

# COMMAND ----------

# Agora você tem uma instância de RAGAgent
response = rag_agent.execute("O que é ICMS?")
print(response)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🎨 POR QUE USAR ESSE PADRÃO?
# MAGIC ❌ **SEM Factory (código acoplado):**

# COMMAND ----------

# app.py - RUIM: código acoplado

from agents.rag_agent import RAGAgent
from agents.genie_agent import GenieAgent

# Criar agentes manualmente
rag_agent = RAGAgent(
    config=AgentConfig(...),
    index_table="...",
    endpoint_llm="..."
)

genie_agent = GenieAgent(
    config=AgentConfig(...),
    genie_space_id="...",
    workspace_client=...
)

# Problema: Se você adicionar um novo agente (SQLAgent),
# precisa modificar ESTE arquivo!

# COMMAND ----------

# MAGIC %md
# MAGIC ✅ **COM Factory (código desacoplado):**

# COMMAND ----------

# app.py - BOM: código desacoplado

from agents.agent_factory import agent_factory

# Registrar agentes (pode estar em outro arquivo)
agent_factory.register("rag", RAGAgent)
agent_factory.register("genie", GenieAgent)

# Criar agentes de forma uniforme
rag_agent = agent_factory.create("rag", config, index_table="...", endpoint_llm="...")
genie_agent = agent_factory.create("genie", config, genie_space_id="...", workspace_client=...)

# Vantagem: Adicionar novo agente é só registrar!
agent_factory.register("sql", SQLAgent)
sql_agent = agent_factory.create("sql", config, connection_string="...")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔥 EXEMPLO PRÁTICO: Adicionando um Novo Agente
# MAGIC
# MAGIC Cenário: Você quer adicionar um SQLAgent para consultas SQL diretas.
# MAGIC
# MAGIC **PASSO 1:** Criar a classe concreta

# COMMAND ----------

# agents/sql_agent.py

from .base_agent import BaseAgent, AgentConfig

class SQLAgent(BaseAgent):
    """Agente para consultas SQL diretas."""
    
    def __init__(self, config: AgentConfig, connection_string: str):
        super().__init__(config)
        self.connection_string = connection_string
    
    def execute(self, query: str, context=None) -> str:
        # Lógica de execução SQL
        return f"Executando SQL: {query}"

# COMMAND ----------

# MAGIC %md
# MAGIC **PASSO 2:** Registrar no factory

# COMMAND ----------

# app.py

from agents.sql_agent import SQLAgent

# Registrar o novo agente
agent_factory.register("sql", SQLAgent)

# COMMAND ----------

# MAGIC %md
# MAGIC **PASSO 3:** Usar normalmente

# COMMAND ----------

# Criar instância
sql_agent = agent_factory.create(
    "sql",
    config=AgentConfig(name="sql_agent", description="Consultas SQL"),
    connection_string="jdbc:..."
)

# Usar
response = sql_agent.execute("SELECT * FROM laws")

# COMMAND ----------

# MAGIC %md
# MAGIC ✨ **Você NÃO precisou modificar:**
# MAGIC - AgentFactory
# MAGIC - BaseAgent
# MAGIC - RAGAgent ou GenieAgent
# MAGIC - Código do supervisor
# MAGIC
# MAGIC
# MAGIC __________________________________
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## 🧩 RELACIONAMENTO ENTRE OS COMPONENTES

# COMMAND ----------

┌─────────────────────────────────────────────────────────────┐
│                         app.py                               │
│                                                              │
│  1. Registra agentes no factory                             │
│     agent_factory.register("rag", RAGAgent)                 │
│     agent_factory.register("genie", GenieAgent)             │
│                                                              │
│  2. Cria instâncias via factory                             │
│     rag_agent = agent_factory.create("rag", config, ...)    │
│     genie_agent = agent_factory.create("genie", config, ...) │
│                                                              │
│  3. Passa agentes para o supervisor                         │
│     supervisor = MultiAgentSupervisor([rag_agent, genie])   │
│                                                              │
│  4. Supervisor usa os agentes                               │
│     response = supervisor.invoke("Quantas leis de SP?")     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                   AgentFactory                               │
│                                                              │
│  _agents = {                                                │
│      "rag": RAGAgent,      ← Classe registrada             │
│      "genie": GenieAgent   ← Classe registrada             │
│  }                                                          │
│                                                              │
│  create("rag", config, ...) → RAGAgent(config, ...)        │
│  create("genie", config, ...) → GenieAgent(config, ...)    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    BaseAgent (ABC)                           │
│                                                              │
│  - execute(query) [abstract]                                │
│  - validate_input(query)                                    │
│  - get_capabilities()                                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                    ↑                    ↑
                    │                    │
         ┌──────────┴──────────┐  ┌─────┴──────────┐
         │     RAGAgent        │  │   GenieAgent    │
         │                     │  │                 │
         │  execute() {        │  │  execute() {    │
         │    RAG logic        │  │    Genie logic  │
         │  }                  │  │  }              │
         └─────────────────────┘  └─────────────────┘

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📝 RESUMO
# MAGIC #### Componentes - Papeis e Analogias	
# MAGIC - **BaseAgent**:	Define o contrato (interface)	"Receita de bolo" - todos devem seguir
# MAGIC - **RAGAgent/GenieAgent**:	Implementam a lógica específica	"Bolos diferentes" - chocolate, morango
# MAGIC - **AgentFactory**:	Registra e cria agentes	"Padaria" - você pede, ela faz
# MAGIC - **app.py**:	Usa os agentes	"Cliente" - pede o bolo e come
# MAGIC
# MAGIC #### Benefícios: 
# MAGIC
# MAGIC - **Extensibilidade**: Adicionar novos agentes sem modificar código existente
# MAGIC - **Desacoplamento**: Código não depende de classes concretas
# MAGIC -  **Manutenibilidade**: Mudanças em um agente não afetam outros
# MAGIC - **Testabilidade**: Fácil mockar agentes em testes