# Databricks notebook source
# MAGIC %md
# MAGIC ## 📚 Documentação do Projeto: Tax Legislation Chatbot
# MAGIC
# MAGIC ### 🎯 Visão Geral do Projeto
# MAGIC **Nome:** Tax Legislation Chatbot
# MAGIC
# MAGIC **Objetivo:** Assistente inteligente multi-agente especializado em legislação tributária brasileira, com capacidade de responder perguntas sobre leis, impostos, alíquotas e regulamentações fiscais.
# MAGIC
# MAGIC **Tecnologias Principais:**
# MAGIC
# MAGIC - **Databricks** (plataforma de dados e ML)
# MAGIC - **MLflow** (gerenciamento de modelos)
# MAGIC - **Streamlit** (interface web)
# MAGIC - **LangChain** (orquestração de LLMs)
# MAGIC - **Unity Catalog** (governança de dados)
# MAGIC - **Vector Search** (busca semântica)
# MAGIC - **Genie Space** (análise de dados)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🏗️ Arquitetura Geral do Sistema
# MAGIC
# MAGIC ### Diagrama de Componentes

# COMMAND ----------

┌─────────────────────────────────────────────────────────────────┐ │ USUÁRIO FINAL 
│ │ (Navegador Web) │ └────────────────────────┬────────────────────────────────────────┘
│ ▼ ┌─────────────────────────────────────────────────────────────────┐ │ CAMADA DE APRESENTAÇÃO │ 
│ ┌──────────────────────────────────────────────────────────┐ 
│ │ │ Streamlit App (app.py) 
│ │ │ │ • Interface de chat 
│ │ │ │ • Gerenciamento de sessão (UI) 
│ │ │ │ • Exibição de histórico 
│ │ │ │ • Métricas de uso 
│ └──────────────────────────────────────────────────────────┘ 
│ └────────────────────────┬────────────────────────────────────────┘ │ HTTP Request 
│ {question, session_id} ▼ ┌─────────────────────────────────────────────────────────────────┐ │ CAMADA DE SERVING (MLflow) │ 
│ ┌──────────────────────────────────────────────────────────┐ 
│ │ │ Model Serving Endpoint │ 
│ │ │ (tax_chatbot_endpoint) │ │ │ │ 
│ │ │ │ ┌─────────────────────────────────────────────────┐ 
│ │ │ │ │ TaxChatbotModel (MLflow PyFunc) 
│ │ │ │ │ │ • Recebe pergunta + session_id 
│ │ │ │ │ │ • Gerencia memória interna 
│ │ │ │ │ │ • Orquestra agentes 
│ │ │ │ │ │ • Retorna resposta + métricas 
│ │ │ │ └─────────────────────────────────────────────────┘ 
│ └──────────────────────────────────────────────────────────┘ │ └────────────────────────┬────────────────────────────────────────┘ │ ▼ ┌─────────────────────────────────────────────────────────────────┐ │ CAMADA DE ORQUESTRAÇÃO (Supervisor) │ 
 │ ┌──────────────────────────────────────────────────────────┐ 
 │ │ │ MultiAgentSupervisor │ │ 
 │ │ • Analisa a pergunta │ │ 
 │ │ • Seleciona agente apropriado │ │
 │ │ • Gerencia fluxo de conversação │ │ 
 │ │ • Integra respostas │ │ 
 │ └──────────────────────────────────────────────────────────┘ │ │ │ │ ┌──────────────────────────────────────────────────────────┐ │ │ │ ConversationHandler │ │ │ │ • Gerencia memória de conversação │ │ │ │ • Resumo inteligente (após 3 turnos) │ │ │ │ • Mantém contexto (7 mensagens) │ │ │ │ • Analytics de interações │ │ │ └──────────────────────────────────────────────────────────┘ │ └────────────────────────┬────────────────────────────────────────┘ │ ┌────────────────┼────────────────┐ │ │ │ ▼ ▼ ▼ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │ KA Agent │ │ Genie Agent │ │ RAG Agent │ │ │ │ │ │ │ │ • Knowledge │ │ • Análise │ │ • Busca │ │ Assistant │ │ quantita- │ │ semântica │ │ • Perguntas │ │ tiva │ │ • Retrieval │ │ qualita- │ │ • SQL sobre │ │ • Vector │ │ tivas │ │ dados │ │ Search │ └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ │ │ │ └─────────────────┼─────────────────┘ │ ▼ ┌─────────────────────────────────────────────────────────────────┐ │ CAMADA DE DADOS │ │ │ │ ┌──────────────────┐ ┌──────────────────┐ ┌──────────────┐ │ │ │ Unity Catalog │ │ Vector Search │ │ Genie Space │ │ │ │ │ │ │ │ │ │ │ │ • tax_legisla- │ │ • Índice │ │ • Análise │ │ │ │ tion (Delta) │ │ vetorial │ │ de dados │ │ │ │ • Metadados │ │ • Embeddings │ │ • SQL │ │ │ │ • Governança │ │ • Busca │ │ natural │ │ │ └──────────────────┘ └──────────────────┘ └──────────────┘ │ └─────────────────────────────────────────────────────────────────┘

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📦 Estrutura de Diretórios

# COMMAND ----------

streamlit-hello-world-app/ 
│ 
├── app.py # 🎨 Interface Streamlit principal 
│ ├── config/ 
│ ├── settings.py # ⚙️ Configurações globais 
│ └── prompts.py # 💬 Templates de prompts 
│ ├── model/
│ ├── tax_chatbot_model.py # 🤖 Modelo MLflow (PyFunc) 
│ ├── register_model.py # 📝 Script de registro no MLflow 
│ └── teste_modelo.py # 🧪 Testes do modelo 
│ ├── agents/ 
│ ├── base_agent.py # 🏗️ Classe base para agentes 
│ ├── agent_factory.py # 🏭 Factory pattern para agentes 
│ ├── ka_agent.py # 📚 Knowledge Assistant Agent 
│ ├── genie_agent.py # 🧞 Genie Space Agent 
│ └── rag_agent.py # 🔍 RAG Agent (Vector Search) 
│ ├── supervisor/ 
│ ├── multi_agent_supervisor.py # 🎯 Orquestrador de agentes │ └── teste.py # 🧪 Testes do supervisor 
│ ├── memory/ 
│ ├── init.py 
│ ├── conversation_memory.py # 💾 Gerenciamento de histórico │ ├── session_manager.py # 🔐 Gerenciamento de sessões 
│ └── conversation_handler.py # 🧠 Handler com resumo inteligente 
│ ├── utils/ 
│ ├── init.py 
│ ├── analytics_logger.py # 📊 Logging de analytics 
│ ├── mlflow_tracking.py # 📈 Tracking MLflow 
│ └── persistence.py # 💿 Persistência de dados 
│ ├── core/ 
│ ├── rag_pipeline.py # 🔄 Pipeline RAG 
│ └── metadata_extractor.py # 🏷️ Extração de metadados 
│ └── requirements.txt # 📋 Dependências Python