from databricks.vector_search.client import VectorSearchClient
from .metadata_extractor import MetadataExtractor
import re
import mlflow
import os

class RAGPipeline:
    """Pipeline RAG para busca vetorial e geração de respostas."""

    def __init__(self, index_table: str, endpoint_llm: str, workspace_client=None):
        self.index_table = index_table
        self.endpoint_llm = endpoint_llm
        self.workspace_client = workspace_client

    @mlflow.trace(name="vector_search", span_type="RETRIEVER")
    def vector_search(self, query_text: str, filtros: dict, num_results: int = 3, columns: list = None) -> list:
        """Realiza busca vetorial com filtros de metadados."""
        try:
            print('\n Iniciando busca vetorial ...')
            
            # Log dos parâmetros para tracing
            mlflow.log_param("query_text", query_text)
            mlflow.log_param("num_results", num_results)
            mlflow.log_param("filters", str(filtros))
            
            # Criar VectorSearchClient
            # Em Model Serving, as credenciais vêm automaticamente do ambiente
            # Não precisa passar workspace_client explicitamente
            client = VectorSearchClient(disable_notice=True)
            
            index = client.get_index(index_name=self.index_table)
            
            # Definir columns padrão se não especificado
            if columns is None:
                columns = ["law_chunk_text"]
            
            # Preparar parâmetros de busca
            search_params = {
                "query_text": query_text,
                "columns": columns,  # OBRIGATÓRIO - agora sempre tem valor
                "num_results": num_results
            }
            
            # Adicionar filtros se existirem
            if filtros:
                search_params["filters"] = filtros
            
            # Realizar busca vetorial
            results = index.similarity_search(**search_params)
            
            # Limpar textos dos resultados
            patterns = r'[\n\t\r]|td>||<td>|</td>|<tr>|</tr>|<p>|</p>|<b>|</b>'
            cleaned_texts = []
            
            for i in results["result"]["data_array"]:
                # i[1] deve ser o texto, mas validar que é string
                text = i[1] if len(i) > 1 else None
                
                if text is not None:
                    # Converter para string se não for
                    text_str = str(text) if not isinstance(text, str) else text
                    # Aplicar limpeza
                    cleaned = re.sub(patterns, '', text_str)
                    cleaned_texts.append(cleaned)
                else:
                    print(f"⚠️  Resultado sem texto (índice 1): {i}")
            
            # Log do número de resultados
            mlflow.log_metric("num_chunks_retrieved", len(cleaned_texts))
            
            return cleaned_texts
        except Exception as e:
            error_msg = f"Erro na busca vetorial: {str(e)}"
            print(f"❌ {error_msg}")
            mlflow.log_param("error", str(e))
            import traceback
            print(traceback.format_exc())
            # Retornar lista vazia ao invés de falhar
            return []

    @staticmethod
    @mlflow.trace(name="auto_merge_chunks", span_type="PARSER")
    def auto_merge_chunks(chunks: list, min_length: int = 300) -> list:
        """Mescla chunks pequenos para criar contextos mais coesos."""
        try:
            mlflow.log_param("num_chunks_input", len(chunks))
            mlflow.log_param("min_length", min_length)
            
            merged = []
            buffer = ""
            for chunk in chunks:
                if len(buffer) + len(chunk) < min_length:
                    buffer += " " + chunk
                else:
                    if buffer:
                        merged.append(buffer.strip())
                    buffer = chunk
            if buffer:
                merged.append(buffer.strip())
            
            mlflow.log_metric("num_chunks_merged", len(merged))
            
            return merged
        except Exception as e:
            print(f"Error: {e}")
            return []

    @mlflow.trace(name="generate_llm_response", span_type="LLM")
    def generate_llm_response(self, query: str, context_list: list) -> dict:
        """Gera resposta usando LLM com contexto RAG.
        
        Returns:
            dict: Resposta completa da LLM no formato {"choices": [...]}
        """
        print('\n Gerando resposta da LLM')
        try:
            import mlflow.deployments
            
            # Log dos parâmetros
            mlflow.log_param("llm_endpoint", self.endpoint_llm)
            mlflow.log_param("num_context_chunks", len(context_list))
            
            client = mlflow.deployments.get_deploy_client("databricks")
            context = " ".join(context_list)
            
            # Log do tamanho do contexto
            mlflow.log_metric("context_length", len(context))
            
            response = client.predict(
                endpoint=self.endpoint_llm,
                inputs={"messages": [
                    {
                        "role": "system",
                        "content": (
                            "Você é um assistente especializado em legislação tributária brasileira. Responda às perguntas do usuário APENAS com base no contexto fornecido da nossa base de dados (RAG). Você deve se ater estritamente ao tema de tributação e legislação fiscal brasileira. Se o usuário perguntar sobre assuntos não relacionados a tributação, educadamente redirecione a conversa informando que você é especializado apenas em legislação tributária brasileira. Se a resposta não estiver no contexto fornecido, diga 'Não há informação suficiente no contexto para responder.' Escreva o texto de forma clara, usando formatação markdown. Você pode inserir tabelas se ajudar a organizar as informações e usar bullet points quando necessário. Não inclua referências ao contexto no seu texto final. Sempre responda no mesmo idioma da pergunta do usuário."
                            f"Contexto: {context}"
                        )
                    },
                    {
                        "role": "user",
                        "content": f"{query}"
                    }
                ]}
            )
            
            # Log da resposta
            if response.get("choices"):
                response_text = response["choices"][0].get("message", {}).get("content", "")
                mlflow.log_metric("response_length", len(response_text))
            
            return response
        except Exception as e:
            print(f"Error: {e}")
            mlflow.log_param("error", str(e))
            return {"choices": [{"message": {"content": ""}}]}

    @mlflow.trace(name="rag_process_query", span_type="CHAIN")
    def process_query(self, query_usuario: str) -> dict:
        """Processa consulta completa: extração, busca e geração.
        
        Returns:
            dict: Resposta no formato {"messages": [HumanMessage, AIMessage]}
                  Similar ao formato retornado pelo GenieAgent
        """
        # Log da query
        mlflow.log_param("user_query", query_usuario)
        
        # Extrair metadados
        filtros = MetadataExtractor.extract(query_usuario)
        print(filtros)
        
        # Buscar contexto
        resultados = self.vector_search(query_usuario, filtros)
        
        # Mesclar chunks
        merged_context = self.auto_merge_chunks(resultados)
        
        # Gerar resposta
        llm_response = self.generate_llm_response(query_usuario, merged_context)
        
        # Extrair conteúdo da resposta da LLM
        resposta = llm_response.get("choices", [{}])[0].get("message", {}).get("content", "")
        
        # Retornar no formato de messages (similar ao Genie)
        return {
            "messages": [
                {"role": "user", "content": query_usuario},
                {"role": "assistant", "content": resposta}
            ]
        }
