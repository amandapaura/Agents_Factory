import re

class MetadataExtractor:
    """Extrai metadados de consultas para filtrar busca vetorial."""

    # Mapeamento de estados brasileiros (nome completo -> sigla)
    STATE_MAPPING = {
        'acre': 'AC', 'alagoas': 'AL', 'amapá': 'AP', 'amapa': 'AP',
        'amazonas': 'AM', 'bahia': 'BA', 'ceará': 'CE', 'ceara': 'CE',
        'distrito federal': 'DF', 'espírito santo': 'ES', 'espirito santo': 'ES',
        'goiás': 'GO', 'goias': 'GO', 'maranhão': 'MA', 'maranhao': 'MA',
        'mato grosso': 'MT', 'mato grosso do sul': 'MS',
        'minas gerais': 'MG', 'pará': 'PA', 'para': 'PA',
        'paraíba': 'PB', 'paraiba': 'PB', 'paraná': 'PR', 'parana': 'PR',
        'pernambuco': 'PE', 'piauí': 'PI', 'piaui': 'PI',
        'rio de janeiro': 'RJ', 'rio grande do norte': 'RN',
        'rio grande do sul': 'RS', 'rondônia': 'RO', 'rondonia': 'RO',
        'roraima': 'RR', 'santa catarina': 'SC', 'são paulo': 'SP',
        'sao paulo': 'SP', 'sergipe': 'SE', 'tocantins': 'TO'
    }
    
    # Lista de siglas válidas
    VALID_STATES = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
                    'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
                    'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO']
    
    @staticmethod
    def extract(query: str) -> dict:
        print('\n Extraindo metadados ...')
        
        # Validar que query é string
        if not isinstance(query, str):
            print(f"⚠️  Query não é string: {type(query)}, convertendo...")
            query = str(query) if query is not None else ""
        
        if not query or not query.strip():
            print("⚠️  Query vazia, retornando filtros vazios")
            return {}
        
        filtros = {}

        # Filtro por número da lei - aceita variações como "Lei 123", "lei numero 123", "ache a lei numero 123"
        match_number = re.search(r'lei\s+(?:n[úu]mero\s+|n[°º]\.\s+)?(\d+)', query, re.IGNORECASE)
        if match_number:
            filtros['law_number'] = match_number.group(1)

        # Filtro por ano da lei - aceita variações como "lei de 2020", "lei do ano 2021", "ano 2022"
        match_year = re.search(r'(?:ano|de)\s+(\d{4})|\b(19\d{2}|20\d{2})\b', query, re.IGNORECASE)
        if match_year:
            filtros['law_year'] = match_year.group(1) or match_year.group(2)

        # Filtro por estado da lei - aceita nome completo ou sigla
        query_lower = query.lower()
        
        # Primeiro tenta encontrar siglas (ex: "RJ", "SP")
        match_sigla = re.search(r'\b([A-Z]{2})\b', query)
        if match_sigla:
            sigla = match_sigla.group(1).upper()
            if sigla in MetadataExtractor.VALID_STATES:
                filtros['law_state'] = sigla
        
        # Se não encontrou sigla, busca por nome completo do estado
        if 'law_state' not in filtros:
            for state_name, sigla in MetadataExtractor.STATE_MAPPING.items():
                if state_name in query_lower:
                    filtros['law_state'] = sigla
                    break

        # Filtro por cidade da lei - aceita padrões como "lei de [cidade]", "lei municipal de [cidade]"
        # Captura nomes de cidades após palavras-chave comuns
        match_city = re.search(
            r'(?:lei\s+(?:municipal\s+)?(?:da\s+cidade\s+)?de\s+|cidade\s+de\s+|município\s+de\s+)([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)',
            query
        )
        if match_city:
            city_name = match_city.group(1).strip()
            # Verifica se não é um estado (para evitar falsos positivos)
            if city_name.lower() not in MetadataExtractor.STATE_MAPPING:
                filtros['law_city'] = city_name

        return filtros
