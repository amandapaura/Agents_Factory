import streamlit as st
import pandas as pd
import os
from databricks.sdk import WorkspaceClient
from config.settings import (
    MODEL_NAME, MODEL_ENDPOINT, MODEL_VERSION, 
    CATALOG, SCHEMA, 
    get_user_workspace_client,
    SESSION_TTL, MAX_HISTORY_LENGTH, KEEP_LAST_N_TURNS,
    LLM_ENDPOINT, ENABLE_ANALYTICS, ENABLE_SMART_SUMMARY,
    ANALYTICS_INTERACTIONS_TABLE, ANALYTICS_EVENTS_TABLE,
    ANALYTICS_BATCH_ENABLED, ANALYTICS_BATCH_SIZE
)
from memory import ConversationMemory
from utils.analytics_logger import InMemoryAnalyticsLogger

# Configurar página
st.set_page_config(
    page_title="Chatbot Legislação Tributária",
    page_icon="🤖",
    layout="wide"
)

@st.cache_resource
def get_workspace_client_with_fallback():
    """Cria WorkspaceClient com OBO + fallback para Service Principal."""
    try:
        obo_client = get_user_workspace_client()
        if obo_client:
            return obo_client, "OBO"
        
        client = WorkspaceClient()
        return client, "Service Principal"
        
    except Exception as e:
        st.error(f"❌ Erro ao criar WorkspaceClient: {e}")
        st.stop()

@st.cache_resource
def get_analytics_logger():
    """Cria e retorna o Analytics Logger (singleton)."""
    if not ENABLE_ANALYTICS:
        return None
    
    try:
        # Usar InMemoryAnalyticsLogger pois Streamlit não tem acesso ao Spark
        # Para persistir em Delta Tables, seria necessário um job separado
        return InMemoryAnalyticsLogger()
    except Exception as e:
        st.warning(f"⚠️ Analytics logger não disponível: {e}")
        return None

# Inicializar componentes
workspace_client, auth_type = get_workspace_client_with_fallback()

# Obter usuário autenticado
user_email = st.context.headers.get('x-forwarded-email', 'Usuário')

# Inicializar memória de conversação no session_state (persiste entre reloads)
# NOTA: Esta memória é apenas para exibição no UI
# O modelo MLflow tem sua própria memória interna gerenciada por session_id
if 'conversation_memory' not in st.session_state:
    st.session_state.conversation_memory = ConversationMemory(
        max_messages=MAX_HISTORY_LENGTH
    )
    
    # Log evento de criação de sessão
    if ENABLE_ANALYTICS:
        analytics = get_analytics_logger()
        if analytics:
            import uuid
            session_id = str(uuid.uuid4())
            st.session_state.session_id = session_id
            analytics.log_event(
                session_id=session_id,
                event_type="session_created",
                metadata={"user_email": user_email, "auth_type": auth_type}
            )
else:
    # Garantir que temos um session_id
    if 'session_id' not in st.session_state:
        import uuid
        st.session_state.session_id = str(uuid.uuid4())

memory = st.session_state.conversation_memory
session_id = st.session_state.session_id

# Header
st.title("🤖 Chatbot de Legislação Tributária")
st.caption(f"Modelo: **{MODEL_NAME}** v{MODEL_VERSION} | Usuário: **{user_email}**")

# Sidebar com controles
with st.sidebar:
    st.header("⚙️ Configurações")
    
    # Botão para limpar conversa
    if st.button("🗑️ Limpar Conversa", use_container_width=True):
        # O histórico no Delta Table é PRESERVADO para auditoria
        # O modelo continua com acesso ao histórico completo
        memory.clear()
        
        # - Session ID permanece o MESMO
        # - Histórico no Delta NÃO é apagado
        # - Apenas a TELA é limpa
        # - O modelo ainda tem acesso ao histórico completo
        
        # Log evento de limpeza da UI (com o MESMO session_id)
        if ENABLE_ANALYTICS:
            analytics = get_analytics_logger()
            if analytics:
                analytics.log_event(
                    session_id=session_id,
                    event_type="ui_cleared",  # ✅ Mudado para "ui_cleared"
                    metadata={
                        "user_email": user_email,
                        "note": "UI cleared, Delta history preserved"
                    }
                )
        
        st.rerun()
    
    # Informações da sessão
    st.divider()
    st.subheader("📊 Informações da Sessão")
    
    # Informações de memória
    memory_summary = memory.get_summary()
    st.write(f"**Mensagens (UI):** {memory_summary['total_messages']}/{memory_summary['max_capacity']}")
    st.write(f"**Total processadas:** {memory_summary['total_processed']}")
    st.write(f"**Session ID:** {session_id[:8]}...")
    st.write(f"**Auth:** {auth_type}")
    
    # Nota sobre memória
    st.info("ℹ️ O modelo mantém histórico completo no Delta Table. Limpar conversa apenas limpa a tela.")
    
    # Analytics status
    if ENABLE_ANALYTICS:
        st.success("📈 Analytics ativo (in-memory)")
    
    # Debug (colapsado)
    with st.expander("🔍 Debug"):
        st.write("**DATABRICKS_HOST:**", os.getenv('DATABRICKS_HOST', 'Não definido'))
        #st.write("**DATABRICKS_CLIENT_ID:**", os.getenv('DATABRICKS_CLIENT_ID', 'Não definido'))
        st.write("**MODEL_ENDPOINT:**", MODEL_ENDPOINT)
        st.write("**MODEL_VERSION:**", MODEL_VERSION)
        st.write("**LLM_ENDPOINT:**", LLM_ENDPOINT)
        st.write("**Session ID completo:**", session_id)
        
        # Mostrar histórico sendo enviado
        st.write("**Histórico na memória (UI):**", len(memory.get_messages()))
        
        # Estatísticas de analytics
        if ENABLE_ANALYTICS:
            analytics = get_analytics_logger()
            if analytics:
                stats = analytics.get_statistics()
                st.json(stats)

# Exibir histórico de mensagens
messages = memory.get_messages(include_metadata=False)
for message in messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Input do usuário
if prompt := st.chat_input("Faça sua pergunta sobre legislação tributária..."):
    # Adicionar mensagem do usuário à memória (apenas para UI)
    memory.add_user_message(prompt, metadata={"user_email": user_email})
    
    # Log analytics da pergunta
    if ENABLE_ANALYTICS:
        analytics = get_analytics_logger()
        if analytics:
            analytics.log_interaction(
                session_id=session_id,
                role="user",
                content=prompt,
                metadata={"user_email": user_email}
            )
    
    # Exibir mensagem do usuário
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Processar e exibir resposta do assistente
    with st.chat_message("assistant"):
        with st.spinner("🤔 Processando sua pergunta..."):
            try:
                # Preparar input APENAS com question e session_id
                # O modelo gerencia a memória internamente
                input_data = {
                    "question": [prompt],
                    "session_id": [session_id]
                }
                
                input_df = pd.DataFrame(input_data)
                input_records = input_df.to_dict(orient='records')
                
                # Chamar o endpoint
                response = workspace_client.serving_endpoints.query(
                    name=MODEL_ENDPOINT,
                    dataframe_records=input_records
                )
                
                # Extrair resultado
                if not response or not response.predictions:
                    st.error("⚠️ Endpoint não retornou resposta")
                    st.stop()
                
                prediction = response.predictions[0]
                
                if isinstance(prediction, dict):
                    answer = prediction.get('answer', 'Sem resposta')
                    prompt_tokens = prediction.get('prompt_tokens', 0)
                    completion_tokens = prediction.get('completion_tokens', 0)
                    total_tokens = prediction.get('total_tokens', 0)
                    returned_session_id = prediction.get('session_id', '')
                    
                    # Apenas logar se o modelo retornou um ID diferente (para debug)
                    if returned_session_id and returned_session_id != session_id:
                        print(f"⚠️ DEBUG: Modelo retornou session_id diferente!")
                        print(f"   Streamlit: {session_id}")
                        print(f"   Modelo: {returned_session_id}")
                        print(f"   → Mantendo session_id do Streamlit")
                else:
                    st.error(f"⚠️ Formato de resposta inesperado: {type(prediction)}")
                    st.stop()
                
                # Verificar se houve erro
                if answer.startswith("Erro ao processar pergunta:"):
                    st.error(answer)
                    st.stop()
                
                # Verificar se está vazia
                if answer == 'Sem resposta':
                    st.warning("⚠️ O modelo retornou 'Sem resposta'.")
                    st.stop()
                
                # Exibir resposta
                st.markdown(answer)
                
                # Adicionar resposta à memória (apenas para UI)
                memory.add_assistant_message(
                    content=answer,
                    agent_name="tax_chatbot",
                    metadata={
                        "metrics": {
                            "prompt_tokens": prompt_tokens,
                            "completion_tokens": completion_tokens,
                            "total_tokens": total_tokens
                        }
                    }
                )
                
                # Log analytics da resposta
                if ENABLE_ANALYTICS:
                    analytics = get_analytics_logger()
                    if analytics:
                        analytics.log_interaction(
                            session_id=session_id,
                            role="assistant",
                            content=answer,
                            metadata={
                                "agent": "tax_chatbot",
                                "metrics": {
                                    "prompt_tokens": prompt_tokens,
                                    "completion_tokens": completion_tokens,
                                    "total_tokens": total_tokens
                                }
                            }
                        )
                
                # Exibir métricas
                with st.expander("📊 Métricas de uso"):
                    col1, col2, col3 = st.columns(3)
                    col1.metric("Prompt Tokens", f"{prompt_tokens:,.0f}")
                    col2.metric("Completion Tokens", f"{completion_tokens:,.0f}")
                    col3.metric("Total Tokens", f"{total_tokens:,.0f}")
                
                with st.expander("🔍 Debug - Input/Output da Interação"):
                    st.subheader("📤 Input enviado ao modelo:")
                    st.json({
                        "question": prompt,
                        "session_id": session_id
                    })
                    
                    st.divider()
                    
                    st.subheader("📥 Output recebido do modelo:")
                    st.json({
                        "answer": answer[:200] + "..." if len(answer) > 200 else answer,  # Limitar tamanho
                        "session_id": returned_session_id,
                        "prompt_tokens": prompt_tokens,
                        "completion_tokens": completion_tokens,
                        "total_tokens": total_tokens
                    })
                    
                    st.divider()
                    
                    st.subheader("🔄 Comparação de Session IDs:")
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write("**Streamlit (enviado):**")
                        st.code(session_id)
                    with col2:
                        st.write("**Modelo (retornado):**")
                        st.code(returned_session_id)
                    
                    if session_id == returned_session_id:
                        st.success("✅ Session IDs são iguais - Memória funcionando!")
                    else:
                        st.error("❌ Session IDs diferentes - Memória pode não estar funcionando!")
                    
                    st.divider()
                    
                    st.subheader("📊 Dados completos da resposta:")
                    st.json(prediction)
                    
            except Exception as e:
                st.error(f"❌ Erro ao chamar endpoint: {e}")
                
                with st.expander("🔍 Detalhes do erro"):
                    import traceback
                    st.code(traceback.format_exc())
